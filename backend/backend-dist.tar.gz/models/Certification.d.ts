import { Document, Types } from 'mongoose';
export type CertificationStatus = 'active' | 'expiring_soon' | 'expired' | 'renewed' | 'revoked' | 'suspended';
export interface ICertification extends Document {
    cert_number: string;
    cert_type: string;
    org_id: Types.ObjectId;
    product_id: Types.ObjectId;
    application_id: Types.ObjectId;
    issuing_body: string;
    scheme: string;
    issue_date: Date;
    expiry_date: Date;
    validity_period_months: number;
    status: CertificationStatus;
    status_changed_at: Date;
    revocation_reason?: string;
    certificate_document_id?: Types.ObjectId;
    test_report_document_ids: Types.ObjectId[];
    predecessor_cert_id?: Types.ObjectId;
    successor_cert_id?: Types.ObjectId;
    renewal_due_at?: Date;
    scope?: string;
    notes?: string;
    tags: string[];
    public_verifiable: boolean;
    verification_url?: string;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Certification: import("mongoose").Model<ICertification, {}, {}, {}, Document<unknown, {}, ICertification, {}, import("mongoose").DefaultSchemaOptions> & ICertification & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, ICertification>;
//# sourceMappingURL=Certification.d.ts.map