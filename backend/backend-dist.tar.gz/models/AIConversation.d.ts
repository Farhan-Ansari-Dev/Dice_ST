import { Document, Types } from 'mongoose';
export interface IAIConversation extends Document {
    user_id: Types.ObjectId;
    messages: any[];
    created_at: Date;
    updated_at: Date;
}
export declare const AIConversation: import("mongoose").Model<IAIConversation, {}, {}, {}, Document<unknown, {}, IAIConversation, {}, import("mongoose").DefaultSchemaOptions> & IAIConversation & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IAIConversation>;
//# sourceMappingURL=AIConversation.d.ts.map