"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Payment = void 0;
const mongoose_1 = require("mongoose");
const PaymentSchema = new mongoose_1.Schema({
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    user_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    application_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Application', index: true },
    certification_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Certification' },
    description: { type: String, required: true },
    purpose: { type: String, enum: ['application_fee', 'expedited_fee', 'renewal_fee', 'subscription', 'other'], required: true, index: true },
    amount_paise: { type: Number, required: true },
    currency: { type: String, enum: ['INR', 'USD', 'AED', 'EUR'], default: 'INR' },
    tax_amount_paise: { type: Number, default: 0 },
    total_paise: { type: Number, required: true },
    status: { type: String, enum: ['pending', 'authorized', 'captured', 'failed', 'refunded', 'partially_refunded'], default: 'pending', index: true },
    razorpay_order_id: { type: String, unique: true, sparse: true },
    razorpay_payment_id: { type: String, sparse: true, index: true },
    razorpay_signature: String,
    razorpay_refund_id: String,
    method: String,
    captured_at: Date,
    failed_reason: String,
    refunded_paise: Number,
    refunded_at: Date,
    invoice_number: { type: String, unique: true, sparse: true },
    invoice_url: String,
    metadata: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    ip: String,
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
PaymentSchema.index({ org_id: 1, status: 1, created_at: -1 });
PaymentSchema.index({ application_id: 1, status: 1 });
exports.Payment = (0, mongoose_1.model)('Payment', PaymentSchema);
//# sourceMappingURL=Payment.js.map