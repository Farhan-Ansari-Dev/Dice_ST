"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const mongoose_1 = require("mongoose");
const UserSchema = new mongoose_1.Schema({
    email: { type: String, required: true, lowercase: true, trim: true },
    phone: { type: String, trim: true },
    name: { type: String, required: true, trim: true },
    avatar_url: { type: String },
    role: { type: String, enum: ['super_admin', 'admin', 'consultant', 'client', 'viewer', 'cb', 'lab', 'ib'], default: 'client', index: true },
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', index: true },
    locale: { type: String, default: 'en-IN' },
    country_code: { type: String, default: 'IN', uppercase: true },
    password_hash: { type: String, select: false },
    otp_hash: { type: String, select: false },
    otp_expires_at: { type: Date, select: false },
    otp_attempts: { type: Number, default: 0, select: false },
    totp_secret: { type: String, select: false },
    totp_enabled: { type: Boolean, default: false },
    expo_push_tokens: { type: [String], default: [] },
    webpush_subscriptions: [
        {
            endpoint: { type: String, required: true },
            keys: {
                p256dh: { type: String, required: true },
                auth: { type: String, required: true },
            },
            created_at: { type: Date, default: Date.now },
            _id: false,
        },
    ],
    notification_preferences: {
        push: { type: mongoose_1.Schema.Types.Mixed },
        email: { type: mongoose_1.Schema.Types.Mixed },
        sms: { type: mongoose_1.Schema.Types.Mixed },
        quiet_hours: {
            start: String,
            end: String,
            timezone: { type: String, default: 'Asia/Kolkata' },
        },
    },
    consents: {
        privacy_policy: {
            version: { type: String, default: '1.0' },
            accepted_at: { type: Date, default: Date.now },
        },
        marketing: { type: Boolean, default: false },
        analytics: { type: Boolean, default: true },
    },
    email_verified_at: Date,
    last_active_at: Date,
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
// Unique email when not soft-deleted
UserSchema.index({ email: 1 }, { unique: true, partialFilterExpression: { deleted_at: null } });
UserSchema.index({ phone: 1 }, { unique: true, sparse: true });
UserSchema.index({ org_id: 1, role: 1 });
// Auto-exclude soft-deleted in default queries (use .setOptions({ includeDeleted: true }) to bypass)
UserSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted) {
        this.where({ deleted_at: null });
    }
});
exports.User = (0, mongoose_1.model)('User', UserSchema);
//# sourceMappingURL=User.js.map