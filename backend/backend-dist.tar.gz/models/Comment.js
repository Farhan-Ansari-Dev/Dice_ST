"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Comment = void 0;
const mongoose_1 = require("mongoose");
const CommentSchema = new mongoose_1.Schema({
    resource_type: { type: String, enum: ['application', 'document', 'certification'], required: true, index: true },
    resource_id: { type: mongoose_1.Schema.Types.ObjectId, required: true, index: true },
    parent_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Comment' },
    thread_root_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Comment', index: true },
    author_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    body: { type: String, required: true },
    mentions: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'User' }],
    attachments: [{
            document_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Document' },
            label: String,
            _id: false,
        }],
    is_system: { type: Boolean, default: false },
    system_event: String,
    edited_at: Date,
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
CommentSchema.index({ resource_type: 1, resource_id: 1, created_at: -1 });
CommentSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Comment = (0, mongoose_1.model)('Comment', CommentSchema);
//# sourceMappingURL=Comment.js.map