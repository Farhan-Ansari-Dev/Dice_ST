import type { ApplicationStatus } from './Application';
/**
 * Workflow definitions for each certification type.
 *
 * Stored as DATA so adding a new cert type (e.g., new EU CE Marking Cat. III)
 * is a database insert — zero code change.
 *
 * Each workflow describes the stages, required docs per stage, SLAs, and fees.
 */
export interface IWorkflowStage {
    id: ApplicationStatus;
    label: string;
    description?: string;
    sla_days: number;
    required_docs: Array<{
        doc_type: string;
        label: string;
        mandatory: boolean;
    }>;
    next_states: ApplicationStatus[];
    assignee_role?: string;
    auto_advance?: boolean;
}
export interface IWorkflow {
    _id: string;
    cert_type: string;
    display_name: string;
    description?: string;
    version: number;
    active: boolean;
    issuing_body: string;
    country_code: string;
    estimated_duration_days: number;
    validity_period_months: number;
    stages: IWorkflowStage[];
    fee_structure: {
        application_fee_inr: number;
        annual_fee_inr?: number;
        expedited_surcharge_inr?: number;
        test_fee_inr?: number;
    };
    customer_description?: string;
    required_business_info: string[];
    helpful_links?: Array<{
        label: string;
        url: string;
    }>;
    created_at: Date;
    updated_at: Date;
}
export declare const Workflow: import("mongoose").Model<any, unknown, unknown, unknown, any, any, unknown>;
//# sourceMappingURL=Workflow.d.ts.map