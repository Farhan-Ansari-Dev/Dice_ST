"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Workflow = void 0;
const mongoose_1 = require("mongoose");
const WorkflowStageSchema = new mongoose_1.Schema({
    id: { type: String, required: true },
    label: { type: String, required: true },
    description: String,
    sla_days: { type: Number, default: 7 },
    required_docs: [{
            doc_type: { type: String, required: true },
            label: { type: String, required: true },
            mandatory: { type: Boolean, default: true },
            _id: false,
        }],
    next_states: [String],
    assignee_role: String,
    auto_advance: { type: Boolean, default: false },
}, { _id: false });
const WorkflowSchema = new mongoose_1.Schema({
    _id: { type: String, required: true }, // override ObjectId with readable id
    cert_type: { type: String, required: true, index: true },
    display_name: { type: String, required: true },
    description: String,
    version: { type: Number, default: 1 },
    active: { type: Boolean, default: true, index: true },
    issuing_body: { type: String, required: true },
    country_code: { type: String, default: 'IN', index: true },
    estimated_duration_days: { type: Number, default: 45 },
    validity_period_months: { type: Number, default: 24 },
    stages: { type: [WorkflowStageSchema], default: [] },
    fee_structure: {
        application_fee_inr: { type: Number, default: 0 },
        annual_fee_inr: Number,
        expedited_surcharge_inr: Number,
        test_fee_inr: Number,
    },
    customer_description: String,
    required_business_info: [String],
    helpful_links: [{ label: String, url: String, _id: false }],
}, { _id: false, timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
WorkflowSchema.index({ cert_type: 1, active: 1, version: -1 });
exports.Workflow = (0, mongoose_1.model)('Workflow', WorkflowSchema);
//# sourceMappingURL=Workflow.js.map