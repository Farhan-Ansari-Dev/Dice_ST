"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.Shipment = void 0;
const mongoose_1 = __importStar(require("mongoose"));
const ShipmentSchema = new mongoose_1.Schema({
    shipment_number: { type: String, required: true, unique: true },
    client_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    origin: { type: String, required: true },
    destination: { type: String, required: true },
    status: {
        type: String,
        enum: ['pending', 'in_transit', 'customs_clearance', 'delivered', 'held', 'cancelled'],
        default: 'pending',
    },
    expected_delivery: { type: Date },
    documents: [
        {
            name: { type: String, required: true },
            url: { type: String, required: true },
            uploaded_at: { type: Date, default: Date.now },
        },
    ],
    deleted_at: { type: Date, default: null },
}, { timestamps: true });
exports.Shipment = mongoose_1.default.model('Shipment', ShipmentSchema);
//# sourceMappingURL=Shipment.js.map