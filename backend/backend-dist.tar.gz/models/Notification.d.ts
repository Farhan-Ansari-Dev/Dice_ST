import { Document, Types } from 'mongoose';
export interface INotification extends Document {
    user_id: Types.ObjectId;
    type: string;
    title: string;
    body: string;
    data?: Record<string, any>;
    channels: Array<'in_app' | 'push' | 'email' | 'sms'>;
    delivered_channels: string[];
    read_at?: Date;
    clicked_at?: Date;
    expires_at?: Date;
    resource_type?: string;
    resource_id?: Types.ObjectId;
    created_at: Date;
}
export declare const Notification: import("mongoose").Model<INotification, {}, {}, {}, Document<unknown, {}, INotification, {}, import("mongoose").DefaultSchemaOptions> & INotification & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, INotification>;
//# sourceMappingURL=Notification.d.ts.map