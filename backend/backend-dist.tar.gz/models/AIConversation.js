"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIConversation = void 0;
const mongoose_1 = require("mongoose");
const AIConversationSchema = new mongoose_1.Schema({
    user_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    messages: [{ type: mongoose_1.Schema.Types.Mixed }],
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
exports.AIConversation = (0, mongoose_1.model)('AIConversation', AIConversationSchema);
//# sourceMappingURL=AIConversation.js.map