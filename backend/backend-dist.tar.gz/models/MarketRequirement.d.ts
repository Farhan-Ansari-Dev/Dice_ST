import mongoose, { Document } from 'mongoose';
import { IProductCategory } from './ProductCategory';
import { IMarketCertification } from './MarketCertification';
export interface IMarketRequirement extends Document {
    country: string;
    productCategoryId: mongoose.Types.ObjectId | IProductCategory;
    requiredCertifications: mongoose.Types.ObjectId[] | IMarketCertification[];
    optionalCertifications: mongoose.Types.ObjectId[] | IMarketCertification[];
    marketReadinessRules?: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IMarketRequirement, {}, {}, {}, mongoose.Document<unknown, {}, IMarketRequirement, {}, mongoose.DefaultSchemaOptions> & IMarketRequirement & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IMarketRequirement>;
export default _default;
//# sourceMappingURL=MarketRequirement.d.ts.map