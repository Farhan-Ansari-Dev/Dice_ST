import { Document, Types } from 'mongoose';
export interface IComment extends Document {
    resource_type: 'application' | 'document' | 'certification';
    resource_id: Types.ObjectId;
    parent_id?: Types.ObjectId;
    thread_root_id?: Types.ObjectId;
    author_id: Types.ObjectId;
    body: string;
    mentions: Types.ObjectId[];
    attachments: Array<{
        document_id: Types.ObjectId;
        label: string;
    }>;
    is_system: boolean;
    system_event?: string;
    edited_at?: Date;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Comment: import("mongoose").Model<IComment, {}, {}, {}, Document<unknown, {}, IComment, {}, import("mongoose").DefaultSchemaOptions> & IComment & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IComment>;
//# sourceMappingURL=Comment.d.ts.map