import { Document as MongooseDoc, Types } from 'mongoose';
/**
 * A LOGICAL document (e.g. "BIS Test Report for Product X").
 * The actual file content lives in document_versions — this is the pointer.
 *
 * Pattern: parent doc holds current_version_id (denormalized for fast reads).
 * All previous versions are queryable from document_versions by document_id.
 */
export interface IDocument extends MongooseDoc {
    org_id: Types.ObjectId;
    uploaded_by: Types.ObjectId;
    name: string;
    doc_type: string;
    category?: string;
    application_ids: Types.ObjectId[];
    certification_id?: Types.ObjectId;
    product_id?: Types.ObjectId;
    current_version_id: Types.ObjectId;
    version_count: number;
    tags: string[];
    description?: string;
    visibility: 'private' | 'org' | 'shared_external';
    shared_with: Types.ObjectId[];
    retention_until?: Date;
    is_legal_hold: boolean;
    pii_classification: 'none' | 'low' | 'medium' | 'high';
    archived_at?: Date;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Document: import("mongoose").Model<IDocument, {}, {}, {}, MongooseDoc<unknown, {}, IDocument, {}, import("mongoose").DefaultSchemaOptions> & IDocument & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IDocument>;
//# sourceMappingURL=Document.d.ts.map