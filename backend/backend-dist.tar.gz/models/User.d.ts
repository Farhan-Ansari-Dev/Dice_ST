import { Document, Types } from 'mongoose';
export interface IUser extends Document {
    email: string;
    phone?: string;
    name: string;
    avatar_url?: string;
    role: 'super_admin' | 'admin' | 'consultant' | 'client' | 'viewer' | 'cb' | 'lab' | 'ib';
    org_id?: Types.ObjectId;
    locale: string;
    country_code: string;
    password_hash?: string;
    otp_hash?: string;
    otp_expires_at?: Date;
    otp_attempts: number;
    totp_secret?: string;
    totp_enabled: boolean;
    expo_push_tokens: string[];
    webpush_subscriptions: Array<{
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        created_at: Date;
    }>;
    notification_preferences?: {
        push?: Record<string, boolean>;
        email?: Record<string, boolean>;
        sms?: Record<string, boolean>;
        quiet_hours?: {
            start: string;
            end: string;
            timezone: string;
        };
    };
    consents: {
        privacy_policy: {
            version: string;
            accepted_at: Date;
        };
        marketing: boolean;
        analytics: boolean;
    };
    email_verified_at?: Date;
    last_active_at?: Date;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const User: import("mongoose").Model<IUser, {}, {}, {}, Document<unknown, {}, IUser, {}, import("mongoose").DefaultSchemaOptions> & IUser & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IUser>;
//# sourceMappingURL=User.d.ts.map