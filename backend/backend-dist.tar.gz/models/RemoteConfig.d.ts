import mongoose from 'mongoose';
export interface IRemoteConfig {
    version: string;
    featureFlags: {
        maintenance_mode: boolean;
        enable_ai_assistant: boolean;
        enable_ocr_scanning: boolean;
        enable_referral_rewards: boolean;
        enable_promotional_banners: boolean;
        enable_notifications: boolean;
    };
    dynamicConfig: {
        banner_text: string;
        banner_color: string;
        referral_reward_value: number;
        announcement_title: string;
        announcement_body: string;
    };
}
export declare const RemoteConfig: mongoose.Model<IRemoteConfig, {}, {}, {}, mongoose.Document<unknown, {}, IRemoteConfig, {}, mongoose.DefaultSchemaOptions> & IRemoteConfig & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
} & {
    id: string;
}, any, IRemoteConfig> & {
    getGlobalConfig(): Promise<mongoose.Document<unknown, {}, IRemoteConfig> & IRemoteConfig>;
};
//# sourceMappingURL=RemoteConfig.d.ts.map