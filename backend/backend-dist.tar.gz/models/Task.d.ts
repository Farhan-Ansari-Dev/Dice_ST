import { Document, Types } from 'mongoose';
export interface ITask extends Document {
    org_id: Types.ObjectId;
    application_id?: Types.ObjectId;
    title: string;
    description?: string;
    assigned_to: Types.ObjectId;
    assigned_by: Types.ObjectId;
    priority: 'low' | 'medium' | 'high' | 'urgent';
    status: 'todo' | 'in_progress' | 'blocked' | 'done' | 'cancelled';
    due_at?: Date;
    completed_at?: Date;
    checklist: Array<{
        item: string;
        done: boolean;
        done_at?: Date;
    }>;
    attachments: Types.ObjectId[];
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Task: import("mongoose").Model<ITask, {}, {}, {}, Document<unknown, {}, ITask, {}, import("mongoose").DefaultSchemaOptions> & ITask & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, ITask>;
//# sourceMappingURL=Task.d.ts.map