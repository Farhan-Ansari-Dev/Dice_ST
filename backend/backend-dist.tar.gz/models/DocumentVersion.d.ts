import { Document as MongooseDoc, Types } from 'mongoose';
/**
 * IMMUTABLE — never updated after creation.
 *
 * One row per upload. The parent Document.current_version_id points
 * at the latest one. Old versions remain queryable for audit.
 *
 * Storage: file content is in S3, identified by s3_key.
 *          sha256 makes each version content-addressable (dedupe possible).
 */
export interface IDocumentVersion extends MongooseDoc {
    document_id: Types.ObjectId;
    version_number: number;
    s3_bucket: string;
    s3_key: string;
    s3_region: string;
    original_filename: string;
    mime_type: string;
    size_bytes: number;
    sha256: string;
    page_count?: number;
    uploaded_by: Types.ObjectId;
    uploaded_at: Date;
    upload_ip?: string;
    upload_user_agent?: string;
    change_reason?: string;
    ocr_text?: string;
    ai_extracted?: {
        summary?: string;
        key_fields?: Record<string, any>;
        compliance_score?: number;
        issues?: string[];
    };
    thumbnail_s3_key?: string;
    virus_scan?: {
        scanned_at: Date;
        clean: boolean;
        engine: string;
    };
    signature?: {
        algorithm: string;
        value: string;
        signed_at: Date;
        cert_chain_s3_key?: string;
    };
}
export declare const DocumentVersion: import("mongoose").Model<IDocumentVersion, {}, {}, {}, MongooseDoc<unknown, {}, IDocumentVersion, {}, import("mongoose").DefaultSchemaOptions> & IDocumentVersion & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IDocumentVersion>;
//# sourceMappingURL=DocumentVersion.d.ts.map