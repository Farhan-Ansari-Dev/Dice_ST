"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Certification = void 0;
const mongoose_1 = require("mongoose");
const CertificationSchema = new mongoose_1.Schema({
    cert_number: { type: String, required: true, unique: true, index: true },
    cert_type: { type: String, required: true, index: true },
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    product_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Product', required: true, index: true },
    application_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Application', required: true, index: true },
    issuing_body: { type: String, required: true },
    scheme: { type: String, required: true },
    issue_date: { type: Date, required: true },
    expiry_date: { type: Date, required: true, index: true },
    validity_period_months: { type: Number, default: 12 },
    status: { type: String, enum: ['active', 'expiring_soon', 'expired', 'renewed', 'revoked', 'suspended'], default: 'active', index: true },
    status_changed_at: { type: Date, default: Date.now },
    revocation_reason: String,
    certificate_document_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Document' },
    test_report_document_ids: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'Document' }],
    predecessor_cert_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Certification' },
    successor_cert_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Certification' },
    renewal_due_at: { type: Date, index: true },
    scope: String,
    notes: String,
    tags: { type: [String], default: [] },
    public_verifiable: { type: Boolean, default: false },
    verification_url: String,
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
// Critical indexes
CertificationSchema.index({ org_id: 1, status: 1, expiry_date: 1 });
CertificationSchema.index({ expiry_date: 1, status: 1 }); // for expiry-cron (range scan)
CertificationSchema.index({ org_id: 1, cert_type: 1, issue_date: -1 });
// Auto-flip "expiring_soon" + "expired" via a daily job (see jobs/certificationLifecycle.ts)
CertificationSchema.statics.computeStatus = function (cert) {
    const now = Date.now();
    const expiryMs = cert.expiry_date.getTime();
    const daysToExpiry = (expiryMs - now) / (1000 * 60 * 60 * 24);
    if (cert.status === 'revoked' || cert.status === 'renewed' || cert.status === 'suspended') {
        return cert.status;
    }
    if (daysToExpiry < 0)
        return 'expired';
    if (daysToExpiry <= 30)
        return 'expiring_soon';
    return 'active';
};
CertificationSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Certification = (0, mongoose_1.model)('Certification', CertificationSchema);
//# sourceMappingURL=Certification.js.map