"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentVersion = void 0;
const mongoose_1 = require("mongoose");
const DocumentVersionSchema = new mongoose_1.Schema({
    document_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Document', required: true, index: true },
    version_number: { type: Number, required: true },
    s3_bucket: { type: String, required: true },
    s3_key: { type: String, required: true },
    s3_region: { type: String, default: 'ap-south-1' },
    original_filename: { type: String, required: true },
    mime_type: { type: String, required: true },
    size_bytes: { type: Number, required: true },
    sha256: { type: String, required: true, index: true },
    page_count: Number,
    uploaded_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    uploaded_at: { type: Date, default: Date.now, index: true },
    upload_ip: String,
    upload_user_agent: String,
    change_reason: String,
    ocr_text: { type: String },
    ai_extracted: {
        summary: String,
        key_fields: { type: mongoose_1.Schema.Types.Mixed, default: {} },
        compliance_score: Number,
        issues: [String],
    },
    thumbnail_s3_key: String,
    virus_scan: {
        scanned_at: Date,
        clean: Boolean,
        engine: String,
    },
    signature: {
        algorithm: String,
        value: String,
        signed_at: Date,
        cert_chain_s3_key: String,
    },
}, { timestamps: false } // immutable — no updated_at
);
// Unique version per document
DocumentVersionSchema.index({ document_id: 1, version_number: -1 }, { unique: true });
// Dedupe / integrity lookup
DocumentVersionSchema.index({ sha256: 1 });
// Full-text search on OCR'd content
DocumentVersionSchema.index({ ocr_text: 'text', 'ai_extracted.summary': 'text' });
// IMMUTABILITY GUARDS
DocumentVersionSchema.pre("save", function (next) {
    if (!this.isNew) {
        // Allow only specific async-processing fields to be updated
        const allowedUpdates = ['ocr_text', 'ai_extracted', 'thumbnail_s3_key', 'virus_scan', 'signature'];
        const modified = this.modifiedPaths();
        const forbidden = modified.filter((p) => !allowedUpdates.some(a => p.startsWith(a)));
        if (forbidden.length) {
            return next(new Error(`DocumentVersion is immutable. Forbidden modifications: ${forbidden.join(',')}`));
        }
    }
});
DocumentVersionSchema.pre("deleteOne", { document: true }, function (next) {
    next(new Error('DocumentVersion cannot be deleted — versions are immutable for audit'));
});
exports.DocumentVersion = (0, mongoose_1.model)('DocumentVersion', DocumentVersionSchema);
//# sourceMappingURL=DocumentVersion.js.map