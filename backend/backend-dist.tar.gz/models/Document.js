"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Document = void 0;
const mongoose_1 = require("mongoose");
const DocumentSchema = new mongoose_1.Schema({
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    uploaded_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true, trim: true },
    doc_type: { type: String, required: true, index: true },
    category: { type: String },
    application_ids: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'Application', index: true }],
    certification_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Certification', index: true },
    product_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Product', index: true },
    current_version_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'DocumentVersion', required: true },
    version_count: { type: Number, default: 1 },
    tags: { type: [String], default: [], index: true },
    description: String,
    visibility: { type: String, enum: ['private', 'org', 'shared_external'], default: 'org' },
    shared_with: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'User' }],
    retention_until: Date,
    is_legal_hold: { type: Boolean, default: false, index: true },
    pii_classification: { type: String, enum: ['none', 'low', 'medium', 'high'], default: 'low' },
    archived_at: Date,
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
// Indexes
DocumentSchema.index({ org_id: 1, doc_type: 1, created_at: -1 });
DocumentSchema.index({ org_id: 1, created_at: -1 });
DocumentSchema.index({ application_ids: 1 });
DocumentSchema.index({ name: 'text', description: 'text', tags: 'text' });
// Prevent deletion when legal-hold or retention-locked
DocumentSchema.pre("deleteOne", { document: true }, function (next) {
    if (this.is_legal_hold)
        return next(new Error('Cannot delete: document is under legal hold'));
    if (this.retention_until && this.retention_until > new Date()) {
        return next(new Error(`Cannot delete: retention until ${this.retention_until.toISOString()}`));
    }
});
DocumentSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Document = (0, mongoose_1.model)('Document', DocumentSchema);
//# sourceMappingURL=Document.js.map