import { Document, Types } from 'mongoose';
export type PaymentStatus = 'pending' | 'authorized' | 'captured' | 'failed' | 'refunded' | 'partially_refunded';
export interface IPayment extends Document {
    org_id: Types.ObjectId;
    user_id: Types.ObjectId;
    application_id?: Types.ObjectId;
    certification_id?: Types.ObjectId;
    description: string;
    purpose: 'application_fee' | 'expedited_fee' | 'renewal_fee' | 'subscription' | 'other';
    amount_paise: number;
    currency: 'INR' | 'USD' | 'AED' | 'EUR';
    tax_amount_paise: number;
    total_paise: number;
    status: PaymentStatus;
    razorpay_order_id?: string;
    razorpay_payment_id?: string;
    razorpay_signature?: string;
    razorpay_refund_id?: string;
    method?: string;
    captured_at?: Date;
    failed_reason?: string;
    refunded_paise?: number;
    refunded_at?: Date;
    invoice_number?: string;
    invoice_url?: string;
    metadata: Record<string, any>;
    ip?: string;
    created_at: Date;
    updated_at: Date;
}
export declare const Payment: import("mongoose").Model<IPayment, {}, {}, {}, Document<unknown, {}, IPayment, {}, import("mongoose").DefaultSchemaOptions> & IPayment & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IPayment>;
//# sourceMappingURL=Payment.d.ts.map