import mongoose, { Document } from 'mongoose';
export interface IMarketCertification extends Document {
    certificationName: string;
    code: string;
    country: string;
    authority: string;
    description?: string;
    estimatedTimeline: string;
    estimatedCost: string;
    renewalCycle: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IMarketCertification, {}, {}, {}, mongoose.Document<unknown, {}, IMarketCertification, {}, mongoose.DefaultSchemaOptions> & IMarketCertification & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IMarketCertification>;
export default _default;
//# sourceMappingURL=MarketCertification.d.ts.map