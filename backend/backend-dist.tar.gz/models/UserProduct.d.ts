import mongoose, { Document } from 'mongoose';
export interface IUserProduct extends Document {
    userId: string;
    productName: string;
    categoryId: mongoose.Types.ObjectId;
    existingCertifications: mongoose.Types.ObjectId[];
    targetMarkets: string[];
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IUserProduct, {}, {}, {}, mongoose.Document<unknown, {}, IUserProduct, {}, mongoose.DefaultSchemaOptions> & IUserProduct & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IUserProduct>;
export default _default;
//# sourceMappingURL=UserProduct.d.ts.map