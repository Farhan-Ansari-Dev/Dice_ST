"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Notification = void 0;
const mongoose_1 = require("mongoose");
const NotificationSchema = new mongoose_1.Schema({
    user_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: { type: String, required: true, index: true },
    title: { type: String, required: true },
    body: { type: String, required: true },
    data: { type: mongoose_1.Schema.Types.Mixed },
    channels: [String],
    delivered_channels: [String],
    read_at: Date,
    clicked_at: Date,
    expires_at: Date,
    resource_type: String,
    resource_id: mongoose_1.Schema.Types.ObjectId,
}, { timestamps: { createdAt: 'created_at', updatedAt: false } });
NotificationSchema.index({ user_id: 1, read_at: 1, created_at: -1 });
// Auto-delete after 180 days
NotificationSchema.index({ created_at: 1 }, { expireAfterSeconds: 180 * 24 * 3600 });
exports.Notification = (0, mongoose_1.model)('Notification', NotificationSchema);
//# sourceMappingURL=Notification.js.map