"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Product = void 0;
const mongoose_1 = require("mongoose");
const ProductSchema = new mongoose_1.Schema({
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    name: { type: String, required: true, trim: true },
    brand: { type: String, trim: true },
    model_number: { type: String, trim: true },
    category: { type: String, required: true, index: true },
    sub_category: { type: String },
    hsn_code: { type: String, index: true },
    description: String,
    specifications: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    images: { type: [String], default: [] },
    manufacturer: {
        name: String,
        country_code: { type: String, default: 'IN' },
        factory_address: String,
    },
    is_imported: { type: Boolean, default: false, index: true },
    countries_of_sale: { type: [String], default: ['IN'] },
    active: { type: Boolean, default: true, index: true },
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
ProductSchema.index({ org_id: 1, category: 1, active: 1 });
ProductSchema.index({ org_id: 1, name: 'text', brand: 'text', model_number: 'text' });
ProductSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Product = (0, mongoose_1.model)('Product', ProductSchema);
//# sourceMappingURL=Product.js.map