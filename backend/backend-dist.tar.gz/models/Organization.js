"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Organization = void 0;
const mongoose_1 = require("mongoose");
const OrganizationSchema = new mongoose_1.Schema({
    name: { type: String, required: true, trim: true },
    legal_name: { type: String, trim: true },
    type: { type: String, enum: ['manufacturer', 'importer', 'consultant', 'cb', 'lab', 'other'], default: 'manufacturer', index: true },
    gst_number: { type: String, trim: true, uppercase: true },
    pan_number: { type: String, trim: true, uppercase: true },
    iec_code: { type: String, trim: true },
    cin: { type: String, trim: true, uppercase: true },
    address: {
        line1: String,
        line2: String,
        city: String,
        state: String,
        country_code: { type: String, default: 'IN', uppercase: true, index: true },
        pincode: String,
    },
    contact: {
        email: String,
        phone: String,
        website: String,
    },
    branding: {
        logo_url: String,
        primary_color: String,
    },
    subscription: {
        tier: { type: String, enum: ['free', 'starter', 'pro', 'enterprise'], default: 'free', index: true },
        seats: { type: Number, default: 1 },
        trial_ends_at: Date,
        renewed_at: Date,
        razorpay_customer_id: String,
        razorpay_subscription_id: String,
    },
    owner_user_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    settings: {
        require_2fa_for_admins: { type: Boolean, default: false },
        allowed_cert_types: { type: [String], default: [] },
        notification_preferences: { type: mongoose_1.Schema.Types.Mixed, default: {} },
    },
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
OrganizationSchema.index({ gst_number: 1 }, { unique: true, sparse: true });
OrganizationSchema.index({ 'address.country_code': 1, 'subscription.tier': 1 });
OrganizationSchema.index({ name: 'text', legal_name: 'text' });
OrganizationSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Organization = (0, mongoose_1.model)('Organization', OrganizationSchema);
//# sourceMappingURL=Organization.js.map