"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RemoteConfig = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const remoteConfigSchema = new mongoose_1.default.Schema({
    version: { type: String, required: true, default: 'v1' },
    featureFlags: {
        maintenance_mode: { type: Boolean, default: false },
        enable_ai_assistant: { type: Boolean, default: true },
        enable_ocr_scanning: { type: Boolean, default: false },
        enable_referral_rewards: { type: Boolean, default: true },
        enable_promotional_banners: { type: Boolean, default: false },
        enable_notifications: { type: Boolean, default: true },
    },
    dynamicConfig: {
        banner_text: { type: String, default: 'Welcome to DICE by Sanyog' },
        banner_color: { type: String, default: '#6C63FF' },
        referral_reward_value: { type: Number, default: 200 },
        announcement_title: { type: String, default: '' },
        announcement_body: { type: String, default: '' },
    }
}, { timestamps: true });
// Ensure there is only ever one document for global config
remoteConfigSchema.statics.getGlobalConfig = async function () {
    let config = await this.findOne();
    if (!config) {
        config = await this.create({ version: 'v1' });
    }
    return config;
};
exports.RemoteConfig = mongoose_1.default.model('RemoteConfig', remoteConfigSchema);
//# sourceMappingURL=RemoteConfig.js.map