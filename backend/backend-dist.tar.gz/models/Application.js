"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Application = exports.ALLOWED_TRANSITIONS = void 0;
const mongoose_1 = require("mongoose");
exports.ALLOWED_TRANSITIONS = {
    draft: ['submitted', 'cancelled'],
    submitted: ['docs_review', 'cancelled'],
    docs_review: ['tech_review', 'docs_required', 'rejected', 'on_hold'],
    docs_required: ['docs_review', 'cancelled'],
    tech_review: ['testing', 'approval_pending', 'docs_required', 'rejected'],
    testing: ['approval_pending', 'docs_required', 'rejected'],
    approval_pending: ['approved', 'rejected', 'on_hold'],
    approved: ['cert_issued'],
    cert_issued: [], // terminal — issue Certification doc
    rejected: [], // terminal
    on_hold: ['docs_review', 'tech_review', 'cancelled'],
    cancelled: [], // terminal
};
const StatusTransitionSchema = new mongoose_1.Schema({
    from: { type: String, required: true },
    to: { type: String, required: true },
    by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    at: { type: Date, default: Date.now },
    reason: String,
    comment: String,
}, { _id: false });
const ApplicationSchema = new mongoose_1.Schema({
    application_number: { type: String, required: true, unique: true, index: true },
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    product_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Product', required: true, index: true },
    workflow_id: { type: String, required: true, index: true },
    cert_type: { type: String, required: true, index: true },
    status: {
        type: String,
        enum: Object.keys(exports.ALLOWED_TRANSITIONS),
        default: 'draft',
        index: true,
    },
    current_stage: String,
    status_history: { type: [StatusTransitionSchema], default: [] },
    created_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    assignees: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'User', index: true }],
    primary_assignee: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User' },
    documents: [
        {
            document_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Document', required: true },
            required_for_stage: { type: String, required: true },
            label: { type: String, required: true },
            added_at: { type: Date, default: Date.now },
            _id: false,
        },
    ],
    submitted_at: Date,
    estimated_completion_at: Date,
    completed_at: Date,
    due_at: { type: Date, index: true },
    fee: {
        base_inr: { type: Number, default: 0 },
        expedited: { type: Boolean, default: false },
        paid: { type: Boolean, default: false },
        payment_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Payment' },
    },
    priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium', index: true },
    tags: { type: [String], default: [] },
    external_ref: {
        body: String,
        reference_number: String,
        portal_url: String,
    },
    progress_percent: { type: Number, default: 0 },
    days_in_current_stage: { type: Number, default: 0 },
    is_overdue: { type: Boolean, default: false, index: true },
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
// ─── Indexes (match dashboard/list query patterns) ───
ApplicationSchema.index({ org_id: 1, status: 1, created_at: -1 });
ApplicationSchema.index({ assignees: 1, status: 1, due_at: 1 }); // "my tasks, sorted by deadline"
ApplicationSchema.index({ org_id: 1, cert_type: 1, status: 1 });
ApplicationSchema.index({ is_overdue: 1, status: 1 }); // overdue dashboard
ApplicationSchema.index({ tags: 1 });
// ─── Methods ───
ApplicationSchema.methods.canTransitionTo = function (newStatus) {
    return exports.ALLOWED_TRANSITIONS[this.status].includes(newStatus);
};
ApplicationSchema.methods.transitionTo = function (newStatus, by, opts = {}) {
    if (!this.canTransitionTo(newStatus)) {
        throw new Error(`Invalid transition ${this.status} → ${newStatus}`);
    }
    this.status_history.push({
        from: this.status,
        to: newStatus,
        by,
        at: new Date(),
        reason: opts.reason,
        comment: opts.comment,
    });
    this.status = newStatus;
    if (newStatus === 'submitted' && !this.submitted_at)
        this.submitted_at = new Date();
    if (['cert_issued', 'rejected', 'cancelled'].includes(newStatus))
        this.completed_at = new Date();
};
ApplicationSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Application = (0, mongoose_1.model)('Application', ApplicationSchema);
//# sourceMappingURL=Application.js.map