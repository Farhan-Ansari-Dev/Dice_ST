import mongoose, { Document } from 'mongoose';
export interface IInsight extends Document {
    title: string;
    summary: string;
    category: string;
    country: string;
    source: string;
    link: string;
    tags: string[];
    relevanceScore: number;
    publishedAt: Date;
    createdAt: Date;
}
export declare const Insight: mongoose.Model<any, {}, {}, {}, any, any, any>;
//# sourceMappingURL=Insight.d.ts.map