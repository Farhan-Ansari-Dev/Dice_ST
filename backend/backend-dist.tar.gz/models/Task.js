"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Task = void 0;
const mongoose_1 = require("mongoose");
const TaskSchema = new mongoose_1.Schema({
    org_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Organization', required: true, index: true },
    application_id: { type: mongoose_1.Schema.Types.ObjectId, ref: 'Application', index: true },
    title: { type: String, required: true, trim: true },
    description: String,
    assigned_to: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    assigned_by: { type: mongoose_1.Schema.Types.ObjectId, ref: 'User', required: true },
    priority: { type: String, enum: ['low', 'medium', 'high', 'urgent'], default: 'medium', index: true },
    status: { type: String, enum: ['todo', 'in_progress', 'blocked', 'done', 'cancelled'], default: 'todo', index: true },
    due_at: { type: Date, index: true },
    completed_at: Date,
    checklist: [{
            item: { type: String, required: true },
            done: { type: Boolean, default: false },
            done_at: Date,
            _id: false,
        }],
    attachments: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'Document' }],
    deleted_at: { type: Date, index: true },
}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });
TaskSchema.index({ assigned_to: 1, status: 1, due_at: 1 });
TaskSchema.index({ org_id: 1, status: 1, created_at: -1 });
TaskSchema.pre(/^find/, function () {
    if (!this.getOptions().includeDeleted)
        this.where({ deleted_at: null });
});
exports.Task = (0, mongoose_1.model)('Task', TaskSchema);
//# sourceMappingURL=Task.js.map