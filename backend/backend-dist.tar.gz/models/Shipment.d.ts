import mongoose, { Document } from 'mongoose';
export interface IShipment extends Document {
    shipment_number: string;
    client_id: mongoose.Types.ObjectId;
    origin: string;
    destination: string;
    status: 'pending' | 'in_transit' | 'customs_clearance' | 'delivered' | 'held' | 'cancelled';
    expected_delivery?: Date;
    documents: Array<{
        name: string;
        url: string;
        uploaded_at: Date;
    }>;
    deleted_at?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Shipment: mongoose.Model<IShipment, {}, {}, {}, mongoose.Document<unknown, {}, IShipment, {}, mongoose.DefaultSchemaOptions> & IShipment & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IShipment>;
//# sourceMappingURL=Shipment.d.ts.map