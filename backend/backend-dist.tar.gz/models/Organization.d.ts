import { Document, Types } from 'mongoose';
export interface IOrganization extends Document {
    name: string;
    legal_name?: string;
    type: 'manufacturer' | 'importer' | 'consultant' | 'cb' | 'lab' | 'other';
    gst_number?: string;
    pan_number?: string;
    iec_code?: string;
    cin?: string;
    address: {
        line1?: string;
        line2?: string;
        city?: string;
        state?: string;
        country_code: string;
        pincode?: string;
    };
    contact: {
        email?: string;
        phone?: string;
        website?: string;
    };
    branding?: {
        logo_url?: string;
        primary_color?: string;
    };
    subscription: {
        tier: 'free' | 'starter' | 'pro' | 'enterprise';
        seats: number;
        trial_ends_at?: Date;
        renewed_at?: Date;
        razorpay_customer_id?: string;
        razorpay_subscription_id?: string;
    };
    owner_user_id: Types.ObjectId;
    settings: {
        require_2fa_for_admins: boolean;
        allowed_cert_types: string[];
        notification_preferences: Record<string, boolean>;
    };
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Organization: import("mongoose").Model<IOrganization, {}, {}, {}, Document<unknown, {}, IOrganization, {}, import("mongoose").DefaultSchemaOptions> & IOrganization & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IOrganization>;
//# sourceMappingURL=Organization.d.ts.map