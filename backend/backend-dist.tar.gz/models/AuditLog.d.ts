import { Document as MongooseDoc, Types } from 'mongoose';
import mongoose from 'mongoose';
export type AuditAction = 'created' | 'updated' | 'deleted' | 'viewed' | 'downloaded' | 'logged_in' | 'logged_out' | 'failed_login' | 'status_changed' | 'assigned' | 'unassigned' | 'document_uploaded' | 'document_replaced' | 'document_archived' | 'payment_received' | 'cert_issued' | 'cert_revoked' | 'consent_given' | 'consent_revoked' | 'data_exported' | 'data_deletion_requested';
export interface IAuditLog extends MongooseDoc {
    ts: Date;
    meta: {
        actor: Types.ObjectId | null;
        actor_type: 'user' | 'system' | 'cron';
        org_id?: Types.ObjectId;
        resource_type: string;
        resource_id?: Types.ObjectId;
        action: AuditAction;
        ip?: string;
        request_id?: string;
    };
    before?: any;
    after?: any;
    user_agent?: string;
    notes?: string;
}
export declare const AuditLog: mongoose.Model<IAuditLog, {}, {}, {}, MongooseDoc<unknown, {}, IAuditLog, {}, mongoose.DefaultSchemaOptions> & IAuditLog & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IAuditLog>;
/**
 * Helper to record audit events. Always async, never blocking.
 *
 *   await audit({
 *     actor: req.user._id,
 *     org_id: req.user.org_id,
 *     resource_type: 'application',
 *     resource_id: app._id,
 *     action: 'status_changed',
 *     before: { status: 'docs_review' },
 *     after:  { status: 'tech_review' },
 *     ip: req.ip,
 *     request_id: req.id,
 *   });
 */
export declare function audit(input: {
    actor?: Types.ObjectId | null;
    actor_type?: 'user' | 'system' | 'cron';
    org_id?: Types.ObjectId;
    resource_type: string;
    resource_id?: Types.ObjectId;
    action: AuditAction;
    before?: any;
    after?: any;
    ip?: string;
    user_agent?: string;
    request_id?: string;
    notes?: string;
}): Promise<void>;
//# sourceMappingURL=AuditLog.d.ts.map