import mongoose, { Document } from 'mongoose';
export interface IProductCategory extends Document {
    categoryName: string;
    keywords: string[];
    description?: string;
    industry: string;
    createdAt: Date;
    updatedAt: Date;
}
declare const _default: mongoose.Model<IProductCategory, {}, {}, {}, mongoose.Document<unknown, {}, IProductCategory, {}, mongoose.DefaultSchemaOptions> & IProductCategory & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IProductCategory>;
export default _default;
//# sourceMappingURL=ProductCategory.d.ts.map