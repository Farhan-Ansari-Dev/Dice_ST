import { Document, Types } from 'mongoose';
/**
 * A Product is the THING being certified.
 * One product can have multiple Applications across different cert types.
 */
export interface IProduct extends Document {
    org_id: Types.ObjectId;
    name: string;
    brand?: string;
    model_number?: string;
    category: string;
    sub_category?: string;
    hsn_code?: string;
    description?: string;
    specifications?: Record<string, any>;
    images: string[];
    manufacturer?: {
        name: string;
        country_code: string;
        factory_address?: string;
    };
    is_imported: boolean;
    countries_of_sale: string[];
    active: boolean;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Product: import("mongoose").Model<IProduct, {}, {}, {}, Document<unknown, {}, IProduct, {}, import("mongoose").DefaultSchemaOptions> & IProduct & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IProduct>;
//# sourceMappingURL=Product.d.ts.map