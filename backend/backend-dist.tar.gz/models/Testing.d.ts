import mongoose, { Document } from 'mongoose';
export interface ITesting extends Document {
    sample_id: string;
    client_id: mongoose.Types.ObjectId;
    product_name: string;
    standard: string;
    lab_name: string;
    expected_completion?: Date;
    status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'cancelled';
    report_file?: string;
    deleted_at?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const Testing: mongoose.Model<ITesting, {}, {}, {}, mongoose.Document<unknown, {}, ITesting, {}, mongoose.DefaultSchemaOptions> & ITesting & Required<{
    _id: mongoose.Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, ITesting>;
//# sourceMappingURL=Testing.d.ts.map