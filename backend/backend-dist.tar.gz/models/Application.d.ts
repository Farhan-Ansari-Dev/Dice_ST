import { Document, Types } from 'mongoose';
export type ApplicationStatus = 'draft' | 'submitted' | 'docs_review' | 'docs_required' | 'tech_review' | 'testing' | 'approval_pending' | 'approved' | 'rejected' | 'on_hold' | 'cert_issued' | 'cancelled';
export declare const ALLOWED_TRANSITIONS: Record<ApplicationStatus, ApplicationStatus[]>;
export interface IStatusTransition {
    from: ApplicationStatus;
    to: ApplicationStatus;
    by: Types.ObjectId;
    at: Date;
    reason?: string;
    comment?: string;
}
export interface IApplication extends Document {
    application_number: string;
    org_id: Types.ObjectId;
    product_id: Types.ObjectId;
    workflow_id: string;
    cert_type: string;
    status: ApplicationStatus;
    current_stage?: string;
    status_history: IStatusTransition[];
    created_by: Types.ObjectId;
    assignees: Types.ObjectId[];
    primary_assignee?: Types.ObjectId;
    documents: Array<{
        document_id: Types.ObjectId;
        required_for_stage: string;
        label: string;
        added_at: Date;
    }>;
    submitted_at?: Date;
    estimated_completion_at?: Date;
    completed_at?: Date;
    due_at?: Date;
    fee: {
        base_inr: number;
        expedited: boolean;
        paid: boolean;
        payment_id?: Types.ObjectId;
    };
    priority: 'low' | 'medium' | 'high' | 'urgent';
    tags: string[];
    external_ref?: {
        body: string;
        reference_number?: string;
        portal_url?: string;
    };
    progress_percent: number;
    days_in_current_stage: number;
    is_overdue: boolean;
    deleted_at?: Date;
    created_at: Date;
    updated_at: Date;
}
export declare const Application: import("mongoose").Model<IApplication, {}, {}, {}, Document<unknown, {}, IApplication, {}, import("mongoose").DefaultSchemaOptions> & IApplication & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
} & {
    id: string;
}, any, IApplication>;
//# sourceMappingURL=Application.d.ts.map