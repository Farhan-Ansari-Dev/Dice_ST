"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const marketAccessController_1 = require("../controllers/marketAccessController");
const router = (0, express_1.Router)();
router.get('/product-categories', marketAccessController_1.getProductCategories);
router.get('/certifications', marketAccessController_1.getCertifications);
router.get('/countries', marketAccessController_1.getCountries);
router.get('/rules', marketAccessController_1.getMarketRules);
// Support both GET and POST for checking access, as requested
router.post('/check', marketAccessController_1.checkMarketAccess);
router.get('/check', marketAccessController_1.checkMarketAccess);
exports.default = router;
//# sourceMappingURL=marketAccessRoutes.js.map