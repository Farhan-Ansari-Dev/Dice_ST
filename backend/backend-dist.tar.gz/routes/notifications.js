"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET /notifications — list user's notifications (paginated)
router.get('/', wrap(async (req, res) => {
    const { page = 1, limit = 20, unread } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const conditions = ['user_id = $1'];
    const params = [req.user.id];
    if (unread === 'true') {
        conditions.push('is_read = false');
    }
    const where = conditions.join(' AND ');
    const [result, countResult] = await Promise.all([
        (0, database_1.query)(`SELECT * FROM notifications WHERE ${where} ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, Number(limit), offset]),
        (0, database_1.query)(`SELECT COUNT(*) FROM notifications WHERE ${where}`, params),
    ]);
    const total = parseInt(countResult.rows[0].count);
    (0, response_1.sendPaginated)(res, result.rows, total, Number(page), Number(limit));
}));
// PUT /notifications/read-all — mark all as read (must be before /:id route)
router.put('/read-all', wrap(async (req, res) => {
    await (0, database_1.query)('UPDATE notifications SET is_read = true WHERE user_id = $1 AND is_read = false', [req.user.id]);
    (0, response_1.sendSuccess)(res, null, 'All notifications marked as read');
}));
// PUT /notifications/:id/read — mark single notification as read
router.put('/:id/read', wrap(async (req, res) => {
    const result = await (0, database_1.query)('UPDATE notifications SET is_read = true WHERE id = $1 AND user_id = $2 RETURNING *', [req.params.id, req.user.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Notification not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Notification marked as read');
}));
// DELETE /notifications/:id
router.delete('/:id', wrap(async (req, res) => {
    const result = await (0, database_1.query)('DELETE FROM notifications WHERE id = $1 AND user_id = $2 RETURNING id', [req.params.id, req.user.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Notification not found', 404);
    (0, response_1.sendSuccess)(res, null, 'Notification deleted');
}));
// POST /push-tokens — register or update push token
router.post('/push-tokens', wrap(async (req, res) => {
    const { token, platform = 'ios' } = req.body;
    if (!token)
        throw new errorHandler_1.AppError('Token is required', 400);
    await (0, database_1.query)(`INSERT INTO push_tokens (user_id, token, platform, is_active)
     VALUES ($1, $2, $3, true)
     ON CONFLICT (token) DO UPDATE SET user_id = $1, platform = $3, is_active = true`, [req.user.id, token, platform]);
    (0, response_1.sendSuccess)(res, null, 'Push token registered', 201);
}));
// DELETE /push-tokens/:token — unregister push token
router.delete('/push-tokens/:token', wrap(async (req, res) => {
    await (0, database_1.query)('UPDATE push_tokens SET is_active = false WHERE token = $1 AND user_id = $2', [decodeURIComponent(req.params.token), req.user.id]);
    (0, response_1.sendSuccess)(res, null, 'Push token unregistered');
}));
exports.default = router;
//# sourceMappingURL=notifications.js.map