"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET / — list shipments
router.get('/', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const { status, page = 1, limit = 20 } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const conditions = [];
    const params = [];
    if (!isAdmin) {
        params.push(req.user.id);
        conditions.push(`s.user_id = $${params.length}`);
    }
    if (status) {
        params.push(status);
        conditions.push(`s.status = $${params.length}`);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const result = await (0, database_1.query)(`SELECT s.*, u.name as client_name
     FROM shipments s
     LEFT JOIN users u ON s.user_id = u.id
     ${where}
     ORDER BY s.created_at DESC
     LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, Number(limit), offset]);
    (0, response_1.sendSuccess)(res, result.rows);
}));
// GET /:id — shipment details with events
router.get('/:id', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const params = [req.params.id];
    let where = 's.id = $1';
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND s.user_id = $2`;
    }
    const result = await (0, database_1.query)(`SELECT s.*, u.name as client_name, u.email as client_email
     FROM shipments s
     LEFT JOIN users u ON s.user_id = u.id
     WHERE ${where}`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Shipment not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0]);
}));
// POST / — create shipment
router.post('/', wrap(async (req, res) => {
    const { tracking_number, carrier, origin_country, destination_country, product_description, hs_code, estimated_arrival, } = req.body;
    if (!tracking_number)
        throw new errorHandler_1.AppError('tracking_number is required', 400);
    const result = await (0, database_1.query)(`INSERT INTO shipments
       (user_id, tracking_number, carrier, origin_country, destination_country,
        product_description, hs_code, estimated_arrival)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`, [
        req.user.id,
        tracking_number,
        carrier ?? null,
        origin_country ?? null,
        destination_country ?? null,
        product_description ?? null,
        hs_code ?? null,
        estimated_arrival ?? null,
    ]);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Shipment created', 201);
}));
// PUT /:id/status — update shipment status
router.put('/:id/status', wrap(async (req, res) => {
    const { status, customs_status, actual_arrival } = req.body;
    if (!status)
        throw new errorHandler_1.AppError('status is required', 400);
    const isAdmin = req.user.role === 'admin';
    const params = [status];
    const setClauses = ['status = $1'];
    if (customs_status !== undefined) {
        params.push(customs_status);
        setClauses.push(`customs_status = $${params.length}`);
    }
    if (actual_arrival !== undefined) {
        params.push(actual_arrival);
        setClauses.push(`actual_arrival = $${params.length}`);
    }
    params.push(req.params.id);
    let where = `id = $${params.length}`;
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND user_id = $${params.length}`;
    }
    const result = await (0, database_1.query)(`UPDATE shipments SET ${setClauses.join(', ')}, updated_at = NOW() WHERE ${where} RETURNING *`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Shipment not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Shipment status updated');
}));
// POST /:id/track — add tracking event
router.post('/:id/track', wrap(async (req, res) => {
    const { location, status, description, timestamp } = req.body;
    if (!status)
        throw new errorHandler_1.AppError('status is required for tracking event', 400);
    const isAdmin = req.user.role === 'admin';
    const params = [req.params.id];
    let where = 'id = $1';
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND user_id = $2`;
    }
    const shipResult = await (0, database_1.query)(`SELECT tracking_events FROM shipments WHERE ${where}`, params);
    if (!shipResult.rows.length)
        throw new errorHandler_1.AppError('Shipment not found', 404);
    const existingEvents = shipResult.rows[0].tracking_events ?? [];
    const newEvent = {
        id: Date.now(),
        location: location ?? null,
        status,
        description: description ?? null,
        timestamp: timestamp ?? new Date().toISOString(),
    };
    const updatedEvents = [...existingEvents, newEvent];
    const updateResult = await (0, database_1.query)(`UPDATE shipments SET tracking_events = $1, status = $2, updated_at = NOW() WHERE id = $3 RETURNING *`, [JSON.stringify(updatedEvents), status, req.params.id]);
    (0, response_1.sendSuccess)(res, updateResult.rows[0], 'Tracking event added');
}));
exports.default = router;
//# sourceMappingURL=shipments.js.map