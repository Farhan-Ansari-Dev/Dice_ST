"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
const generateCode = (userId) => {
    const base = userId.replace(/-/g, '').slice(0, 6).toUpperCase();
    const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
    return `DICE${base}${suffix}`.slice(0, 16);
};
// GET /my-code — get user's referral code (create if doesn't exist)
router.get('/my-code', wrap(async (req, res) => {
    const result = await (0, database_1.query)('SELECT * FROM referrals WHERE referrer_id = $1 AND referred_email IS NULL LIMIT 1', [req.user.id]);
    if (result.rows.length) {
        (0, response_1.sendSuccess)(res, result.rows[0]);
        return;
    }
    // Create new referral code for this user
    let code;
    let attempts = 0;
    do {
        code = generateCode(req.user.id);
        const check = await (0, database_1.query)('SELECT id FROM referrals WHERE referral_code = $1', [code]);
        if (!check.rows.length)
            break;
        attempts++;
    } while (attempts < 5);
    const newRef = await (0, database_1.query)(`INSERT INTO referrals (referrer_id, referral_code, status)
     VALUES ($1, $2, 'active') RETURNING *`, [req.user.id, code]);
    (0, response_1.sendSuccess)(res, newRef.rows[0], 'Referral code created', 201);
}));
// GET /stats — referral stats
router.get('/stats', wrap(async (req, res) => {
    const result = await (0, database_1.query)(`SELECT
       COUNT(*) FILTER (WHERE referred_user_id IS NOT NULL) as total_referred,
       COUNT(*) FILTER (WHERE status = 'rewarded') as rewarded_count,
       COALESCE(SUM(reward_amount) FILTER (WHERE status = 'rewarded'), 0) as total_earned,
       COUNT(*) FILTER (WHERE status = 'pending' AND referred_email IS NOT NULL) as pending_count
     FROM referrals
     WHERE referrer_id = $1`, [req.user.id]);
    const referrals = await (0, database_1.query)(`SELECT r.id, r.referred_email, r.status, r.reward_amount, r.created_at,
            u.name as referred_user_name
     FROM referrals r
     LEFT JOIN users u ON r.referred_user_id = u.id
     WHERE r.referrer_id = $1 AND r.referred_email IS NOT NULL
     ORDER BY r.created_at DESC
     LIMIT 20`, [req.user.id]);
    (0, response_1.sendSuccess)(res, {
        stats: result.rows[0],
        referrals: referrals.rows,
    });
}));
// POST /apply — apply a referral code during signup
router.post('/apply', wrap(async (req, res) => {
    const { code } = req.body;
    if (!code)
        throw new errorHandler_1.AppError('Referral code is required', 400);
    const refResult = await (0, database_1.query)('SELECT * FROM referrals WHERE referral_code = $1 AND referred_email IS NULL', [code.toUpperCase()]);
    if (!refResult.rows.length)
        throw new errorHandler_1.AppError('Invalid or already used referral code', 400);
    const ref = refResult.rows[0];
    // Prevent self-referral
    if (ref.referrer_id === req.user.id)
        throw new errorHandler_1.AppError('You cannot use your own referral code', 400);
    // Check if user has already applied a code
    const existing = await (0, database_1.query)('SELECT id FROM referrals WHERE referred_user_id = $1', [req.user.id]);
    if (existing.rows.length)
        throw new errorHandler_1.AppError('You have already used a referral code', 400);
    await (0, database_1.query)(`UPDATE referrals
     SET referred_user_id = $1, referred_email = $2, status = 'completed'
     WHERE id = $3`, [req.user.id, req.user.email, ref.id]);
    (0, response_1.sendSuccess)(res, null, 'Referral code applied successfully');
}));
exports.default = router;
//# sourceMappingURL=referrals.js.map