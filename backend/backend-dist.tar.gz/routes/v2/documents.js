"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Document routes — S3 presigned uploads + immutable versioning.
 */
const express_1 = require("express");
const mongoose_1 = require("mongoose");
const models_1 = require("../../models");
const documentService_1 = require("../../services/documentService");
const authMongo_1 = require("../../middleware/authMongo");
const router = (0, express_1.Router)();
router.use(authMongo_1.authenticate);
// Step 1: Get presigned URL for direct browser-to-S3 upload
router.post('/presign', async (req, res) => {
    const { filename, mime_type, size_bytes, sha256, doc_type, document_id } = req.body;
    if (!filename || !mime_type || !size_bytes || !sha256 || !doc_type) {
        return res.status(400).json({ error: 'missing_fields' });
    }
    try {
        const result = await documentService_1.documentService.presignUpload({
            org_id: req.user.org_id,
            user_id: req.user._id,
            filename,
            mime_type,
            size_bytes,
            sha256,
            doc_type,
            document_id: document_id ? new mongoose_1.Types.ObjectId(document_id) : undefined,
        });
        return res.json({ data: result });
    }
    catch (err) {
        return res.status(400).json({ error: err.message });
    }
});
// Step 2: After client uploads to S3, finalize the metadata
router.post('/finalize', async (req, res) => {
    const { s3_key, name, doc_type, mime_type, size_bytes, sha256, document_id, application_id, change_reason, description, tags } = req.body;
    try {
        const { document, version } = await documentService_1.documentService.finalizeUpload({
            org_id: req.user.org_id,
            user_id: req.user._id,
            s3_key, name, doc_type, mime_type, size_bytes, sha256,
            document_id: document_id ? new mongoose_1.Types.ObjectId(document_id) : undefined,
            application_id: application_id ? new mongoose_1.Types.ObjectId(application_id) : undefined,
            change_reason, description, tags,
            ip: req.ip,
            user_agent: req.get('user-agent'),
        });
        return res.status(201).json({ data: { document, version } });
    }
    catch (err) {
        return res.status(400).json({ error: err.message });
    }
});
// List documents
router.get('/', async (req, res) => {
    const { application_id, doc_type, q, page = '1', limit = '20' } = req.query;
    const filter = { org_id: req.user.org_id };
    if (application_id)
        filter.application_ids = application_id;
    if (doc_type)
        filter.doc_type = doc_type;
    if (q)
        filter.$text = { $search: q };
    const pageN = parseInt(page, 10);
    const limitN = Math.min(parseInt(limit, 10), 100);
    const [items, total] = await Promise.all([
        models_1.Document.find(filter)
            .sort({ created_at: -1 })
            .skip((pageN - 1) * limitN)
            .limit(limitN)
            .populate('current_version_id')
            .populate('uploaded_by', 'name email')
            .lean(),
        models_1.Document.countDocuments(filter),
    ]);
    return res.json({
        data: items,
        pagination: { page: pageN, limit: limitN, total },
    });
});
// Get a download URL (presigned, short-lived)
router.get('/:id/download', async (req, res) => {
    const { version } = req.query;
    const doc = await models_1.Document.findOne({ _id: req.params.id, org_id: req.user.org_id });
    if (!doc)
        return res.status(404).json({ error: 'not_found' });
    const url = await documentService_1.documentService.getDownloadUrl(doc._id, version ? parseInt(version, 10) : undefined, req.user._id);
    return res.json({ data: { url, expires_in: 900 } });
});
// List all versions of a document
router.get('/:id/versions', async (req, res) => {
    const doc = await models_1.Document.findOne({ _id: req.params.id, org_id: req.user.org_id });
    if (!doc)
        return res.status(404).json({ error: 'not_found' });
    const versions = await documentService_1.documentService.listVersions(doc._id);
    return res.json({ data: versions });
});
exports.default = router;
//# sourceMappingURL=documents.js.map