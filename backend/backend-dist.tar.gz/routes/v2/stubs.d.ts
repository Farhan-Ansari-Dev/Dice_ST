export declare const certificationsRouter: import("express-serve-static-core").Router;
export declare const insightsRouter: import("express-serve-static-core").Router;
export declare const shipmentsRouter: import("express-serve-static-core").Router;
export declare const paymentsRouter: import("express-serve-static-core").Router;
export declare const analyticsRouter: import("express-serve-static-core").Router;
export declare const aiRouter: import("express-serve-static-core").Router;
export declare const bookmarksRouter: import("express-serve-static-core").Router;
export declare const referralsRouter: import("express-serve-static-core").Router;
export declare const templatesRouter: import("express-serve-static-core").Router;
export declare const teamTasksRouter: import("express-serve-static-core").Router;
export declare const adminRouter: import("express-serve-static-core").Router;
export declare const usersRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=stubs.d.ts.map