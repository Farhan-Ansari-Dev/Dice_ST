"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMongo_1 = require("../../middleware/authMongo");
const Certification_1 = require("../../models/Certification");
const response_1 = require("../../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.get('/', authMongo_1.authenticate, wrap(async (req, res) => {
    const query = {};
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        query.org_id = req.user.org_id;
    }
    if (req.query.showDeleted !== 'true') {
        query.deleted_at = { $exists: false };
    }
    const certs = await Certification_1.Certification.find(query)
        .populate('org_id', 'name')
        .populate('product_id', 'name')
        .sort({ created_at: -1 })
        .lean();
    return (0, response_1.sendSuccess)(res, certs);
}));
router.get('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    const cert = await Certification_1.Certification.findOne({ _id: req.params.id, org_id: req.user.org_id }).lean();
    if (!cert)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, cert);
}));
router.post('/', authMongo_1.authenticate, wrap(async (req, res) => {
    const cert = new Certification_1.Certification({
        ...req.body,
        org_id: req.user.org_id,
        created_at: new Date(),
        updated_at: new Date()
    });
    await cert.save();
    return (0, response_1.sendSuccess)(res, cert, 'Created successfully', 201);
}));
router.put('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    const cert = await Certification_1.Certification.findOneAndUpdate({ _id: req.params.id, org_id: req.user.org_id }, { ...req.body, updated_at: new Date() }, { new: true });
    if (!cert)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, cert, 'Updated successfully');
}));
router.delete('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    const cert = await Certification_1.Certification.findOneAndUpdate({ _id: req.params.id, org_id: req.user.org_id }, { deleted_at: new Date(), updated_at: new Date() }, { new: true });
    if (!cert)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, cert, 'Deleted successfully');
}));
router.post('/:id/restore', authMongo_1.authenticate, wrap(async (req, res) => {
    const cert = await Certification_1.Certification.findOneAndUpdate({ _id: req.params.id, org_id: req.user.org_id }, { $unset: { deleted_at: 1 }, updated_at: new Date() }, { new: true });
    if (!cert)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, cert, 'Restored successfully');
}));
exports.default = router;
//# sourceMappingURL=certifications.js.map