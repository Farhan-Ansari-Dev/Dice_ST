"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Notification routes — list, mark-read, register push tokens, web push subs.
 */
const express_1 = require("express");
const expo_server_sdk_1 = require("expo-server-sdk");
const models_1 = require("../../models");
const authMongo_1 = require("../../middleware/authMongo");
const router = (0, express_1.Router)();
router.use(authMongo_1.authenticate);
// ─── Inbox ─────────────────────────────────────────────────────
// GET /notifications?unread=true&limit=50
router.get('/', async (req, res) => {
    const { unread, limit = '50' } = req.query;
    const filter = { user_id: req.user._id };
    if (unread === 'true')
        filter.read_at = { $exists: false };
    const items = await models_1.Notification.find(filter)
        .sort({ created_at: -1 })
        .limit(parseInt(limit, 10))
        .lean();
    const unreadCount = await models_1.Notification.countDocuments({
        user_id: req.user._id,
        read_at: { $exists: false },
    });
    return res.json({ data: items, unread_count: unreadCount });
});
// PUT /notifications/:id/read
router.put('/:id/read', async (req, res) => {
    await models_1.Notification.updateOne({ _id: req.params.id, user_id: req.user._id }, { $set: { read_at: new Date() } });
    return res.json({ success: true });
});
// PUT /notifications/read-all
router.put('/read-all', async (req, res) => {
    await models_1.Notification.updateMany({ user_id: req.user._id, read_at: { $exists: false } }, { $set: { read_at: new Date() } });
    return res.json({ success: true });
});
// DELETE /notifications/:id
router.delete('/:id', async (req, res) => {
    await models_1.Notification.deleteOne({ _id: req.params.id, user_id: req.user._id });
    return res.json({ success: true });
});
// ─── Mobile push tokens (Expo) ─────────────────────────────────
// POST /notifications/push-tokens
router.post('/push-tokens', async (req, res) => {
    const { token, platform } = req.body;
    if (!token)
        return res.status(400).json({ error: 'token required' });
    if (!expo_server_sdk_1.Expo.isExpoPushToken(token)) {
        return res.status(400).json({ error: 'invalid expo token format' });
    }
    await models_1.User.updateOne({ _id: req.user._id }, { $addToSet: { expo_push_tokens: token } });
    return res.json({ success: true, platform });
});
// DELETE /notifications/push-tokens/:token
router.delete('/push-tokens/:token', async (req, res) => {
    await models_1.User.updateOne({ _id: req.user._id }, { $pull: { expo_push_tokens: req.params.token } });
    return res.json({ success: true });
});
// ─── Web Push subscriptions (VAPID) ────────────────────────────
// POST /notifications/webpush-subscriptions
router.post('/webpush-subscriptions', async (req, res) => {
    const { endpoint, keys } = req.body;
    if (!endpoint || !keys?.p256dh || !keys?.auth) {
        return res.status(400).json({ error: 'invalid_subscription' });
    }
    await models_1.User.updateOne({ _id: req.user._id, 'webpush_subscriptions.endpoint': { $ne: endpoint } }, {
        $addToSet: {
            webpush_subscriptions: { endpoint, keys, created_at: new Date() },
        },
    });
    return res.json({ success: true });
});
// DELETE /notifications/webpush-subscriptions
router.delete('/webpush-subscriptions', async (req, res) => {
    const { endpoint } = req.body;
    if (!endpoint)
        return res.status(400).json({ error: 'endpoint required' });
    await models_1.User.updateOne({ _id: req.user._id }, { $pull: { webpush_subscriptions: { endpoint } } });
    return res.json({ success: true });
});
// ─── Notification preferences ──────────────────────────────────
// GET / PUT /notifications/preferences
router.get('/preferences', async (req, res) => {
    return res.json({ data: req.user.notification_preferences ?? {} });
});
router.put('/preferences', async (req, res) => {
    await models_1.User.updateOne({ _id: req.user._id }, { $set: { notification_preferences: req.body } });
    return res.json({ success: true });
});
// ─── Public VAPID key (for web frontend to subscribe) ──────────
router.get('/vapid-public-key', (_req, res) => {
    res.json({ key: process.env.VAPID_PUBLIC_KEY ?? null });
});
exports.default = router;
//# sourceMappingURL=notifications.js.map