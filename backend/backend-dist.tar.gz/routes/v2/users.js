"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMongo_1 = require("../../middleware/authMongo");
const User_1 = require("../../models/User");
const response_1 = require("../../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.get('/', authMongo_1.authenticate, wrap(async (req, res) => {
    const query = {};
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        query.org_id = req.user.org_id;
    }
    if (req.query.role) {
        query.role = req.query.role;
    }
    if (req.query.showDeleted !== 'true') {
        query.deleted_at = { $exists: false };
    }
    const users = await User_1.User.find(query)
        .select('-password_hash -otp_hash -totp_secret')
        .sort({ created_at: -1 })
        .lean();
    return (0, response_1.sendSuccess)(res, users);
}));
router.post('/', authMongo_1.authenticate, wrap(async (req, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        return (0, response_1.sendError)(res, 'Unauthorized', 403);
    }
    const user = new User_1.User({
        ...req.body,
        org_id: req.body.org_id || req.user.org_id,
        created_at: new Date(),
        updated_at: new Date()
    });
    await user.save();
    const userObj = user.toObject();
    delete userObj.password_hash;
    delete userObj.otp_hash;
    return (0, response_1.sendSuccess)(res, userObj, 'Created successfully', 201);
}));
router.put('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        return (0, response_1.sendError)(res, 'Unauthorized', 403);
    }
    const user = await User_1.User.findByIdAndUpdate(req.params.id, { ...req.body, updated_at: new Date() }, { new: true }).select('-password_hash -otp_hash -totp_secret');
    if (!user)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, user, 'Updated successfully');
}));
router.delete('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        return (0, response_1.sendError)(res, 'Unauthorized', 403);
    }
    const user = await User_1.User.findByIdAndUpdate(req.params.id, { deleted_at: new Date(), updated_at: new Date() }, { new: true }).select('-password_hash -otp_hash -totp_secret');
    if (!user)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, user, 'Deleted successfully');
}));
router.post('/:id/restore', authMongo_1.authenticate, wrap(async (req, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        return (0, response_1.sendError)(res, 'Unauthorized', 403);
    }
    const user = await User_1.User.findByIdAndUpdate(req.params.id, { $unset: { deleted_at: 1 }, updated_at: new Date() }, { new: true }).select('-password_hash -otp_hash -totp_secret');
    if (!user)
        return (0, response_1.sendError)(res, 'Not found', 404);
    return (0, response_1.sendSuccess)(res, user, 'Restored successfully');
}));
exports.default = router;
//# sourceMappingURL=users.js.map