"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * v2 router — mounts all MongoDB-backed routes.
 * Mount at: app.use('/api/v1', v2Routes)   ← keeps the same /api/v1 prefix
 *           so mobile/admin clients don't need URL changes.
 */
const express_1 = require("express");
const auth_1 = __importDefault(require("./auth"));
const applications_1 = __importDefault(require("./applications"));
const documents_1 = __importDefault(require("./documents"));
const notifications_1 = __importDefault(require("./notifications"));
const workflows_1 = __importDefault(require("./workflows"));
const config_1 = __importDefault(require("./config"));
const analytics_1 = __importDefault(require("./analytics"));
const shipments_1 = __importDefault(require("./shipments"));
const testing_1 = __importDefault(require("./testing"));
const certifications_1 = __importDefault(require("./certifications"));
const payments_1 = __importDefault(require("./payments"));
const users_1 = __importDefault(require("./users"));
const authMongo_1 = require("../../middleware/authMongo");
const models_1 = require("../../models");
const router = (0, express_1.Router)();
// Mount sub-routers
router.use('/auth', auth_1.default);
router.use('/applications', applications_1.default);
router.use('/documents', documents_1.default);
router.use('/notifications', notifications_1.default);
router.use('/workflows', workflows_1.default);
router.use('/remote-config', config_1.default);
router.use('/analytics', analytics_1.default);
router.use('/shipments', shipments_1.default);
router.use('/testing', testing_1.default);
router.use('/certifications', certifications_1.default);
router.use('/payments', payments_1.default);
router.use('/users', users_1.default);
// Quick profile endpoint
router.get('/users/me', authMongo_1.authenticate, async (req, res) => {
    res.json({ data: req.user });
});
router.put('/users/me', authMongo_1.authenticate, async (req, res) => {
    const allowed = ['name', 'avatar_url', 'locale', 'phone', 'consents'];
    const update = {};
    for (const k of allowed) {
        if (k in req.body)
            update[k] = req.body[k];
    }
    const updated = await models_1.User.findByIdAndUpdate(req.user._id, update, { new: true });
    res.json({ data: updated });
});
exports.default = router;
//# sourceMappingURL=index.js.map