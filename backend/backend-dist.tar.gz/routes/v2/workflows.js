"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Workflow routes — list available cert-type workflows.
 * Workflows are global config data, readable by any authenticated user.
 */
const express_1 = require("express");
const models_1 = require("../../models");
const authMongo_1 = require("../../middleware/authMongo");
const router = (0, express_1.Router)();
router.use(authMongo_1.authenticate);
// List all active workflows (cert types)
router.get('/', async (req, res) => {
    const { country_code } = req.query;
    const filter = { active: true };
    if (country_code)
        filter.country_code = country_code;
    const workflows = await models_1.Workflow.find(filter).sort({ display_name: 1 }).lean();
    return res.json({ data: workflows });
});
// Get one workflow by cert_type or _id
router.get('/:identifier', async (req, res) => {
    const { identifier } = req.params;
    const workflow = await models_1.Workflow.findOne({
        $or: [{ _id: identifier }, { cert_type: identifier }],
        active: true,
    }).lean();
    if (!workflow)
        return res.status(404).json({ error: 'not_found' });
    return res.json({ data: workflow });
});
// Admin-only: create/update workflows
router.put('/:id', (0, authMongo_1.requireRole)('super_admin'), async (req, res) => {
    const result = await models_1.Workflow.findByIdAndUpdate(req.params.id, { ...req.body, _id: req.params.id }, { upsert: true, new: true });
    return res.json({ data: result });
});
exports.default = router;
//# sourceMappingURL=workflows.js.map