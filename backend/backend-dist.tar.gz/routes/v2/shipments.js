"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const models_1 = require("../../models");
const authMongo_1 = require("../../middleware/authMongo");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
// GET all shipments (Admins see all, Clients see theirs)
router.get('/', authMongo_1.authenticate, wrap(async (req, res) => {
    const query = { deleted_at: null };
    if (req.user?.role !== 'admin' && req.user?.role !== 'super_admin') {
        query.client_id = req.user?._id;
    }
    const shipments = await models_1.Shipment.find(query).populate('client_id', 'name email companyName').sort('-createdAt');
    return res.json({ success: true, data: shipments });
}));
// GET single shipment
router.get('/:id', authMongo_1.authenticate, wrap(async (req, res) => {
    const shipment = await models_1.Shipment.findOne({ _id: req.params.id, deleted_at: null }).populate('client_id', 'name email companyName');
    if (!shipment)
        return res.status(404).json({ success: false, error: 'Not found' });
    if (req.user?.role !== 'admin' && req.user?.role !== 'super_admin' && String(shipment.client_id._id) !== String(req.user?._id)) {
        return res.status(403).json({ success: false, error: 'Access denied' });
    }
    return res.json({ success: true, data: shipment });
}));
// POST new shipment (Admin only)
router.post('/', authMongo_1.authenticate, (0, authMongo_1.requireRole)('admin', 'super_admin'), wrap(async (req, res) => {
    try {
        const shipment = await models_1.Shipment.create(req.body);
        return res.status(201).json({ success: true, data: shipment });
    }
    catch (error) {
        return res.status(400).json({ success: false, error: error.message });
    }
}));
// PUT update shipment (Admin only)
router.put('/:id', authMongo_1.authenticate, (0, authMongo_1.requireRole)('admin', 'super_admin'), wrap(async (req, res) => {
    try {
        const shipment = await models_1.Shipment.findOneAndUpdate({ _id: req.params.id, deleted_at: null }, req.body, { new: true });
        if (!shipment)
            return res.status(404).json({ success: false, error: 'Not found' });
        return res.json({ success: true, data: shipment });
    }
    catch (error) {
        return res.status(400).json({ success: false, error: error.message });
    }
}));
// DELETE soft delete (Admin only)
router.delete('/:id', authMongo_1.authenticate, (0, authMongo_1.requireRole)('admin', 'super_admin'), wrap(async (req, res) => {
    const shipment = await models_1.Shipment.findOneAndUpdate({ _id: req.params.id }, { deleted_at: new Date() }, { new: true });
    if (!shipment)
        return res.status(404).json({ success: false, error: 'Not found' });
    return res.json({ success: true, data: shipment });
}));
exports.default = router;
//# sourceMappingURL=shipments.js.map