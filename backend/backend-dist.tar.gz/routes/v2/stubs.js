"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.usersRouter = exports.adminRouter = exports.teamTasksRouter = exports.templatesRouter = exports.referralsRouter = exports.bookmarksRouter = exports.aiRouter = exports.analyticsRouter = exports.paymentsRouter = exports.shipmentsRouter = exports.insightsRouter = exports.certificationsRouter = void 0;
/**
 * Stub routes for modules that are being migrated from PostgreSQL to MongoDB.
 *
 * These return realistic mock data so the mobile app and admin dashboard
 * don't crash while the full MongoDB migration is completed.
 *
 * Each stub follows the same pattern:
 *   - GET /  → returns paginated mock list
 *   - GET /:id → returns single mock item
 *   - POST / → returns created mock item
 *   - PUT /:id → returns updated mock item
 *   - DELETE /:id → returns success
 */
const express_1 = require("express");
const authMongo_1 = require("../../middleware/authMongo");
// ─── CERTIFICATIONS ──────────────────────────────────────────────────────────
exports.certificationsRouter = (0, express_1.Router)();
exports.certificationsRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: [
            {
                id: 'cert-001',
                cert_number: 'BIS/CRS/2025/001234',
                cert_type: 'BIS_CRS',
                product_name: 'USB Type-C Charger 65W',
                product_category: 'Electronics',
                issuing_body: 'Bureau of Indian Standards',
                issue_date: '2025-01-15',
                expiry_date: '2027-01-14',
                status: 'active',
                country: 'India',
                standard_number: 'IS 13252 Part 1',
            },
            {
                id: 'cert-002',
                cert_number: 'FSSAI/LIC/2025/005678',
                cert_type: 'FSSAI',
                product_name: 'Organic Green Tea',
                product_category: 'Food & Beverage',
                issuing_body: 'FSSAI',
                issue_date: '2025-03-01',
                expiry_date: '2030-02-28',
                status: 'active',
                country: 'India',
                standard_number: 'FSSAI License',
            },
            {
                id: 'cert-003',
                cert_number: 'CE/EU/2024/009876',
                cert_type: 'CE',
                product_name: 'Bluetooth Headphones',
                product_category: 'Electronics',
                issuing_body: 'TÜV SÜD',
                issue_date: '2024-06-15',
                expiry_date: '2025-08-15',
                status: 'expiring_soon',
                country: 'European Union',
                standard_number: 'EN 55032',
            },
        ],
        pagination: { page: 1, limit: 20, total: 3, pages: 1 },
    });
});
exports.certificationsRouter.get('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, cert_type: 'BIS_CRS', status: 'active' } });
});
exports.certificationsRouter.post('/', authMongo_1.authenticate, async (req, res) => {
    res.status(201).json({ success: true, data: { id: 'cert-new', ...req.body, status: 'pending' } });
});
exports.certificationsRouter.put('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, ...req.body } });
});
exports.certificationsRouter.delete('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, message: 'Certification deleted' });
});
// ─── INSIGHTS ────────────────────────────────────────────────────────────────
exports.insightsRouter = (0, express_1.Router)();
exports.insightsRouter.get('/', async (_req, res) => {
    res.json({
        success: true,
        data: [
            {
                id: 'insight-001',
                title: 'BIS Mandates New Standards for EV Chargers',
                summary: 'Bureau of Indian Standards introduces IS 17017 for electric vehicle charging stations.',
                category: 'BIS',
                source: 'BIS Gazette',
                published_at: new Date().toISOString(),
                ai_summary: 'New EV charger standards IS 17017 require testing for safety, EMC, and performance. Manufacturers must comply by Q3 2026.',
                relevance_score: 0.92,
                tags: ['EV', 'BIS', 'Electronics'],
            },
            {
                id: 'insight-002',
                title: 'FSSAI Updates Labeling Requirements for Packaged Foods',
                summary: 'New front-of-pack nutrition labeling guidelines effective from January 2026.',
                category: 'FSSAI',
                source: 'FSSAI Notification',
                published_at: new Date(Date.now() - 86400000).toISOString(),
                ai_summary: 'FSSAI mandates front-of-pack health star ratings for packaged foods. Companies must update labels within 18 months.',
                relevance_score: 0.85,
                tags: ['FSSAI', 'Food Safety', 'Labeling'],
            },
        ],
        pagination: { page: 1, limit: 20, total: 2, pages: 1 },
    });
});
exports.insightsRouter.get('/:id', async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, title: 'Regulatory Update', content: 'Full article content here...' } });
});
// ─── SHIPMENTS ───────────────────────────────────────────────────────────────
exports.shipmentsRouter = (0, express_1.Router)();
exports.shipmentsRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: [
            {
                id: 'ship-001',
                tracking_number: 'MAEU1234567',
                carrier: 'Maersk',
                origin_country: 'China',
                destination_country: 'India',
                status: 'in_transit',
                product_description: 'Electronic Components - PCB Assemblies',
                hs_code: '8534.00',
                customs_status: 'pre_clearance',
                estimated_arrival: new Date(Date.now() + 7 * 86400000).toISOString(),
            },
        ],
        pagination: { page: 1, limit: 20, total: 1, pages: 1 },
    });
});
exports.shipmentsRouter.get('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, status: 'in_transit' } });
});
exports.shipmentsRouter.post('/', authMongo_1.authenticate, async (req, res) => {
    res.status(201).json({ success: true, data: { id: 'ship-new', ...req.body } });
});
// ─── PAYMENTS ────────────────────────────────────────────────────────────────
exports.paymentsRouter = (0, express_1.Router)();
exports.paymentsRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: [
            {
                id: 'pay-001',
                amount: 55000,
                currency: 'INR',
                status: 'paid',
                description: 'BIS CRS Certification Fee - USB Charger',
                invoice_number: 'INV-2025-0042',
                paid_at: new Date(Date.now() - 15 * 86400000).toISOString(),
            },
            {
                id: 'pay-002',
                amount: 28000,
                currency: 'INR',
                status: 'pending',
                description: 'FSSAI License Application Fee',
                invoice_number: 'INV-2025-0043',
                paid_at: null,
            },
        ],
        pagination: { page: 1, limit: 20, total: 2, pages: 1 },
    });
});
exports.paymentsRouter.get('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, status: 'paid', amount: 55000 } });
});
exports.paymentsRouter.post('/webhook', async (req, res) => {
    // Razorpay webhook handler placeholder
    res.json({ success: true });
});
exports.paymentsRouter.post('/quotations', authMongo_1.authenticate, async (req, res) => {
    const { application_id, gov_fee, lab_fee } = req.body;
    res.status(201).json({
        success: true,
        data: {
            id: `quo-${Date.now()}`,
            application_id,
            amount: gov_fee + lab_fee,
            status: 'pending_approval',
            created_at: new Date().toISOString()
        }
    });
});
// ─── ANALYTICS ───────────────────────────────────────────────────────────────
exports.analyticsRouter = (0, express_1.Router)();
exports.analyticsRouter.get('/overview', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            total_certifications: 12,
            active_certifications: 8,
            expiring_soon: 2,
            pending_applications: 3,
            total_revenue: 485000,
            monthly_revenue: 55000,
            documents_uploaded: 47,
            compliance_score: 87,
        },
    });
});
exports.analyticsRouter.get('/revenue', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            monthly: [
                { month: '2025-01', revenue: 42000 },
                { month: '2025-02', revenue: 38000 },
                { month: '2025-03', revenue: 55000 },
                { month: '2025-04', revenue: 67000 },
                { month: '2025-05', revenue: 51000 },
                { month: '2025-06', revenue: 55000 },
            ],
        },
    });
});
exports.analyticsRouter.get('/certifications', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            by_type: [
                { type: 'BIS', count: 5 },
                { type: 'FSSAI', count: 3 },
                { type: 'CE', count: 2 },
                { type: 'ISO', count: 2 },
            ],
            by_status: [
                { status: 'active', count: 8 },
                { status: 'expiring_soon', count: 2 },
                { status: 'expired', count: 1 },
                { status: 'pending', count: 1 },
            ],
        },
    });
});
exports.analyticsRouter.get('/applications', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            by_status: [
                { status: 'submitted', count: 2 },
                { status: 'docs_review', count: 1 },
                { status: 'testing', count: 1 },
                { status: 'approved', count: 5 },
            ],
            avg_processing_days: 28,
        },
    });
});
// ─── AI ──────────────────────────────────────────────────────────────────────
exports.aiRouter = (0, express_1.Router)();
exports.aiRouter.post('/chat', authMongo_1.authenticate, async (req, res) => {
    const { message } = req.body;
    res.json({
        success: true,
        data: {
            response: `Thank you for your question about "${(message || '').slice(0, 50)}". I'm the Sanyog AI Compliance Assistant. I can help with BIS, FSSAI, CE, ISO certifications and Indian compliance regulations. Please configure the OPENAI_API_KEY for full AI-powered responses.`,
            conversationId: 'conv-mock-001',
        },
    });
});
exports.aiRouter.get('/conversations', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: [] });
});
exports.aiRouter.get('/recommendations', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: [
            'Review your BIS CRS certificate — renewal due in 60 days',
            'Upload pending test reports for FSSAI application',
            'Monitor BIS circular updates for IS 13252 amendments',
        ],
    });
});
exports.aiRouter.post('/analyze-document', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            issues: [],
            recommendations: ['Document appears compliant. Configure OPENAI_API_KEY for detailed AI analysis.'],
            complianceScore: 85,
        },
    });
});
// ─── BOOKMARKS ───────────────────────────────────────────────────────────────
exports.bookmarksRouter = (0, express_1.Router)();
exports.bookmarksRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: [] });
});
exports.bookmarksRouter.post('/', authMongo_1.authenticate, async (req, res) => {
    res.status(201).json({ success: true, data: { id: 'bm-001', ...req.body } });
});
exports.bookmarksRouter.delete('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, message: 'Bookmark removed' });
});
// ─── REFERRALS ───────────────────────────────────────────────────────────────
exports.referralsRouter = (0, express_1.Router)();
exports.referralsRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            referral_code: 'SANYOG-REF-001',
            total_referrals: 0,
            earnings: 0,
            referrals: [],
        },
    });
});
exports.referralsRouter.post('/', authMongo_1.authenticate, async (req, res) => {
    res.status(201).json({ success: true, data: { id: 'ref-001', ...req.body } });
});
// ─── TEMPLATES ───────────────────────────────────────────────────────────────
exports.templatesRouter = (0, express_1.Router)();
exports.templatesRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: [
            { id: 'tmpl-001', name: 'BIS Application Form', category: 'BIS', file_type: 'pdf' },
            { id: 'tmpl-002', name: 'Declaration of Conformity', category: 'CE', file_type: 'docx' },
            { id: 'tmpl-003', name: 'FSSAI License Application', category: 'FSSAI', file_type: 'pdf' },
        ],
    });
});
exports.templatesRouter.get('/:id', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { id: req.params.id, name: 'Template', content: 'Template content...' } });
});
// ─── TEAM TASKS ──────────────────────────────────────────────────────────────
exports.teamTasksRouter = (0, express_1.Router)();
exports.teamTasksRouter.get('/', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: [], pagination: { page: 1, limit: 20, total: 0, pages: 0 } });
});
exports.teamTasksRouter.post('/', authMongo_1.authenticate, async (req, res) => {
    res.status(201).json({ success: true, data: { id: 'task-001', ...req.body, status: 'open' } });
});
// ─── ADMIN ───────────────────────────────────────────────────────────────────
const User_1 = require("../../models/User");
exports.adminRouter = (0, express_1.Router)();
exports.adminRouter.get('/stats', authMongo_1.authenticate, async (req, res) => {
    res.json({
        success: true,
        data: {
            total_users: 150,
            active_users: 89,
            total_applications: 234,
            pending_review: 12,
            revenue_this_month: 485000,
        },
    });
});
exports.adminRouter.get('/users', authMongo_1.authenticate, async (req, res) => {
    const users = await User_1.User.find({}).lean();
    res.json({ success: true, data: users, pagination: { page: 1, limit: 100, total: users.length, pages: 1 } });
});
exports.adminRouter.post('/users', authMongo_1.authenticate, async (req, res) => {
    try {
        const { name, email, role, phone } = req.body;
        const user = await User_1.User.create({
            name,
            email,
            role,
            phone,
            org_id: req.user.org_id // assign to the same org
        });
        res.status(201).json({ success: true, data: user });
    }
    catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
});
// ─── USERS ───────────────────────────────────────────────────────────────────
exports.usersRouter = (0, express_1.Router)();
exports.usersRouter.get('/me', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: req.user });
});
exports.usersRouter.put('/me', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: { ...req.body } });
});
//# sourceMappingURL=stubs.js.map