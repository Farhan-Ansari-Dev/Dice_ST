"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const RemoteConfig_1 = require("../../models/RemoteConfig");
const authMongo_1 = require("../../middleware/authMongo");
const response_1 = require("../../utils/response");
const redis_1 = __importDefault(require("../../config/redis"));
const zod_1 = require("zod");
const logger_1 = require("../../utils/logger");
const router = (0, express_1.Router)();
const CACHE_KEY = 'global_remote_config';
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
const configUpdateSchema = zod_1.z.object({
    featureFlags: zod_1.z.object({
        maintenance_mode: zod_1.z.boolean().optional(),
        enable_ai_assistant: zod_1.z.boolean().optional(),
        enable_ocr_scanning: zod_1.z.boolean().optional(),
        enable_referral_rewards: zod_1.z.boolean().optional(),
        enable_promotional_banners: zod_1.z.boolean().optional(),
        enable_notifications: zod_1.z.boolean().optional(),
    }).optional(),
    dynamicConfig: zod_1.z.object({
        banner_text: zod_1.z.string().optional(),
        banner_color: zod_1.z.string().optional(),
        referral_reward_value: zod_1.z.number().optional(),
        announcement_title: zod_1.z.string().optional(),
        announcement_body: zod_1.z.string().optional(),
    }).optional(),
});
// Public endpoint for mobile app to fetch config
router.get('/', wrap(async (req, res) => {
    // 1. Try Cache
    const cached = await redis_1.default.get(CACHE_KEY);
    if (cached) {
        (0, response_1.sendSuccess)(res, JSON.parse(cached), 'Config fetched from cache');
        return;
    }
    // 2. Fetch from DB
    const config = await RemoteConfig_1.RemoteConfig.getGlobalConfig();
    // 3. Update Cache
    await redis_1.default.setex(CACHE_KEY, 3600, JSON.stringify(config)); // 1 hour TTL
    (0, response_1.sendSuccess)(res, config, 'Config fetched from database');
}));
// Admin endpoint to get config details
router.get('/admin', authMongo_1.authenticate, (0, authMongo_1.requireRole)('admin'), wrap(async (req, res) => {
    const config = await RemoteConfig_1.RemoteConfig.getGlobalConfig();
    (0, response_1.sendSuccess)(res, config, 'Admin config fetched');
}));
// Admin endpoint to update config and bust cache
router.put('/admin', authMongo_1.authenticate, (0, authMongo_1.requireRole)('admin'), wrap(async (req, res) => {
    const updates = configUpdateSchema.parse(req.body);
    let config = await RemoteConfig_1.RemoteConfig.getGlobalConfig();
    if (updates.featureFlags) {
        config.featureFlags = { ...config.featureFlags, ...updates.featureFlags };
    }
    if (updates.dynamicConfig) {
        config.dynamicConfig = { ...config.dynamicConfig, ...updates.dynamicConfig };
    }
    await config.save();
    // Immediately bust and update the cache for instant rollout
    await redis_1.default.setex(CACHE_KEY, 3600, JSON.stringify(config));
    logger_1.logger.info(`Remote Config updated by admin ${req.user._id}`);
    (0, response_1.sendSuccess)(res, config, 'Configuration updated successfully');
}));
exports.default = router;
//# sourceMappingURL=config.js.map