"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMongo_1 = require("../../middleware/authMongo");
const Certification_1 = require("../../models/Certification");
const Application_1 = require("../../models/Application");
const Payment_1 = require("../../models/Payment");
const User_1 = require("../../models/User");
const response_1 = require("../../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.get('/overview', authMongo_1.authenticate, wrap(async (req, res) => {
    const query = {};
    if (req.user.role !== 'admin' && req.user.role !== 'super_admin') {
        query.org_id = req.user.org_id;
    }
    // Count Active Certifications
    const total_certifications = await Certification_1.Certification.countDocuments({ ...query, deleted_at: { $exists: false } });
    const active_certifications = await Certification_1.Certification.countDocuments({ ...query, status: 'active', deleted_at: { $exists: false } });
    const expiring_soon = await Certification_1.Certification.countDocuments({ ...query, status: 'expiring_soon', deleted_at: { $exists: false } });
    // Count Pending Applications
    const pending_applications = await Application_1.Application.countDocuments({ ...query, status: { $in: ['draft', 'submitted', 'under_review'] }, deleted_at: { $exists: false } });
    // Active Users (only admins see all users, else count users in same org)
    let active_users = 0;
    if (req.user.role === 'admin' || req.user.role === 'super_admin') {
        active_users = await User_1.User.countDocuments({ deleted_at: { $exists: false } });
    }
    else {
        active_users = await User_1.User.countDocuments({ org_id: req.user.org_id, deleted_at: { $exists: false } });
    }
    // Total collected payments
    const payments = await Payment_1.Payment.find({ ...query, status: { $in: ['paid', 'captured'] } });
    const total_revenue = payments.reduce((acc, curr) => acc + (curr.total_paise / 100), 0);
    (0, response_1.sendSuccess)(res, {
        total_certifications,
        active_certifications,
        expiring_soon,
        pending_applications,
        active_users,
        total_revenue
    });
}));
exports.default = router;
//# sourceMappingURL=analytics.js.map