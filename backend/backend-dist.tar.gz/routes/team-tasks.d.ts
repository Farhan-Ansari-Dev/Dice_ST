declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=team-tasks.d.ts.map