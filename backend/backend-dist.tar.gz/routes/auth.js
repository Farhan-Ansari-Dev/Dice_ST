"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authService_1 = require("../services/authService");
const auth_1 = require("../middleware/auth");
const response_1 = require("../utils/response");
const zod_1 = require("zod");
const router = (0, express_1.Router)();
const emailSchema = zod_1.z.object({ email: zod_1.z.string().email() });
const otpSchema = zod_1.z.object({ email: zod_1.z.string().email(), otp: zod_1.z.string().length(6) });
const googleSchema = zod_1.z.object({ idToken: zod_1.z.string() });
const refreshSchema = zod_1.z.object({ refreshToken: zod_1.z.string() });
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.post('/send-otp', wrap(async (req, res) => {
    const { email } = emailSchema.parse(req.body);
    await authService_1.authService.sendOTP(email);
    (0, response_1.sendSuccess)(res, null, 'OTP sent successfully');
}));
router.post('/verify-otp', wrap(async (req, res) => {
    const { email, otp } = otpSchema.parse(req.body);
    const result = await authService_1.authService.verifyOTP(email, otp);
    (0, response_1.sendSuccess)(res, result, 'Login successful');
}));
router.post('/google', wrap(async (req, res) => {
    const { idToken } = googleSchema.parse(req.body);
    const result = await authService_1.authService.googleSignIn(idToken);
    (0, response_1.sendSuccess)(res, result, 'Google login successful');
}));
router.post('/refresh', wrap(async (req, res) => {
    const { refreshToken } = refreshSchema.parse(req.body);
    const tokens = await authService_1.authService.refreshTokens(refreshToken);
    (0, response_1.sendSuccess)(res, tokens, 'Tokens refreshed');
}));
router.post('/logout', auth_1.authenticate, wrap(async (req, res) => {
    await authService_1.authService.logout(req.user.id);
    (0, response_1.sendSuccess)(res, null, 'Logged out successfully');
}));
exports.default = router;
//# sourceMappingURL=auth.js.map