"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const models_1 = require("../models");
const redis_1 = __importDefault(require("../config/redis"));
const aiService_1 = require("../services/aiService");
const response_1 = require("../utils/response");
const axiosCreeper_1 = require("../jobs/axiosCreeper");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(auth_1.authenticate);
router.get('/', wrap(async (req, res) => {
    const { page = 1, limit = 20, category, country } = req.query;
    const cacheKey = `insights:mongo:${category ?? 'all'}:${country ?? 'all'}:${page}:${limit}`;
    const cached = await redis_1.default.get(cacheKey);
    if (cached) {
        res.json(JSON.parse(cached));
        return;
    }
    const query = {};
    if (category)
        query.category = category;
    if (country)
        query.country = country;
    const total = await models_1.Insight.countDocuments(query);
    const offset = (Number(page) - 1) * Number(limit);
    const insights = await models_1.Insight.find(query)
        .sort({ publishedAt: -1 })
        .skip(offset)
        .limit(Number(limit));
    const response = { success: true, data: insights, pagination: { total, page: Number(page), limit: Number(limit), pages: Math.ceil(total / Number(limit)) } };
    await redis_1.default.setex(cacheKey, 300, JSON.stringify(response)); // 5 min cache
    res.json(response);
}));
router.get('/:id', wrap(async (req, res) => {
    const insight = await models_1.Insight.findById(req.params.id);
    (0, response_1.sendSuccess)(res, insight);
}));
router.post('/ai-summary', wrap(async (req, res) => {
    const { content } = req.body;
    const summary = await aiService_1.aiService.generateInsightSummary(content);
    (0, response_1.sendSuccess)(res, { summary });
}));
// TRIGGER SCRAPER MANUALLY (For testing pipeline)
router.post('/trigger-scraper', wrap(async (req, res) => {
    const result = await (0, axiosCreeper_1.runAxiosCreeper)();
    (0, response_1.sendSuccess)(res, result);
}));
exports.default = router;
//# sourceMappingURL=insights.js.map