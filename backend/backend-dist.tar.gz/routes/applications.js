"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const socket_1 = require("../config/socket");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(auth_1.authenticate);
router.get('/', wrap(async (req, res) => {
    const { page = 1, limit = 20, status, cert_type } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const isAdmin = req.user.role === 'admin' || req.user.role === 'employee';
    const where = isAdmin ? 'WHERE 1=1' : 'WHERE a.user_id = $1';
    const params = isAdmin ? [] : [req.user.id];
    let idx = params.length + 1;
    if (status) {
        params.push(status);
    }
    params.push(Number(limit), offset);
    const result = await (0, database_1.query)(`SELECT a.*, u.name as client_name, u.email as client_email, u.company_name,
     e.name as assignee_name
     FROM applications a
     LEFT JOIN users u ON a.user_id = u.id
     LEFT JOIN users e ON a.assigned_to = e.id
     ${where} ORDER BY a.created_at DESC LIMIT $${idx} OFFSET $${idx + 1}`, params);
    const total = parseInt((await (0, database_1.query)(`SELECT COUNT(*) FROM applications ${where}`, isAdmin ? [] : [req.user.id])).rows[0].count);
    (0, response_1.sendPaginated)(res, result.rows, total, Number(page), Number(limit));
}));
router.get('/:id', wrap(async (req, res) => {
    const result = await (0, database_1.query)(`SELECT a.*, u.name as client_name, u.company_name, e.name as assignee_name
     FROM applications a LEFT JOIN users u ON a.user_id = u.id LEFT JOIN users e ON a.assigned_to = e.id
     WHERE a.id = $1`, [req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Application not found', 404);
    const events = await (0, database_1.query)('SELECT ae.*, u.name as actor_name FROM application_events ae LEFT JOIN users u ON ae.actor_id = u.id WHERE ae.application_id = $1 ORDER BY ae.created_at ASC', [req.params.id]);
    (0, response_1.sendSuccess)(res, { ...result.rows[0], timeline: events.rows });
}));
router.post('/', wrap(async (req, res) => {
    const { cert_type, product_name, product_category, notes, priority = 'medium' } = req.body;
    const appNum = `APP-${Date.now().toString().slice(-6)}`;
    const result = await (0, database_1.query)(`INSERT INTO applications (user_id, application_number, cert_type, product_name, product_category, notes, priority)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [req.user.id, appNum, cert_type, product_name, product_category, notes, priority]);
    const app = result.rows[0];
    await (0, database_1.query)('INSERT INTO application_events (application_id, event_type, description, actor_id) VALUES ($1,$2,$3,$4)', [app.id, 'created', 'Application submitted', req.user.id]);
    (0, socket_1.emitToAdmin)('application:new', { application: app });
    (0, response_1.sendSuccess)(res, app, 'Application submitted', 201);
}));
router.put('/:id/status', wrap(async (req, res) => {
    const { status, notes } = req.body;
    const VALID = ['submitted', 'under_review', 'lab_testing', 'approved', 'rejected', 'on_hold'];
    if (!VALID.includes(status))
        throw new errorHandler_1.AppError('Invalid status', 400);
    const result = await (0, database_1.query)('UPDATE applications SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *', [status, req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Application not found', 404);
    const app = result.rows[0];
    await (0, database_1.query)('INSERT INTO application_events (application_id, event_type, description, actor_id) VALUES ($1,$2,$3,$4)', [app.id, 'status_change', notes ?? `Status changed to ${status}`, req.user.id]);
    (0, socket_1.emitToUser)(app.user_id, 'application:status_updated', { applicationId: app.id, status });
    (0, response_1.sendSuccess)(res, app, 'Status updated');
}));
exports.default = router;
//# sourceMappingURL=applications.js.map