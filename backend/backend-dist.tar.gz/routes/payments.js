"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const razorpayService_1 = require("../services/razorpayService");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
// Razorpay webhook — no auth, raw body needed
router.post('/webhook', (req, res, next) => {
    (async () => {
        const signature = req.headers['x-razorpay-signature'];
        if (!signature) {
            res.status(400).json({ success: false, message: 'Missing signature' });
            return;
        }
        const payload = JSON.stringify(req.body);
        const valid = await razorpayService_1.razorpayService.handleWebhook(payload, signature);
        if (!valid) {
            res.status(400).json({ success: false, message: 'Invalid webhook signature' });
            return;
        }
        const event = req.body;
        if (event.event === 'payment.captured') {
            const payment = event.payload?.payment?.entity;
            const orderId = payment?.order_id ?? '';
            const paymentId = payment?.id ?? '';
            const userId = event.payload?.order?.entity?.notes?.userId ?? '';
            if (orderId && paymentId) {
                await (0, database_1.query)(`UPDATE payments SET status = 'paid', transaction_id = $1, paid_at = NOW()
           WHERE transaction_id = $2 AND status != 'paid'`, [paymentId, orderId]);
            }
            if (userId) {
                const { notificationService } = await Promise.resolve().then(() => __importStar(require('../services/notificationService')));
                await notificationService.notify(userId, 'Payment Confirmed', 'Your payment has been captured and confirmed.', 'payment');
            }
        }
        res.json({ status: 'ok' });
    })().catch(next);
});
router.use(auth_1.authenticate);
// GET / — list payments with pagination
router.get('/', wrap(async (req, res) => {
    const { page = 1, limit = 20, status } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const isAdmin = req.user.role === 'admin';
    const conditions = [];
    const params = [];
    if (!isAdmin) {
        params.push(req.user.id);
        conditions.push(`p.user_id = $${params.length}`);
    }
    if (status) {
        params.push(status);
        conditions.push(`p.status = $${params.length}`);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [result, countResult] = await Promise.all([
        (0, database_1.query)(`SELECT p.*, u.name as client_name, a.application_number
       FROM payments p
       LEFT JOIN users u ON p.user_id = u.id
       LEFT JOIN applications a ON p.application_id = a.id
       ${where}
       ORDER BY p.created_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`, [...params, Number(limit), offset]),
        (0, database_1.query)(`SELECT COUNT(*) FROM payments p ${where}`, params),
    ]);
    const total = parseInt(countResult.rows[0].count);
    (0, response_1.sendPaginated)(res, result.rows, total, Number(page), Number(limit));
}));
// POST /create-order — creates Razorpay order
router.post('/create-order', wrap(async (req, res) => {
    const { application_id, amount, description } = req.body;
    if (!amount || !description)
        throw new errorHandler_1.AppError('amount and description are required', 400);
    const { order, payment } = await razorpayService_1.razorpayService.createOrder(req.user.id, application_id ?? null, Number(amount), description);
    (0, response_1.sendSuccess)(res, { order, payment }, 'Order created', 201);
}));
// POST /verify — verifies Razorpay payment signature
router.post('/verify', wrap(async (req, res) => {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
        throw new errorHandler_1.AppError('razorpay_order_id, razorpay_payment_id and razorpay_signature are required', 400);
    }
    const verified = await razorpayService_1.razorpayService.verifyPayment(razorpay_order_id, razorpay_payment_id, razorpay_signature, req.user.id);
    if (!verified)
        throw new errorHandler_1.AppError('Payment verification failed', 400);
    (0, response_1.sendSuccess)(res, { verified: true }, 'Payment verified successfully');
}));
// GET /:id/invoice — get invoice details
router.get('/:id/invoice', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const params = [req.params.id];
    let where = 'p.id = $1';
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND p.user_id = $2`;
    }
    const result = await (0, database_1.query)(`SELECT p.*, u.name as client_name, u.email as client_email, u.company_name,
            a.application_number, a.cert_type, a.product_name
     FROM payments p
     LEFT JOIN users u ON p.user_id = u.id
     LEFT JOIN applications a ON p.application_id = a.id
     WHERE ${where}`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Payment not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0]);
}));
exports.default = router;
//# sourceMappingURL=payments.js.map