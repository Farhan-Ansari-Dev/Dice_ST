"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * API Router — mounts all MongoDB-backed routes.
 *
 * Routes are organized into:
 *   - Core v2 routes (fully migrated to MongoDB with Mongoose models)
 *   - Stub routes (return realistic mock data during migration)
 */
const express_1 = require("express");
// Core v2 routes (fully MongoDB-backed)
const auth_1 = __importDefault(require("./v2/auth"));
const applications_1 = __importDefault(require("./v2/applications"));
const documents_1 = __importDefault(require("./v2/documents"));
const notifications_1 = __importDefault(require("./v2/notifications"));
const workflows_1 = __importDefault(require("./v2/workflows"));
const marketAccessRoutes_1 = __importDefault(require("../routes/marketAccessRoutes"));
// Stubs removed
const authMongo_1 = require("../middleware/authMongo");
const models_1 = require("../models");
const ai_1 = __importDefault(require("./ai"));
const insights_1 = __importDefault(require("./insights"));
const router = (0, express_1.Router)();
// ── Core v2 routes (full Mongoose models) ─────────────────────────────────
router.use('/auth', auth_1.default);
router.use('/applications', applications_1.default);
router.use('/documents', documents_1.default);
router.use('/notifications', notifications_1.default);
router.use('/workflows', workflows_1.default);
router.use('/market-access', marketAccessRoutes_1.default);
// ── Migrated to Mongoose ──────────────────────────────────────────────────
router.use('/ai', ai_1.default);
router.use('/insights', insights_1.default);
const payments_1 = __importDefault(require("./v2/payments"));
const certifications_1 = __importDefault(require("./v2/certifications"));
const analytics_1 = __importDefault(require("./v2/analytics"));
const users_1 = __importDefault(require("./v2/users"));
router.use('/payments', payments_1.default);
router.use('/certifications', certifications_1.default);
router.use('/analytics', analytics_1.default);
router.use('/users', users_1.default);
// ── Profile endpoints ─────────────────────────────────────────────────────
router.get('/users/me', authMongo_1.authenticate, async (req, res) => {
    res.json({ success: true, data: req.user });
});
router.put('/users/me', authMongo_1.authenticate, async (req, res) => {
    const allowed = ['name', 'avatar_url', 'locale', 'phone', 'consents'];
    const update = {};
    for (const k of allowed) {
        if (k in req.body)
            update[k] = req.body[k];
    }
    const updated = await models_1.User.findByIdAndUpdate(req.user._id, update, { new: true });
    res.json({ success: true, data: updated });
});
exports.default = router;
//# sourceMappingURL=index.js.map