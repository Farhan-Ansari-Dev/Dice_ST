"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const uuid_1 = require("uuid");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
// Local storage for dev (uploads/ directory)
const UPLOAD_DIR = path_1.default.join(process.cwd(), 'uploads');
if (!fs_1.default.existsSync(UPLOAD_DIR))
    fs_1.default.mkdirSync(UPLOAD_DIR, { recursive: true });
const diskStorage = multer_1.default.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
    filename: (_req, file, cb) => cb(null, `${(0, uuid_1.v4)()}-${file.originalname.replace(/\s+/g, '_')}`),
});
const upload = (0, multer_1.default)({
    storage: process.env.NODE_ENV === 'production' ? multer_1.default.memoryStorage() : diskStorage,
    limits: { fileSize: 50 * 1024 * 1024 },
});
const getBaseUrl = (req) => `${req.protocol}://${req.get('host')}`;
router.use(auth_1.authenticate);
// GET / — list documents
router.get('/', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const { category, application_id } = req.query;
    const conditions = [];
    const params = [];
    if (!isAdmin) {
        params.push(req.user.id);
        conditions.push(`d.user_id = $${params.length}`);
    }
    if (category) {
        params.push(category);
        conditions.push(`d.doc_category = $${params.length}`);
    }
    if (application_id) {
        params.push(application_id);
        conditions.push(`d.application_id = $${params.length}`);
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const result = await (0, database_1.query)(`SELECT d.*, u.name as client_name
     FROM documents d
     LEFT JOIN users u ON d.user_id = u.id
     ${where}
     ORDER BY d.created_at DESC
     LIMIT 100`, params);
    (0, response_1.sendSuccess)(res, result.rows);
}));
// POST /upload — upload file to local disk (dev) or S3 (prod)
router.post('/upload', upload.single('file'), wrap(async (req, res) => {
    if (!req.file)
        throw new errorHandler_1.AppError('No file provided', 400);
    let s3Key;
    let s3Url;
    if (process.env.NODE_ENV === 'production' && process.env.AWS_S3_BUCKET) {
        // Production: upload to S3 via AWS SDK
        const { S3Client, PutObjectCommand } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-s3')));
        const s3 = new S3Client({ region: process.env.AWS_REGION ?? 'ap-south-1' });
        s3Key = `documents/${req.user.id}/${(0, uuid_1.v4)()}-${req.file.originalname}`;
        await s3.send(new PutObjectCommand({
            Bucket: process.env.AWS_S3_BUCKET,
            Key: s3Key,
            Body: req.file.buffer,
            ContentType: req.file.mimetype,
        }));
        s3Url = `https://${process.env.AWS_S3_BUCKET}.s3.${process.env.AWS_REGION ?? 'ap-south-1'}.amazonaws.com/${s3Key}`;
    }
    else {
        // Development: saved to disk
        s3Key = `uploads/${req.file.filename ?? req.file.originalname}`;
        s3Url = `${getBaseUrl(req)}/uploads/${req.file.filename ?? req.file.originalname}`;
    }
    const result = await (0, database_1.query)(`INSERT INTO documents (user_id, application_id, name, file_type, file_size, s3_key, s3_url, doc_category)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`, [
        req.user.id,
        req.body.application_id ?? null,
        req.file.originalname,
        req.file.mimetype,
        req.file.size,
        s3Key,
        s3Url,
        req.body.category ?? 'general',
    ]);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Document uploaded', 201);
}));
// POST /presigned-url — get presigned upload URL for S3
router.post('/presigned-url', wrap(async (req, res) => {
    const { filename, contentType, category = 'general' } = req.body;
    if (!filename || !contentType)
        throw new errorHandler_1.AppError('filename and contentType are required', 400);
    const s3Key = `documents/${req.user.id}/${(0, uuid_1.v4)()}-${filename.replace(/\s+/g, '_')}`;
    if (process.env.AWS_S3_BUCKET) {
        const { S3Client } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-s3')));
        const { PutObjectCommand } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-s3')));
        const { getSignedUrl } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/s3-request-presigner')));
        const s3 = new S3Client({ region: process.env.AWS_REGION ?? 'ap-south-1' });
        const command = new PutObjectCommand({
            Bucket: process.env.AWS_S3_BUCKET,
            Key: s3Key,
            ContentType: contentType,
        });
        const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 3600 });
        const publicUrl = `https://${process.env.AWS_S3_BUCKET}.s3.${process.env.AWS_REGION ?? 'ap-south-1'}.amazonaws.com/${s3Key}`;
        (0, response_1.sendSuccess)(res, { uploadUrl, s3Key, publicUrl, expiresIn: 3600 });
    }
    else {
        // Dev fallback — return a mock presigned URL
        (0, response_1.sendSuccess)(res, {
            uploadUrl: `${getBaseUrl(req)}/api/v1/documents/upload`,
            s3Key,
            publicUrl: `${getBaseUrl(req)}/uploads/${path_1.default.basename(s3Key)}`,
            expiresIn: 3600,
            note: 'dev_mode — use POST /upload instead',
        });
    }
}));
// GET /:id/download — get download URL
router.get('/:id/download', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const params = [req.params.id];
    let where = 'id = $1';
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND user_id = $2`;
    }
    const result = await (0, database_1.query)(`SELECT * FROM documents WHERE ${where}`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Document not found', 404);
    const doc = result.rows[0];
    if (process.env.AWS_S3_BUCKET) {
        const { S3Client, GetObjectCommand } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/client-s3')));
        const { getSignedUrl } = await Promise.resolve().then(() => __importStar(require('@aws-sdk/s3-request-presigner')));
        const s3 = new S3Client({ region: process.env.AWS_REGION ?? 'ap-south-1' });
        const command = new GetObjectCommand({ Bucket: process.env.AWS_S3_BUCKET, Key: doc.s3_key });
        const url = await getSignedUrl(s3, command, { expiresIn: 3600 });
        (0, response_1.sendSuccess)(res, { url, expiresIn: 3600 });
    }
    else {
        (0, response_1.sendSuccess)(res, { url: doc.s3_url ?? `${getBaseUrl(req)}/${doc.s3_key}`, expiresIn: 3600 });
    }
}));
// DELETE /:id — delete document
router.delete('/:id', wrap(async (req, res) => {
    const isAdmin = req.user.role === 'admin';
    const params = [req.params.id];
    let where = 'id = $1';
    if (!isAdmin) {
        params.push(req.user.id);
        where += ` AND user_id = $2`;
    }
    const result = await (0, database_1.query)(`DELETE FROM documents WHERE ${where} RETURNING s3_key`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Document not found', 404);
    // Delete from disk if dev
    const doc = result.rows[0];
    if (doc.s3_key.startsWith('uploads/')) {
        const filePath = path_1.default.join(process.cwd(), doc.s3_key);
        if (fs_1.default.existsSync(filePath))
            fs_1.default.unlinkSync(filePath);
    }
    (0, response_1.sendSuccess)(res, null, 'Document deleted');
}));
// POST /:id/verify — mark document as verified (admin only)
router.post('/:id/verify', auth_1.requireAdmin, wrap(async (req, res) => {
    const result = await (0, database_1.query)('UPDATE documents SET is_verified = true, metadata = metadata || $1 WHERE id = $2 RETURNING *', [JSON.stringify({ verified_by: req.user.id, verified_at: new Date().toISOString() }), req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Document not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Document verified');
}));
// POST /scan — receive OCR scan result and save
router.post('/scan', wrap(async (req, res) => {
    const { document_id, ocr_text, metadata } = req.body;
    if (!document_id || !ocr_text)
        throw new errorHandler_1.AppError('document_id and ocr_text are required', 400);
    const result = await (0, database_1.query)(`UPDATE documents SET ocr_text = $1, metadata = metadata || $2
     WHERE id = $3 AND user_id = $4 RETURNING *`, [ocr_text, JSON.stringify(metadata ?? {}), document_id, req.user.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Document not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'OCR scan result saved');
}));
exports.default = router;
//# sourceMappingURL=documents.js.map