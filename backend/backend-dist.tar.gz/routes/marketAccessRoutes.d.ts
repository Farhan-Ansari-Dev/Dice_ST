declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=marketAccessRoutes.d.ts.map