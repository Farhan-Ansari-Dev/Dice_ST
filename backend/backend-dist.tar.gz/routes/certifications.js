"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(auth_1.authenticate);
router.get('/', wrap(async (req, res) => {
    const { page = 1, limit = 20, status, cert_type, search } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    let whereClause = req.user.role === 'admin' ? 'WHERE 1=1' : 'WHERE user_id = $1';
    const params = req.user.role === 'admin' ? [] : [req.user.id];
    let paramIdx = params.length + 1;
    if (status) {
        whereClause += ` AND status = $${paramIdx++}`;
        params.push(status);
    }
    if (cert_type) {
        whereClause += ` AND cert_type = $${paramIdx++}`;
        params.push(cert_type);
    }
    if (search) {
        whereClause += ` AND (product_name ILIKE $${paramIdx} OR cert_number ILIKE $${paramIdx})`;
        paramIdx++;
        params.push(`%${search}%`);
    }
    const countResult = await (0, database_1.query)(`SELECT COUNT(*) FROM certifications ${whereClause}`, params);
    const total = parseInt(countResult.rows[0].count);
    params.push(Number(limit), offset);
    const result = await (0, database_1.query)(`SELECT c.*, u.name as client_name, u.email as client_email, u.company_name
     FROM certifications c LEFT JOIN users u ON c.user_id = u.id
     ${whereClause} ORDER BY c.created_at DESC LIMIT $${paramIdx} OFFSET $${paramIdx + 1}`, params);
    (0, response_1.sendPaginated)(res, result.rows, total, Number(page), Number(limit));
}));
router.get('/expiring-soon', wrap(async (req, res) => {
    const days = parseInt(req.query.days ?? '60');
    const userId = req.user.role === 'admin' ? null : req.user.id;
    const result = await (0, database_1.query)(`SELECT c.*, u.name as client_name, u.email as client_email
     FROM certifications c LEFT JOIN users u ON c.user_id = u.id
     WHERE c.expiry_date BETWEEN NOW() AND NOW() + INTERVAL '${days} days'
     AND c.status = 'active'
     ${userId ? 'AND c.user_id = $1' : ''}
     ORDER BY c.expiry_date ASC`, userId ? [userId] : []);
    (0, response_1.sendSuccess)(res, result.rows);
}));
router.get('/:id', wrap(async (req, res) => {
    const result = await (0, database_1.query)('SELECT c.*, u.name as client_name FROM certifications c LEFT JOIN users u ON c.user_id = u.id WHERE c.id = $1', [req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Certification not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0]);
}));
router.post('/', wrap(async (req, res) => {
    const { cert_type, product_name, product_category, issuing_body, issue_date, expiry_date, cert_number, country, standard_number } = req.body;
    const result = await (0, database_1.query)(`INSERT INTO certifications (user_id, cert_type, product_name, product_category, issuing_body, issue_date, expiry_date, cert_number, country, standard_number)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`, [req.user.id, cert_type, product_name, product_category, issuing_body, issue_date, expiry_date, cert_number, country, standard_number]);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Certification created', 201);
}));
router.put('/:id', wrap(async (req, res) => {
    const { status, product_name, expiry_date, issuing_body } = req.body;
    const result = await (0, database_1.query)('UPDATE certifications SET status=$1, product_name=COALESCE($2,product_name), expiry_date=COALESCE($3,expiry_date), updated_at=NOW() WHERE id=$4 RETURNING *', [status, product_name, expiry_date, req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Certification not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Updated successfully');
}));
router.delete('/:id', wrap(async (req, res) => {
    await (0, database_1.query)('UPDATE certifications SET status=$1, updated_at=NOW() WHERE id=$2', ['revoked', req.params.id]);
    (0, response_1.sendSuccess)(res, null, 'Certification revoked');
}));
exports.default = router;
//# sourceMappingURL=certifications.js.map