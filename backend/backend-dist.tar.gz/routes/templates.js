"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET / — list user's application templates
router.get('/', wrap(async (req, res) => {
    const result = await (0, database_1.query)(`SELECT * FROM application_templates
     WHERE user_id = $1
     ORDER BY usage_count DESC, created_at DESC`, [req.user.id]);
    (0, response_1.sendSuccess)(res, result.rows);
}));
// POST / — save a new template
router.post('/', wrap(async (req, res) => {
    const { name, cert_type, product_name, product_category, notes } = req.body;
    if (!name || !cert_type)
        throw new errorHandler_1.AppError('name and cert_type are required', 400);
    const result = await (0, database_1.query)(`INSERT INTO application_templates (user_id, name, cert_type, product_name, product_category, notes)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`, [req.user.id, name, cert_type, product_name ?? null, product_category ?? null, notes ?? null]);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Template created', 201);
}));
// PUT /:id — update template
router.put('/:id', wrap(async (req, res) => {
    const { name, cert_type, product_name, product_category, notes } = req.body;
    const setClauses = [];
    const params = [];
    if (name !== undefined) {
        params.push(name);
        setClauses.push(`name = $${params.length}`);
    }
    if (cert_type !== undefined) {
        params.push(cert_type);
        setClauses.push(`cert_type = $${params.length}`);
    }
    if (product_name !== undefined) {
        params.push(product_name);
        setClauses.push(`product_name = $${params.length}`);
    }
    if (product_category !== undefined) {
        params.push(product_category);
        setClauses.push(`product_category = $${params.length}`);
    }
    if (notes !== undefined) {
        params.push(notes);
        setClauses.push(`notes = $${params.length}`);
    }
    if (!setClauses.length)
        throw new errorHandler_1.AppError('No fields to update', 400);
    params.push(req.params.id);
    params.push(req.user.id);
    const result = await (0, database_1.query)(`UPDATE application_templates
     SET ${setClauses.join(', ')}
     WHERE id = $${params.length - 1} AND user_id = $${params.length}
     RETURNING *`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Template not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Template updated');
}));
// DELETE /:id — delete template
router.delete('/:id', wrap(async (req, res) => {
    const result = await (0, database_1.query)('DELETE FROM application_templates WHERE id = $1 AND user_id = $2 RETURNING id', [req.params.id, req.user.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Template not found', 404);
    (0, response_1.sendSuccess)(res, null, 'Template deleted');
}));
// POST /:id/use — increment usage count
router.post('/:id/use', wrap(async (req, res) => {
    const result = await (0, database_1.query)(`UPDATE application_templates
     SET usage_count = usage_count + 1, last_used_at = NOW()
     WHERE id = $1 AND user_id = $2 RETURNING *`, [req.params.id, req.user.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Template not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0]);
}));
exports.default = router;
//# sourceMappingURL=templates.js.map