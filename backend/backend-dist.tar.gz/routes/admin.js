"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(auth_1.authenticate, auth_1.requireAdmin);
router.get('/users', wrap(async (req, res) => {
    const { page = 1, limit = 20, role } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const params = [];
    let where = 'WHERE 1=1';
    if (role) {
        where += ` AND role = $${params.length + 1}`;
        params.push(role);
    }
    params.push(Number(limit), offset);
    const result = await (0, database_1.query)(`SELECT id, email, name, phone, role, company_name, is_active, created_at FROM users ${where} ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
    const total = parseInt((await (0, database_1.query)(`SELECT COUNT(*) FROM users ${where}`, role ? [role] : [])).rows[0].count);
    (0, response_1.sendPaginated)(res, result.rows, total, Number(page), Number(limit));
}));
router.put('/users/:id/role', wrap(async (req, res) => {
    const { role } = req.body;
    await (0, database_1.query)('UPDATE users SET role = $1, updated_at = NOW() WHERE id = $2', [role, req.params.id]);
    (0, response_1.sendSuccess)(res, null, 'Role updated');
}));
router.put('/users/:id/status', wrap(async (req, res) => {
    const { is_active } = req.body;
    await (0, database_1.query)('UPDATE users SET is_active = $1, updated_at = NOW() WHERE id = $2', [is_active, req.params.id]);
    (0, response_1.sendSuccess)(res, null, 'Status updated');
}));
exports.default = router;
//# sourceMappingURL=admin.js.map