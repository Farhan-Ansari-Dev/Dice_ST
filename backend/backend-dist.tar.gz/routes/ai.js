"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const authMongo_1 = require("../middleware/authMongo");
const aiService_1 = require("../services/aiService");
const response_1 = require("../utils/response");
const AIConversation_1 = require("../models/AIConversation");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(authMongo_1.authenticate);
router.post('/chat', wrap(async (req, res) => {
    const { message, conversationId } = req.body;
    const result = await aiService_1.aiService.chat(req.user._id.toString(), message, conversationId);
    (0, response_1.sendSuccess)(res, result);
}));
router.get('/conversations', wrap(async (req, res) => {
    const result = await AIConversation_1.AIConversation.find({ user_id: req.user._id }).sort({ updated_at: -1 }).limit(20).lean();
    (0, response_1.sendSuccess)(res, result);
}));
router.get('/conversations/:id', wrap(async (req, res) => {
    const result = await AIConversation_1.AIConversation.findOne({ _id: req.params.id, user_id: req.user._id }).lean();
    (0, response_1.sendSuccess)(res, result ?? null);
}));
router.post('/analyze-document', wrap(async (req, res) => {
    const { text } = req.body;
    const analysis = await aiService_1.aiService.analyzeDocument(text);
    (0, response_1.sendSuccess)(res, analysis);
}));
router.get('/recommendations', wrap(async (req, res) => {
    const recs = await aiService_1.aiService.getComplianceRecommendations(req.user._id.toString());
    (0, response_1.sendSuccess)(res, recs);
}));
exports.default = router;
//# sourceMappingURL=ai.js.map