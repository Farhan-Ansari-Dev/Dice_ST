"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const redis_1 = __importDefault(require("../config/redis"));
const response_1 = require("../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET /dashboard — returns totals, active certs, pending payments, compliance score, trends
router.get('/dashboard', wrap(async (req, res) => {
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';
    const cacheKey = `analytics:dashboard:${userId}`;
    const cached = await redis_1.default.get(cacheKey);
    if (cached) {
        (0, response_1.sendSuccess)(res, JSON.parse(cached));
        return;
    }
    const userFilter = isAdmin ? '' : `WHERE user_id = '${userId}'`;
    const userFilterAnd = isAdmin ? '' : `AND user_id = '${userId}'`;
    const [appsResult, certsResult, paymentsResult, docsResult, monthlyApps,] = await Promise.all([
        (0, database_1.query)(`SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN status IN ('pending','submitted','under_review','in_progress') THEN 1 END) as active,
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
        COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected
       FROM applications ${userFilter}`),
        (0, database_1.query)(`SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
        COUNT(CASE WHEN expiry_date < NOW() + INTERVAL '30 days' AND status = 'active' THEN 1 END) as expiring_soon,
        COUNT(CASE WHEN expiry_date < NOW() AND status = 'active' THEN 1 END) as expired
       FROM certifications ${userFilter}`),
        (0, database_1.query)(`SELECT
        COALESCE(SUM(CASE WHEN status = 'paid' THEN amount END), 0) as total_paid,
        COALESCE(SUM(CASE WHEN status = 'pending' THEN amount END), 0) as pending_amount,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count
       FROM payments ${userFilter}`),
        (0, database_1.query)(`SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN is_verified = true THEN 1 END) as verified
       FROM documents ${userFilter}`),
        (0, database_1.query)(`SELECT
        TO_CHAR(DATE_TRUNC('month', created_at), 'Mon YY') as month,
        COUNT(*) as count
       FROM applications
       WHERE created_at > NOW() - INTERVAL '6 months' ${userFilterAnd}
       GROUP BY DATE_TRUNC('month', created_at)
       ORDER BY DATE_TRUNC('month', created_at) ASC`),
    ]);
    // Get latest compliance score
    const scoreResult = await (0, database_1.query)(`SELECT overall_score FROM compliance_scores WHERE user_id = $1 ORDER BY calculated_at DESC LIMIT 1`, [userId]);
    const data = {
        applications: appsResult.rows[0],
        certifications: certsResult.rows[0],
        payments: paymentsResult.rows[0],
        documents: docsResult.rows[0],
        compliance_score: scoreResult.rows[0]?.overall_score ?? null,
        monthly_trends: monthlyApps.rows,
    };
    await redis_1.default.setex(cacheKey, 180, JSON.stringify(data));
    (0, response_1.sendSuccess)(res, data);
}));
// GET /compliance-score — calculate and return detailed compliance score
router.get('/compliance-score', wrap(async (req, res) => {
    const userId = req.user.id;
    const [certs, apps, docs, payments] = await Promise.all([
        (0, database_1.query)(`SELECT cert_type, status, expiry_date FROM certifications WHERE user_id = $1`, [userId]),
        (0, database_1.query)(`SELECT status FROM applications WHERE user_id = $1`, [userId]),
        (0, database_1.query)(`SELECT is_verified, doc_category FROM documents WHERE user_id = $1`, [userId]),
        (0, database_1.query)(`SELECT status FROM payments WHERE user_id = $1`, [userId]),
    ]);
    // Score calculation logic (0–100 per category)
    const activeCerts = certs.rows.filter(c => c.status === 'active');
    const expiredCerts = certs.rows.filter(c => c.expiry_date && new Date(c.expiry_date) < new Date());
    const certScore = certs.rows.length === 0 ? 50 :
        Math.max(0, Math.round(100 - (expiredCerts.length / certs.rows.length) * 100));
    const approvedApps = apps.rows.filter(a => a.status === 'approved').length;
    const appScore = apps.rows.length === 0 ? 50 :
        Math.round((approvedApps / apps.rows.length) * 100);
    const verifiedDocs = docs.rows.filter(d => d.is_verified).length;
    const docScore = docs.rows.length === 0 ? 50 :
        Math.round((verifiedDocs / docs.rows.length) * 100);
    const paidPayments = payments.rows.filter(p => p.status === 'paid').length;
    const paymentScore = payments.rows.length === 0 ? 100 :
        Math.round((paidPayments / payments.rows.length) * 100);
    const getCertTypeScore = (types) => {
        const relevant = activeCerts.filter(c => types.includes(c.cert_type));
        return relevant.length > 0 ? 85 : 40;
    };
    const bisScore = getCertTypeScore(['BIS', 'bis']);
    const eprScore = getCertTypeScore(['EPR', 'epr']);
    const fssaiScore = getCertTypeScore(['FSSAI', 'fssai']);
    const wpcScore = getCertTypeScore(['WPC', 'wpc']);
    const customsScore = getCertTypeScore(['Customs', 'customs', 'CUSTOMS']);
    const overallScore = Math.round((certScore * 0.25) + (docScore * 0.25) + (appScore * 0.20) +
        (paymentScore * 0.10) + (bisScore * 0.04) + (eprScore * 0.04) +
        (fssaiScore * 0.04) + (wpcScore * 0.04) + (customsScore * 0.04));
    // Persist score
    await (0, database_1.query)(`INSERT INTO compliance_scores (user_id, overall_score, bis_score, epr_score, fssai_score, wpc_score, customs_score, document_score)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [userId, overallScore, bisScore, eprScore, fssaiScore, wpcScore, customsScore, docScore]);
    (0, response_1.sendSuccess)(res, {
        overall_score: overallScore,
        breakdown: {
            certifications: certScore,
            documents: docScore,
            applications: appScore,
            payments: paymentScore,
            bis: bisScore,
            epr: eprScore,
            fssai: fssaiScore,
            wpc: wpcScore,
            customs: customsScore,
        },
        stats: {
            active_certs: activeCerts.length,
            expired_certs: expiredCerts.length,
            verified_docs: verifiedDocs,
            total_docs: docs.rows.length,
        },
    });
}));
// GET /activity — recent activity feed
router.get('/activity', wrap(async (req, res) => {
    const userId = req.user.id;
    const isAdmin = req.user.role === 'admin';
    const { limit = 20 } = req.query;
    const userFilter = isAdmin ? '' : `AND ae.application_id IN (SELECT id FROM applications WHERE user_id = '${userId}')`;
    const [events, notifs] = await Promise.all([
        (0, database_1.query)(`SELECT
         ae.id, ae.event_type, ae.description, ae.created_at,
         a.application_number, a.cert_type,
         u.name as actor_name,
         'application_event' as activity_type
       FROM application_events ae
       LEFT JOIN applications a ON ae.application_id = a.id
       LEFT JOIN users u ON ae.actor_id = u.id
       WHERE true ${userFilter}
       ORDER BY ae.created_at DESC LIMIT $1`, [Number(limit)]),
        (0, database_1.query)(`SELECT id, title, body as description, type, created_at, 'notification' as activity_type
       FROM notifications
       WHERE user_id = $1
       ORDER BY created_at DESC LIMIT $2`, [userId, Number(limit)]),
    ]);
    // Merge and sort by date
    const combined = [...events.rows, ...notifs.rows].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, Number(limit));
    (0, response_1.sendSuccess)(res, combined);
}));
// Keep existing admin-only overview and revenue endpoints
router.get('/overview', wrap(async (_req, res) => {
    const cacheKey = 'analytics:overview';
    const cached = await redis_1.default.get(cacheKey);
    if (cached) {
        (0, response_1.sendSuccess)(res, JSON.parse(cached));
        return;
    }
    const [certs, apps, paymentsData, clients] = await Promise.all([
        (0, database_1.query)("SELECT COUNT(*) as total, COUNT(CASE WHEN status='active' THEN 1 END) as active, COUNT(CASE WHEN expiry_date < NOW() + INTERVAL '60 days' AND status='active' THEN 1 END) as expiring_soon FROM certifications"),
        (0, database_1.query)("SELECT COUNT(*) as total, COUNT(CASE WHEN status IN ('pending','submitted','under_review') THEN 1 END) as pending FROM applications"),
        (0, database_1.query)("SELECT COALESCE(SUM(CASE WHEN status='paid' THEN amount END), 0) as total_paid, COALESCE(SUM(CASE WHEN status='pending' THEN amount END), 0) as pending FROM payments"),
        (0, database_1.query)("SELECT COUNT(*) as total, COUNT(CASE WHEN created_at > NOW() - INTERVAL '30 days' THEN 1 END) as new_this_month FROM users WHERE role='client'"),
    ]);
    const data = { certifications: certs.rows[0], applications: apps.rows[0], payments: paymentsData.rows[0], clients: clients.rows[0] };
    await redis_1.default.setex(cacheKey, 300, JSON.stringify(data));
    (0, response_1.sendSuccess)(res, data);
}));
router.get('/revenue', wrap(async (_req, res) => {
    const result = await (0, database_1.query)(`
    SELECT DATE_TRUNC('month', paid_at) as month, SUM(amount) as revenue, COUNT(*) as count
    FROM payments WHERE status='paid' AND paid_at > NOW() - INTERVAL '12 months'
    GROUP BY DATE_TRUNC('month', paid_at) ORDER BY month ASC
  `);
    (0, response_1.sendSuccess)(res, result.rows);
}));
exports.default = router;
//# sourceMappingURL=analytics.js.map