"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const notificationService_1 = require("../services/notificationService");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET /:applicationId — list tasks for an application
router.get('/:applicationId', wrap(async (req, res) => {
    const { status } = req.query;
    const conditions = ['t.application_id = $1'];
    const params = [req.params.applicationId];
    if (status) {
        params.push(status);
        conditions.push(`t.status = $${params.length}`);
    }
    const result = await (0, database_1.query)(`SELECT t.*,
            au.name as assigned_to_name, au.email as assigned_to_email,
            bu.name as assigned_by_name
     FROM team_tasks t
     LEFT JOIN users au ON t.assigned_to = au.id
     LEFT JOIN users bu ON t.assigned_by = bu.id
     WHERE ${conditions.join(' AND ')}
     ORDER BY t.due_date ASC NULLS LAST, t.created_at DESC`, params);
    (0, response_1.sendSuccess)(res, result.rows);
}));
// POST /:applicationId — create task
router.post('/:applicationId', wrap(async (req, res) => {
    const { title, description, assigned_to, due_date, status = 'pending' } = req.body;
    if (!title)
        throw new errorHandler_1.AppError('title is required', 400);
    // Verify application exists
    const appResult = await (0, database_1.query)('SELECT id FROM applications WHERE id = $1', [req.params.applicationId]);
    if (!appResult.rows.length)
        throw new errorHandler_1.AppError('Application not found', 404);
    const result = await (0, database_1.query)(`INSERT INTO team_tasks (application_id, title, description, assigned_to, assigned_by, status, due_date)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [
        req.params.applicationId,
        title,
        description ?? null,
        assigned_to ?? null,
        req.user.id,
        status,
        due_date ?? null,
    ]);
    // Notify assigned user
    if (assigned_to) {
        await notificationService_1.notificationService.notify(assigned_to, 'New Task Assigned', `You have been assigned a new task: ${title}`, 'task', { task_id: result.rows[0].id, application_id: req.params.applicationId }).catch(() => { });
    }
    (0, response_1.sendSuccess)(res, result.rows[0], 'Task created', 201);
}));
// PUT /:id/status — update task status
router.put('/:id/status', wrap(async (req, res) => {
    const { status } = req.body;
    if (!status)
        throw new errorHandler_1.AppError('status is required', 400);
    const validStatuses = ['pending', 'in_progress', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
        throw new errorHandler_1.AppError(`status must be one of: ${validStatuses.join(', ')}`, 400);
    }
    const completedAt = status === 'completed' ? 'NOW()' : 'NULL';
    const result = await (0, database_1.query)(`UPDATE team_tasks
     SET status = $1, completed_at = ${completedAt}
     WHERE id = $2 RETURNING *`, [status, req.params.id]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Task not found', 404);
    const task = result.rows[0];
    // Notify task creator when completed
    if (status === 'completed' && task.assigned_by && task.assigned_by !== req.user.id) {
        await notificationService_1.notificationService.notify(task.assigned_by, 'Task Completed', `Task "${task.title}" has been marked as completed.`, 'task', { task_id: task.id }).catch(() => { });
    }
    (0, response_1.sendSuccess)(res, result.rows[0], 'Task status updated');
}));
// PUT /:id — update task details
router.put('/:id', wrap(async (req, res) => {
    const { title, description, assigned_to, due_date } = req.body;
    const setClauses = [];
    const params = [];
    if (title !== undefined) {
        params.push(title);
        setClauses.push(`title = $${params.length}`);
    }
    if (description !== undefined) {
        params.push(description);
        setClauses.push(`description = $${params.length}`);
    }
    if (assigned_to !== undefined) {
        params.push(assigned_to);
        setClauses.push(`assigned_to = $${params.length}`);
    }
    if (due_date !== undefined) {
        params.push(due_date);
        setClauses.push(`due_date = $${params.length}`);
    }
    if (!setClauses.length)
        throw new errorHandler_1.AppError('No fields to update', 400);
    params.push(req.params.id);
    const result = await (0, database_1.query)(`UPDATE team_tasks SET ${setClauses.join(', ')} WHERE id = $${params.length} RETURNING *`, params);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Task not found', 404);
    (0, response_1.sendSuccess)(res, result.rows[0], 'Task updated');
}));
exports.default = router;
//# sourceMappingURL=team-tasks.js.map