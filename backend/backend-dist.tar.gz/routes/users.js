"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);
router.use(auth_1.authenticate);
router.get('/me', wrap(async (req, res) => {
    const result = await (0, database_1.query)('SELECT id, email, name, phone, role, company_name, avatar_url, created_at FROM users WHERE id = $1', [req.user.id]);
    (0, response_1.sendSuccess)(res, result.rows[0] ?? null);
}));
router.put('/me', wrap(async (req, res) => {
    const { name, phone, company_name } = req.body;
    const result = await (0, database_1.query)('UPDATE users SET name=COALESCE($1,name), phone=COALESCE($2,phone), company_name=COALESCE($3,company_name), updated_at=NOW() WHERE id=$4 RETURNING id, email, name, phone, company_name, role, avatar_url', [name, phone, company_name, req.user.id]);
    (0, response_1.sendSuccess)(res, result.rows[0]);
}));
exports.default = router;
//# sourceMappingURL=users.js.map