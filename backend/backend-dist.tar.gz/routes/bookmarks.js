"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const database_1 = require("../config/database");
const response_1 = require("../utils/response");
const errorHandler_1 = require("../middleware/errorHandler");
const router = (0, express_1.Router)();
const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
router.use(auth_1.authenticate);
// GET / — list bookmarked insights for user
router.get('/', wrap(async (req, res) => {
    const result = await (0, database_1.query)(`SELECT b.id as bookmark_id, b.created_at as bookmarked_at,
            i.*
     FROM bookmarks b
     JOIN insights i ON b.insight_id = i.id
     WHERE b.user_id = $1
     ORDER BY b.created_at DESC`, [req.user.id]);
    (0, response_1.sendSuccess)(res, result.rows);
}));
// POST /:insightId — bookmark an insight
router.post('/:insightId', wrap(async (req, res) => {
    // Verify insight exists
    const insightResult = await (0, database_1.query)('SELECT id FROM insights WHERE id = $1', [req.params.insightId]);
    if (!insightResult.rows.length)
        throw new errorHandler_1.AppError('Insight not found', 404);
    await (0, database_1.query)(`INSERT INTO bookmarks (user_id, insight_id)
     VALUES ($1, $2)
     ON CONFLICT (user_id, insight_id) DO NOTHING`, [req.user.id, req.params.insightId]);
    (0, response_1.sendSuccess)(res, null, 'Insight bookmarked', 201);
}));
// DELETE /:insightId — remove bookmark
router.delete('/:insightId', wrap(async (req, res) => {
    const result = await (0, database_1.query)('DELETE FROM bookmarks WHERE user_id = $1 AND insight_id = $2 RETURNING id', [req.user.id, req.params.insightId]);
    if (!result.rows.length)
        throw new errorHandler_1.AppError('Bookmark not found', 404);
    (0, response_1.sendSuccess)(res, null, 'Bookmark removed');
}));
exports.default = router;
//# sourceMappingURL=bookmarks.js.map