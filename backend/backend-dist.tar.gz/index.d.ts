/**
 * Sanyog Conformity Solutions — Backend API
 *
 * MongoDB-backed, production-ready entry point.
 * Features: graceful shutdown, error boundaries, Socket.io, rate limiting,
 * helmet, CORS, audit logs, background jobs.
 */
import 'dotenv/config';
//# sourceMappingURL=index.d.ts.map