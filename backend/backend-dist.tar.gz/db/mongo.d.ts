/**
 * MongoDB connection with production-grade settings.
 *
 * In development without a real MongoDB:
 *   - Automatically starts mongodb-memory-server (in-memory MongoDB)
 *   - Zero config needed — just `npm run dev`
 *
 * In production / staging:
 *   - Uses MONGODB_URI or DATABASE_URL environment variable
 *   - Tuned for Atlas M2+ clusters
 */
import mongoose from 'mongoose';
export declare function connectMongo(): Promise<typeof mongoose>;
export declare function disconnectMongo(): Promise<void>;
export declare function pingMongo(): Promise<boolean>;
//# sourceMappingURL=mongo.d.ts.map