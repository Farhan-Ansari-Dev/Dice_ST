import 'dotenv/config';
//# sourceMappingURL=seed-market-access.d.ts.map