"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectMongo = connectMongo;
exports.disconnectMongo = disconnectMongo;
exports.pingMongo = pingMongo;
/**
 * MongoDB connection with production-grade settings.
 *
 * In development without a real MongoDB:
 *   - Automatically starts mongodb-memory-server (in-memory MongoDB)
 *   - Zero config needed — just `npm run dev`
 *
 * In production / staging:
 *   - Uses MONGODB_URI or DATABASE_URL environment variable
 *   - Tuned for Atlas M2+ clusters
 */
const mongoose_1 = __importDefault(require("mongoose"));
const logger_1 = require("../utils/logger");
let isConnected = false;
let memoryServer = null;
async function connectMongo() {
    if (isConnected)
        return mongoose_1.default;
    let uri = process.env.MONGODB_URI || process.env.DATABASE_URL;
    // If no MongoDB URI or it's a PostgreSQL URL, use in-memory MongoDB
    if (!uri || uri.startsWith('postgresql://') || uri.startsWith('postgres://')) {
        logger_1.logger.info('🧪 No MongoDB URI found — starting in-memory MongoDB for development...');
        try {
            const { MongoMemoryServer } = await Promise.resolve().then(() => __importStar(require('mongodb-memory-server')));
            memoryServer = await MongoMemoryServer.create({
                instance: { dbName: 'sanyog_conformity' },
            });
            uri = memoryServer.getUri();
            logger_1.logger.info(`✅ In-memory MongoDB started at ${uri}`);
        }
        catch (err) {
            logger_1.logger.error('Failed to start in-memory MongoDB. Install it: npm i -D mongodb-memory-server', err);
            throw err;
        }
    }
    // Connection event listeners
    mongoose_1.default.connection.on('connected', () => {
        isConnected = true;
        logger_1.logger.info(`✅ MongoDB connected: ${mongoose_1.default.connection.host}/${mongoose_1.default.connection.name}`);
    });
    mongoose_1.default.connection.on('disconnected', () => {
        isConnected = false;
        logger_1.logger.warn('⚠️  MongoDB disconnected');
    });
    mongoose_1.default.connection.on('error', (err) => {
        logger_1.logger.error('MongoDB error:', err);
    });
    mongoose_1.default.connection.on('reconnected', () => {
        logger_1.logger.info('MongoDB reconnected');
    });
    await mongoose_1.default.connect(uri, {
        maxPoolSize: 50,
        minPoolSize: 5,
        serverSelectionTimeoutMS: 10000,
        heartbeatFrequencyMS: 10000,
        retryWrites: true,
        w: 'majority',
        autoIndex: process.env.NODE_ENV !== 'production',
    });
    return mongoose_1.default;
}
async function disconnectMongo() {
    if (!isConnected)
        return;
    await mongoose_1.default.disconnect();
    if (memoryServer) {
        await memoryServer.stop();
        memoryServer = null;
    }
    isConnected = false;
}
async function pingMongo() {
    try {
        if (!isConnected)
            return false;
        await mongoose_1.default.connection.db?.admin().ping();
        return true;
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=mongo.js.map