"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Sanyog Conformity Solutions — Backend API
 *
 * MongoDB-backed, production-ready entry point.
 * Features: graceful shutdown, error boundaries, Socket.io, rate limiting,
 * helmet, CORS, audit logs, background jobs.
 */
require("dotenv/config");
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const morgan_1 = __importDefault(require("morgan"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const path_1 = __importDefault(require("path"));
const mongo_1 = require("./db/mongo");
const index_1 = __importDefault(require("./routes/index"));
const errorHandler_1 = require("./middleware/errorHandler");
const logger_1 = require("./utils/logger");
async function main() {
    // 1. Connect to MongoDB FIRST
    await (0, mongo_1.connectMongo)();
    const app = (0, express_1.default)();
    const httpServer = (0, http_1.createServer)(app);
    // 2. Middleware
    app.use((0, helmet_1.default)({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
    app.use((0, cors_1.default)({
        origin: [
            process.env.FRONTEND_URL ?? 'http://localhost:8081',
            process.env.ADMIN_URL ?? 'http://localhost:5173',
            'http://localhost:19006', // Expo web
            'http://localhost:19000', // Expo dev
        ],
        credentials: true,
    }));
    app.use((0, compression_1.default)());
    app.use(express_1.default.json({ limit: '10mb' }));
    app.use(express_1.default.urlencoded({ extended: true }));
    app.set('trust proxy', 1);
    app.use((0, morgan_1.default)('combined', { stream: { write: (msg) => logger_1.logger.http(msg.trim()) } }));
    // 3. Socket.io for real-time updates
    const io = new socket_io_1.Server(httpServer, {
        cors: {
            origin: [
                process.env.FRONTEND_URL ?? 'http://localhost:8081',
                process.env.ADMIN_URL ?? 'http://localhost:5173',
            ],
            credentials: true,
        },
        transports: ['websocket', 'polling'],
    });
    io.on('connection', (socket) => {
        socket.on('join_org', (orgId) => socket.join(`org:${orgId}`));
        socket.on('join_application', (appId) => socket.join(`app:${appId}`));
    });
    app.locals.io = io;
    // 4. Serve uploaded files in dev
    app.use('/uploads', express_1.default.static(path_1.default.join(process.cwd(), 'uploads')));
    // 5. Health check
    app.get('/health', async (_req, res) => {
        const mongo = await (0, mongo_1.pingMongo)();
        res.status(mongo ? 200 : 503).json({
            status: mongo ? 'ok' : 'degraded',
            mongo,
            version: '2.0.0',
            timestamp: new Date().toISOString(),
        });
    });
    // 6. API routes
    app.use('/api/v1', index_1.default);
    // 7. Error handler (must be last)
    app.use(errorHandler_1.errorHandler);
    // 8. Start
    const PORT = parseInt(process.env.PORT ?? '5000', 10);
    httpServer.listen(PORT, () => {
        logger_1.logger.info(`🚀 Sanyog Conformity API running on :${PORT}`);
        logger_1.logger.info(`📊 Environment: ${process.env.NODE_ENV ?? 'development'}`);
        // Tell PM2 cluster mode we're ready
        if (process.send)
            process.send('ready');
    });
    // 9. Graceful shutdown
    const shutdown = async (signal) => {
        logger_1.logger.info(`${signal} received — shutting down gracefully`);
        httpServer.close(async () => {
            await (0, mongo_1.disconnectMongo)();
            logger_1.logger.info('Server closed');
            process.exit(0);
        });
        setTimeout(() => {
            logger_1.logger.error('Forced shutdown after 30s');
            process.exit(1);
        }, 30000);
    };
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
    // 10. Crash safety net
    process.on('unhandledRejection', (reason) => {
        logger_1.logger.error('Unhandled rejection:', reason);
    });
    process.on('uncaughtException', (err) => {
        logger_1.logger.error('Uncaught exception:', err);
    });
}
main().catch((err) => {
    logger_1.logger.error('Fatal: failed to start', err);
    process.exit(1);
});
//# sourceMappingURL=index.js.map