"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketAccessService = void 0;
const MarketRequirement_1 = __importDefault(require("../models/MarketRequirement"));
class MarketAccessService {
    static async calculateMarketAccess(categoryId, ownedCertificationIds) {
        const requirements = await MarketRequirement_1.default.find({ productCategoryId: categoryId })
            .populate('requiredCertifications')
            .populate('optionalCertifications');
        const result = {
            readyMarkets: [],
            partialMarkets: [],
            blockedMarkets: [],
        };
        const ownedSet = new Set(ownedCertificationIds.map(id => id.toString()));
        for (const req of requirements) {
            const requiredCerts = req.requiredCertifications;
            const missingCerts = [];
            let ownedRequiredCount = 0;
            for (const cert of requiredCerts) {
                if (ownedSet.has(cert._id.toString())) {
                    ownedRequiredCount++;
                }
                else {
                    missingCerts.push(cert.certificationName);
                }
            }
            const totalRequired = requiredCerts.length;
            let score = 100;
            if (totalRequired > 0) {
                score = Math.round((ownedRequiredCount / totalRequired) * 100);
            }
            const marketData = {
                country: req.country,
                score,
                missing: missingCerts,
            };
            if (score === 100) {
                result.readyMarkets.push(marketData);
            }
            else if (score > 0) {
                result.partialMarkets.push(marketData);
            }
            else {
                result.blockedMarkets.push(marketData);
            }
        }
        return result;
    }
}
exports.MarketAccessService = MarketAccessService;
//# sourceMappingURL=marketAccessService.js.map