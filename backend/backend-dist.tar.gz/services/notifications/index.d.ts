/**
 * Unified Notification Service — single entry point for all channels.
 *
 * Channels:
 *   1. in_app    — MongoDB Notification document (always recorded)
 *   2. push      — Mobile (Expo Push API) + Web (Web Push API / VAPID)
 *   3. email     — AWS SES (transactional)
 *   4. sms       — MSG91 (Indian numbers) or Twilio (international)
 *
 * Channel selection: derived from notification type + user preferences.
 * Failures in one channel do NOT block others. All channels are logged.
 *
 * Usage:
 *   import { notify } from './services/notifications';
 *
 *   await notify({
 *     user_id: user._id,
 *     type: 'cert_expiry_30d',
 *     title: '⚠️ Certificate Expiring',
 *     body: 'Your BIS cert CM/L-7654321 expires in 30 days. Initiate renewal now.',
 *     data: { cert_id: cert._id, deep_link: 'dice://certs/' + cert._id },
 *     channels: ['in_app', 'push', 'email'],
 *   });
 */
import { Types } from 'mongoose';
export type NotificationChannel = 'in_app' | 'push' | 'email' | 'sms';
export interface NotifyInput {
    user_id: Types.ObjectId | string;
    type: string;
    title: string;
    body: string;
    data?: Record<string, any>;
    channels?: NotificationChannel[];
    resource_type?: string;
    resource_id?: Types.ObjectId | string;
    priority?: 'low' | 'normal' | 'high';
    email_template?: string;
}
/**
 * Send a notification across selected channels.
 * Returns delivery status per channel.
 */
export declare function notify(input: NotifyInput): Promise<{
    in_app: boolean;
    push?: {
        mobile: boolean;
        web: boolean;
    };
    email?: boolean;
    sms?: boolean;
}>;
/**
 * Helper: bulk notify (for cron jobs like expiry reminders).
 * Limits concurrency to avoid hammering external APIs.
 */
export declare function bulkNotify(inputs: NotifyInput[], concurrency?: number): Promise<void>;
//# sourceMappingURL=index.d.ts.map