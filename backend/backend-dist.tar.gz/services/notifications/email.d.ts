export interface EmailInput {
    to: string;
    subject: string;
    body: string;
    template?: string;
    data?: Record<string, any>;
    reply_to?: string;
}
export declare function sendEmail(input: EmailInput): Promise<boolean>;
//# sourceMappingURL=email.d.ts.map