export interface SMSInput {
    to: string;
    text: string;
    country_code?: string;
    template_id?: string;
    variables?: Record<string, string>;
}
export declare function sendSMS(input: SMSInput): Promise<boolean>;
//# sourceMappingURL=sms.d.ts.map