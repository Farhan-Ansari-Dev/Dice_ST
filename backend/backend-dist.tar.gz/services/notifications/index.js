"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.notify = notify;
exports.bulkNotify = bulkNotify;
const models_1 = require("../../models");
const push_1 = require("./push");
const email_1 = require("./email");
const sms_1 = require("./sms");
const logger_1 = require("../../utils/logger");
/**
 * Send a notification across selected channels.
 * Returns delivery status per channel.
 */
async function notify(input) {
    const user = await models_1.User.findById(input.user_id);
    if (!user) {
        logger_1.logger.warn(`[notify] user ${input.user_id} not found`);
        return { in_app: false };
    }
    // Determine channels (caller override OR user preference defaults)
    const channels = input.channels ?? defaultChannelsFor(input.type, user);
    const result = { in_app: false };
    // 1. Always record in-app notification (cheap, source of truth)
    const notif = await models_1.Notification.create({
        user_id: user._id,
        type: input.type,
        title: input.title,
        body: input.body,
        data: input.data ?? {},
        channels,
        delivered_channels: ['in_app'],
        resource_type: input.resource_type,
        resource_id: input.resource_id,
    });
    result.in_app = true;
    // Track delivered channels for analytics
    const delivered = ['in_app'];
    // 2. Push — fire-and-forget in parallel for speed
    if (channels.includes('push') && user.expo_push_tokens?.length) {
        result.push = { mobile: false, web: false };
        // Mobile push (Expo)
        try {
            const tickets = await (0, push_1.sendExpoPush)({
                tokens: user.expo_push_tokens,
                title: input.title,
                body: input.body,
                data: input.data,
                priority: input.priority,
            });
            result.push.mobile = tickets.some(t => t.status === 'ok');
            if (result.push.mobile)
                delivered.push('push:mobile');
        }
        catch (err) {
            logger_1.logger.error('[notify] mobile push failed', err);
        }
    }
    if (channels.includes('push') && user.webpush_subscriptions?.length) {
        // Web push (VAPID)
        try {
            const ok = await (0, push_1.sendWebPush)({
                subscriptions: user.webpush_subscriptions,
                title: input.title,
                body: input.body,
                data: input.data,
                url: input.data?.deep_link,
            });
            if (result.push)
                result.push.web = ok;
            if (ok)
                delivered.push('push:web');
        }
        catch (err) {
            logger_1.logger.error('[notify] web push failed', err);
        }
    }
    // 3. Email
    if (channels.includes('email') && user.email) {
        try {
            const ok = await (0, email_1.sendEmail)({
                to: user.email,
                subject: input.title,
                body: input.body,
                template: input.email_template ?? input.type,
                data: { ...input.data, user_name: user.name },
            });
            result.email = ok;
            if (ok)
                delivered.push('email');
        }
        catch (err) {
            logger_1.logger.error('[notify] email failed', err);
        }
    }
    // 4. SMS (only for critical events, Indian users)
    if (channels.includes('sms') && user.phone) {
        try {
            const ok = await (0, sms_1.sendSMS)({
                to: user.phone,
                text: `${input.title}: ${input.body.slice(0, 100)}...`,
                country_code: user.country_code,
            });
            result.sms = ok;
            if (ok)
                delivered.push('sms');
        }
        catch (err) {
            logger_1.logger.error('[notify] sms failed', err);
        }
    }
    // Update notification record with actual delivered channels
    await models_1.Notification.updateOne({ _id: notif._id }, { $set: { delivered_channels: delivered } });
    return result;
}
/**
 * Choose channels based on notification type + user preferences.
 *
 * Defaults (overridable per user via Organization.settings.notification_preferences):
 *   - Critical (cert revoked, payment failed)     → in_app + push + email + sms
 *   - Time-sensitive (expiry < 7 days, doc due)   → in_app + push + email
 *   - Routine (status change, comment)            → in_app + push
 *   - Marketing                                   → email only (if opted in)
 */
function defaultChannelsFor(type, user) {
    // Critical events — multi-channel
    if (type.startsWith('cert_revoked') ||
        type.startsWith('payment_failed') ||
        type.startsWith('security_alert') ||
        type === 'login_from_new_device') {
        return ['in_app', 'push', 'email', 'sms'];
    }
    // Time-sensitive
    if (type.startsWith('cert_expiry_') || // _7d, _30d, _90d
        type === 'app_docs_required' ||
        type === 'cert_issued' ||
        type === 'payment_received') {
        return ['in_app', 'push', 'email'];
    }
    // Routine app updates
    if (type.startsWith('app_status_changed') ||
        type === 'comment_mention' ||
        type === 'task_assigned') {
        return ['in_app', 'push'];
    }
    // Marketing / weekly digest
    if (type.startsWith('marketing_') || type === 'weekly_digest') {
        return user.consents?.marketing ? ['email'] : [];
    }
    // Default — in-app + push
    return ['in_app', 'push'];
}
/**
 * Helper: bulk notify (for cron jobs like expiry reminders).
 * Limits concurrency to avoid hammering external APIs.
 */
async function bulkNotify(inputs, concurrency = 10) {
    for (let i = 0; i < inputs.length; i += concurrency) {
        const batch = inputs.slice(i, i + concurrency);
        await Promise.allSettled(batch.map(input => notify(input)));
    }
}
//# sourceMappingURL=index.js.map