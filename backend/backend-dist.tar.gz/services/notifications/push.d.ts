/**
 * Push notification adapters:
 *   - Expo Push API (mobile iOS + Android)
 *   - Web Push API / VAPID (PWA, web admin portal)
 *
 * Why Expo (not FCM/APNs directly)?
 *   - Same API works for iOS + Android (one less integration)
 *   - Handles APNs cert rotation and FCM token refresh transparently
 *   - Free up to 1000 messages/sec — covers any startup-scale traffic
 *
 * Why Web Push API (not FCM Web)?
 *   - Native browser API, no Firebase dependency
 *   - GDPR-friendly: data never leaves your servers
 *   - Free, no rate limits
 */
import { ExpoPushTicket } from 'expo-server-sdk';
export interface ExpoPushInput {
    tokens: string[];
    title: string;
    body: string;
    data?: Record<string, any>;
    priority?: 'low' | 'normal' | 'high';
    sound?: 'default' | null;
    badge?: number;
    channelId?: string;
}
export declare function sendExpoPush(input: ExpoPushInput): Promise<ExpoPushTicket[]>;
/**
 * Process Expo's delivery receipts (async — call this on a cron).
 * Receipts tell you if Apple/Google actually delivered the push.
 */
export declare function checkExpoReceipts(ticketIds: string[]): Promise<Record<string, any>>;
export interface WebPushSubscription {
    endpoint: string;
    keys: {
        p256dh: string;
        auth: string;
    };
}
export interface WebPushInput {
    subscriptions: WebPushSubscription[];
    title: string;
    body: string;
    data?: Record<string, any>;
    url?: string;
    icon?: string;
    badge?: string;
}
export declare function sendWebPush(input: WebPushInput): Promise<boolean>;
//# sourceMappingURL=push.d.ts.map