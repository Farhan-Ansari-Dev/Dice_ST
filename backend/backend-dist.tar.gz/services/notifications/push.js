"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendExpoPush = sendExpoPush;
exports.checkExpoReceipts = checkExpoReceipts;
exports.sendWebPush = sendWebPush;
/**
 * Push notification adapters:
 *   - Expo Push API (mobile iOS + Android)
 *   - Web Push API / VAPID (PWA, web admin portal)
 *
 * Why Expo (not FCM/APNs directly)?
 *   - Same API works for iOS + Android (one less integration)
 *   - Handles APNs cert rotation and FCM token refresh transparently
 *   - Free up to 1000 messages/sec — covers any startup-scale traffic
 *
 * Why Web Push API (not FCM Web)?
 *   - Native browser API, no Firebase dependency
 *   - GDPR-friendly: data never leaves your servers
 *   - Free, no rate limits
 */
const expo_server_sdk_1 = require("expo-server-sdk");
const webpush = __importStar(require("web-push"));
const logger_1 = require("../../utils/logger");
const expo = new expo_server_sdk_1.Expo({
    accessToken: process.env.EXPO_ACCESS_TOKEN,
});
// VAPID is the auth mechanism for Web Push.
// Generate ONCE: npx web-push generate-vapid-keys
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
    webpush.setVapidDetails(process.env.VAPID_SUBJECT ?? 'mailto:admin@sanyogconformity.com', process.env.VAPID_PUBLIC_KEY, process.env.VAPID_PRIVATE_KEY);
}
async function sendExpoPush(input) {
    const validTokens = input.tokens.filter(t => expo_server_sdk_1.Expo.isExpoPushToken(t));
    if (validTokens.length === 0) {
        logger_1.logger.debug('[push] no valid Expo tokens');
        return [];
    }
    const messages = validTokens.map(token => ({
        to: token,
        title: input.title,
        body: input.body,
        data: input.data ?? {},
        sound: input.sound === null ? null : 'default',
        priority: input.priority === 'high' ? 'high' : 'default',
        badge: input.badge,
        channelId: input.channelId ?? 'default',
        ttl: 86400, // 24h — drops stale messages
        mutableContent: true, // iOS: allow notification service extension
    }));
    // Expo batches up to 100 per request
    const chunks = expo.chunkPushNotifications(messages);
    const tickets = [];
    for (const chunk of chunks) {
        try {
            const chunkTickets = await expo.sendPushNotificationsAsync(chunk);
            tickets.push(...chunkTickets);
        }
        catch (err) {
            logger_1.logger.error('[push:expo] chunk failed', err);
        }
    }
    // Log errors per token (lets you clean up dead tokens later)
    tickets.forEach((ticket, i) => {
        if (ticket.status === 'error') {
            const token = validTokens[i];
            logger_1.logger.warn(`[push:expo] error for ${token.slice(0, 20)}...: ${ticket.message}`);
            // Common failure: DeviceNotRegistered → remove token from user record
            if (ticket.details?.error === 'DeviceNotRegistered') {
                // Caller should clean up — return enough info
                ticket.cleanup_token = token;
            }
        }
    });
    return tickets;
}
/**
 * Process Expo's delivery receipts (async — call this on a cron).
 * Receipts tell you if Apple/Google actually delivered the push.
 */
async function checkExpoReceipts(ticketIds) {
    const chunks = expo.chunkPushNotificationReceiptIds(ticketIds);
    const allReceipts = {};
    for (const chunk of chunks) {
        try {
            const receipts = await expo.getPushNotificationReceiptsAsync(chunk);
            Object.assign(allReceipts, receipts);
        }
        catch (err) {
            logger_1.logger.error('[push:expo:receipts] failed', err);
        }
    }
    return allReceipts;
}
async function sendWebPush(input) {
    if (!process.env.VAPID_PUBLIC_KEY) {
        logger_1.logger.warn('[push:web] VAPID not configured — skipping');
        return false;
    }
    const payload = JSON.stringify({
        title: input.title,
        body: input.body,
        data: input.data ?? {},
        url: input.url ?? '/',
        icon: input.icon ?? '/icon-192.png',
        badge: input.badge ?? '/badge-72.png',
    });
    const results = await Promise.allSettled(input.subscriptions.map(sub => webpush.sendNotification(sub, payload, {
        TTL: 86400,
        urgency: 'normal',
    })));
    let delivered = 0;
    results.forEach((r, i) => {
        if (r.status === 'fulfilled') {
            delivered++;
        }
        else {
            const err = r.reason;
            // 410 Gone = subscription expired — caller should remove from DB
            if (err.statusCode === 410 || err.statusCode === 404) {
                logger_1.logger.debug(`[push:web] removing expired subscription ${input.subscriptions[i].endpoint.slice(0, 40)}...`);
            }
            else {
                logger_1.logger.error('[push:web] send failed', err.message);
            }
        }
    });
    return delivered > 0;
}
//# sourceMappingURL=push.js.map