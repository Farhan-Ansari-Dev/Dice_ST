"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.razorpayService = void 0;
const razorpay_1 = __importDefault(require("razorpay"));
const crypto_1 = __importDefault(require("crypto"));
const Payment_1 = require("../models/Payment");
const User_1 = require("../models/User");
const notificationService_1 = require("./notificationService");
const logger_1 = require("../utils/logger");
const razorpay = new razorpay_1.default({
    key_id: process.env.RAZORPAY_KEY_ID ?? 'rzp_test_placeholder',
    key_secret: process.env.RAZORPAY_KEY_SECRET ?? 'placeholder',
});
exports.razorpayService = {
    async createOrder(userId, applicationId, amount, description) {
        const amountPaise = Math.round(amount * 100);
        const order = await razorpay.orders.create({
            amount: amountPaise,
            currency: 'INR',
            notes: {
                userId,
                applicationId: applicationId ?? '',
                description,
            },
        });
        const user = await User_1.User.findById(userId);
        const orgId = user?.org_id || undefined;
        const invNum = `INV-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
        const payment = await Payment_1.Payment.create({
            org_id: orgId,
            user_id: userId,
            application_id: applicationId || undefined,
            amount_paise: amountPaise,
            total_paise: amountPaise,
            description,
            purpose: 'other',
            invoice_number: invNum,
            razorpay_order_id: order.id,
            status: 'pending',
        });
        return { order, payment };
    },
    async verifyPayment(orderId, paymentId, signature, userId) {
        const body = `${orderId}|${paymentId}`;
        const expected = crypto_1.default
            .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET ?? '')
            .update(body)
            .digest('hex');
        if (expected !== signature) {
            logger_1.logger.warn(`Razorpay signature mismatch for order ${orderId}`);
            return false;
        }
        await Payment_1.Payment.updateOne({ razorpay_order_id: orderId }, {
            $set: {
                status: 'captured',
                razorpay_payment_id: paymentId,
                razorpay_signature: signature,
                captured_at: new Date()
            }
        });
        await notificationService_1.notificationService.notify(userId, 'Payment Successful', 'Your payment has been processed successfully.', 'payment');
        return true;
    },
    async handleWebhook(payload, signature) {
        const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET ?? '';
        try {
            razorpay_1.default.validateWebhookSignature(payload, signature, webhookSecret);
            return true;
        }
        catch {
            return false;
        }
    },
};
//# sourceMappingURL=razorpayService.js.map