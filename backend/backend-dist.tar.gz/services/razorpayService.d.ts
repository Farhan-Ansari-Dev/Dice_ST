export declare const razorpayService: {
    createOrder(userId: string, applicationId: string | null, amount: number, description: string): Promise<{
        order: import("razorpay/dist/types/orders").Orders.RazorpayOrder;
        payment: import("mongoose").Document<unknown, {}, import("../models/Payment").IPayment, {}, import("mongoose").DefaultSchemaOptions> & import("../models/Payment").IPayment & Required<{
            _id: import("mongoose").Types.ObjectId;
        }> & {
            __v: number;
        } & {
            id: string;
        };
    }>;
    verifyPayment(orderId: string, paymentId: string, signature: string, userId: string): Promise<boolean>;
    handleWebhook(payload: string, signature: string): Promise<boolean>;
};
//# sourceMappingURL=razorpayService.d.ts.map