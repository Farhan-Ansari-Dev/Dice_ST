import { Types } from 'mongoose';
export interface PresignUploadInput {
    org_id: Types.ObjectId;
    user_id: Types.ObjectId;
    filename: string;
    mime_type: string;
    size_bytes: number;
    sha256: string;
    doc_type: string;
    document_id?: Types.ObjectId;
}
export declare const documentService: {
    /**
     * Step 1: Generate presigned URL for direct browser-to-S3 upload.
     */
    presignUpload(input: PresignUploadInput): Promise<{
        url: string;
        s3_key: string;
        expires_in: number;
        version_number: number;
    }>;
    /**
     * Step 2: After client uploads, verify the object exists and record metadata.
     */
    finalizeUpload(input: {
        org_id: Types.ObjectId;
        user_id: Types.ObjectId;
        s3_key: string;
        document_id?: Types.ObjectId;
        name: string;
        doc_type: string;
        mime_type: string;
        size_bytes: number;
        sha256: string;
        change_reason?: string;
        application_id?: Types.ObjectId;
        description?: string;
        tags?: string[];
        ip?: string;
        user_agent?: string;
    }): Promise<{
        document: (import("mongoose").Document<unknown, {}, import("../models").IDocument, {}, import("mongoose").DefaultSchemaOptions> & import("../models").IDocument & Required<{
            _id: Types.ObjectId;
        }> & {
            __v: number;
        } & {
            id: string;
        }) | null;
        version: import("mongoose").Document<unknown, {}, import("../models").IDocumentVersion, {}, import("mongoose").DefaultSchemaOptions> & import("../models").IDocumentVersion & Required<{
            _id: Types.ObjectId;
        }> & {
            __v: number;
        } & {
            id: string;
        };
    }>;
    /**
     * Generate a time-limited download URL for a specific version.
     * Default = current version.
     */
    getDownloadUrl(documentId: Types.ObjectId, versionNumber?: number, requesterId?: Types.ObjectId): Promise<string>;
    /**
     * List all versions of a document (for audit / history UI).
     */
    listVersions(documentId: Types.ObjectId): Promise<(import("mongoose").Document<unknown, {}, import("../models").IDocumentVersion, {}, import("mongoose").DefaultSchemaOptions> & import("../models").IDocumentVersion & Required<{
        _id: Types.ObjectId;
    }> & {
        __v: number;
    } & {
        id: string;
    })[]>;
};
//# sourceMappingURL=documentService.d.ts.map