"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authService = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const google_auth_library_1 = require("google-auth-library");
const database_1 = require("../config/database");
const redis_1 = __importDefault(require("../config/redis"));
const emailService_1 = require("./emailService");
const errorHandler_1 = require("../middleware/errorHandler");
const logger_1 = require("../utils/logger");
const googleClient = new google_auth_library_1.OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const generateOTPCode = () => Math.floor(100000 + Math.random() * 900000).toString();
const generateTokens = (userId, email, role) => {
    const accessToken = jsonwebtoken_1.default.sign({ userId, email, role }, process.env.JWT_SECRET, { expiresIn: '15m' });
    const refreshToken = jsonwebtoken_1.default.sign({ userId, email, role }, process.env.JWT_REFRESH_SECRET, { expiresIn: '7d' });
    return { accessToken, refreshToken };
};
exports.authService = {
    async sendOTP(email) {
        // Rate limit: max 5 OTPs per hour per email
        const key = `otp_rate:${email}`;
        const count = await redis_1.default.incr(key);
        if (count === 1)
            await redis_1.default.expire(key, 3600);
        if (count > 5)
            throw new errorHandler_1.AppError('Too many OTP requests. Please try again in 1 hour.', 429);
        const otp = generateOTPCode();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
        // Invalidate previous OTPs
        await (0, database_1.query)('UPDATE otp_tokens SET is_used = true WHERE email = $1 AND is_used = false', [email]);
        // Store new OTP
        await (0, database_1.query)('INSERT INTO otp_tokens (email, otp, expires_at) VALUES ($1, $2, $3)', [email, otp, expiresAt]);
        // Cache OTP in Redis for fast lookup
        await redis_1.default.setex(`otp:${email}`, 600, otp);
        // Send email
        await emailService_1.emailService.sendOTP(email, otp);
        logger_1.logger.info(`OTP sent to ${email}`);
    },
    async verifyOTP(email, otp) {
        // Check Redis first (fast path)
        const cachedOTP = await redis_1.default.get(`otp:${email}`);
        if (cachedOTP !== otp) {
            // Fallback to DB
            const result = await (0, database_1.query)('SELECT * FROM otp_tokens WHERE email = $1 AND otp = $2 AND is_used = false AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1', [email, otp]);
            if (!result.rows.length)
                throw new errorHandler_1.AppError('Invalid or expired OTP', 400);
            await (0, database_1.query)('UPDATE otp_tokens SET is_used = true WHERE id = $1', [result.rows[0].id]);
        }
        // Invalidate Redis cache
        await redis_1.default.del(`otp:${email}`);
        await redis_1.default.del(`otp_rate:${email}`);
        // Upsert user
        const userResult = await (0, database_1.query)(`INSERT INTO users (email, is_verified) VALUES ($1, true)
       ON CONFLICT (email) DO UPDATE SET is_verified = true, updated_at = NOW()
       RETURNING *`, [email]);
        const user = userResult.rows[0];
        const tokens = generateTokens(user.id, user.email, user.role);
        // Store refresh token in Redis
        await redis_1.default.setex(`refresh:${user.id}`, 7 * 24 * 3600, tokens.refreshToken);
        return { ...tokens, user: { id: user.id, email: user.email, name: user.name, role: user.role, avatar_url: user.avatar_url } };
    },
    async googleSignIn(idToken) {
        const ticket = await googleClient.verifyIdToken({
            idToken,
            audience: process.env.GOOGLE_CLIENT_ID,
        });
        const payload = ticket.getPayload();
        if (!payload?.email)
            throw new errorHandler_1.AppError('Invalid Google token', 400);
        const userResult = await (0, database_1.query)(`INSERT INTO users (email, name, google_id, avatar_url, is_verified)
       VALUES ($1, $2, $3, $4, true)
       ON CONFLICT (email) DO UPDATE SET name = COALESCE(users.name, $2), google_id = $3, avatar_url = COALESCE(users.avatar_url, $4), updated_at = NOW()
       RETURNING *`, [payload.email, payload.name, payload.sub, payload.picture]);
        const user = userResult.rows[0];
        const tokens = generateTokens(user.id, user.email, user.role);
        await redis_1.default.setex(`refresh:${user.id}`, 7 * 24 * 3600, tokens.refreshToken);
        return { ...tokens, user: { id: user.id, email: user.email, name: user.name, role: user.role, avatar_url: user.avatar_url } };
    },
    async refreshTokens(refreshToken) {
        try {
            const decoded = jsonwebtoken_1.default.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
            const stored = await redis_1.default.get(`refresh:${decoded.userId}`);
            if (stored !== refreshToken)
                throw new errorHandler_1.AppError('Refresh token revoked', 401);
            const tokens = generateTokens(decoded.userId, decoded.email, decoded.role);
            await redis_1.default.setex(`refresh:${decoded.userId}`, 7 * 24 * 3600, tokens.refreshToken);
            return tokens;
        }
        catch {
            throw new errorHandler_1.AppError('Invalid refresh token', 401);
        }
    },
    async logout(userId) {
        await redis_1.default.del(`refresh:${userId}`);
    },
};
//# sourceMappingURL=authService.js.map