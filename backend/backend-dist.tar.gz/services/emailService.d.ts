export declare const emailService: {
    sendOTP(email: string, otp: string): Promise<void>;
    sendCertificationExpiry(email: string, certNumber: string, expiryDate: string, daysLeft: number): Promise<void>;
};
//# sourceMappingURL=emailService.d.ts.map