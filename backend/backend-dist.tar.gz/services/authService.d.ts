export declare const authService: {
    sendOTP(email: string): Promise<void>;
    verifyOTP(email: string, otp: string): Promise<{
        accessToken: string;
        refreshToken: string;
        user: any;
    }>;
    googleSignIn(idToken: string): Promise<{
        accessToken: string;
        refreshToken: string;
        user: any;
    }>;
    refreshTokens(refreshToken: string): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(userId: string): Promise<void>;
};
//# sourceMappingURL=authService.d.ts.map