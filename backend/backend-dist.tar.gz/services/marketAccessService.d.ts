export interface MarketAccessOutput {
    readyMarkets: Array<{
        country: string;
        score: number;
        missing: string[];
    }>;
    partialMarkets: Array<{
        country: string;
        score: number;
        missing: string[];
    }>;
    blockedMarkets: Array<{
        country: string;
        score: number;
        missing: string[];
    }>;
}
export declare class MarketAccessService {
    static calculateMarketAccess(categoryId: string, ownedCertificationIds: string[]): Promise<MarketAccessOutput>;
}
//# sourceMappingURL=marketAccessService.d.ts.map