"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.notificationService = void 0;
const User_1 = require("../models/User");
const Notification_1 = require("../models/Notification");
const logger_1 = require("../utils/logger");
exports.notificationService = {
    async sendPush(userId, title, body, data) {
        try {
            const user = await User_1.User.findById(userId).select('expo_push_tokens');
            if (!user || !user.expo_push_tokens || user.expo_push_tokens.length === 0)
                return;
            const messages = user.expo_push_tokens.map(token => ({
                to: token,
                sound: 'default',
                title,
                body,
                data: data ?? {},
                priority: 'high',
            }));
            const response = await fetch('https://exp.host/--/api/v2/push/send', {
                method: 'POST',
                headers: {
                    Accept: 'application/json',
                    'Accept-Encoding': 'gzip, deflate',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(messages),
            });
            const responseData = await response.json();
            logger_1.logger.info(`Push sent to user ${userId}: ${title}`, responseData);
        }
        catch (err) {
            logger_1.logger.error(`Failed to send push notification to user ${userId}`, err);
        }
    },
    async saveToDatabase(userId, title, body, type = 'system', metadata) {
        try {
            await Notification_1.Notification.create({
                user_id: userId,
                title,
                body,
                type,
                data: metadata ?? {},
            });
        }
        catch (err) {
            logger_1.logger.error(`Failed to save notification for user ${userId}`, err);
        }
    },
    async notify(userId, title, body, type = 'system', data) {
        await Promise.all([
            this.sendPush(userId, title, body, data),
            this.saveToDatabase(userId, title, body, type, data),
        ]);
    },
};
//# sourceMappingURL=notificationService.js.map