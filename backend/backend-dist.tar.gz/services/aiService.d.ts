export declare const aiService: {
    chat(userId: string, message: string, conversationId?: string): Promise<{
        response: string;
        conversationId: string;
    }>;
    generateInsightSummary(content: string): Promise<string>;
    analyzeDocument(text: string): Promise<{
        issues: string[];
        recommendations: string[];
        complianceScore: number;
    }>;
    getComplianceRecommendations(userId: string): Promise<string[]>;
};
//# sourceMappingURL=aiService.d.ts.map