export declare const smsService: {
    sendOTP(phone: string, otp: string): Promise<void>;
};
//# sourceMappingURL=smsService.d.ts.map