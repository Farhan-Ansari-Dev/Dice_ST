export declare const notificationService: {
    sendPush(userId: string, title: string, body: string, data?: Record<string, unknown>): Promise<void>;
    saveToDatabase(userId: string, title: string, body: string, type?: string, metadata?: Record<string, unknown>): Promise<void>;
    notify(userId: string, title: string, body: string, type?: string, data?: Record<string, unknown>): Promise<void>;
};
//# sourceMappingURL=notificationService.d.ts.map