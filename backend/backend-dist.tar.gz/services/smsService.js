"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.smsService = void 0;
const logger_1 = require("../utils/logger");
exports.smsService = {
    async sendOTP(phone, otp) {
        const authKey = process.env.MSG91_AUTH_KEY;
        if (!authKey) {
            // Development fallback — log OTP
            logger_1.logger.info(`[DEV] OTP for ${phone}: ${otp}`);
            return;
        }
        const url = 'https://api.msg91.com/api/v5/otp';
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                authkey: authKey,
            },
            body: JSON.stringify({
                template_id: process.env.MSG91_TEMPLATE_ID,
                mobile: `91${phone}`,
                otp,
            }),
        });
        const data = await response.json();
        logger_1.logger.info('MSG91 response:', data);
    },
};
//# sourceMappingURL=smsService.js.map