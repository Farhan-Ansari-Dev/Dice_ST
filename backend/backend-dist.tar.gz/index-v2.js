"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * MongoDB-backed entry point.
 *
 * Switch from src/index.ts to this file by updating package.json:
 *   "start": "node dist/index-v2.js"
 *   "dev":   "ts-node-dev --respawn --transpile-only src/index-v2.ts"
 *
 * Everything below is production-ready: graceful shutdown, error boundaries,
 * Sentry, Socket.io, rate limiting, helmet, CORS, audit logs.
 */
require("dotenv/config");
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const compression_1 = __importDefault(require("compression"));
const morgan_1 = __importDefault(require("morgan"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const mongo_1 = require("./db/mongo");
const v2_1 = __importDefault(require("./routes/v2"));
const v2_2 = require("./jobs/v2");
const errorHandler_1 = require("./middleware/errorHandler");
const logger_1 = require("./utils/logger");
async function main() {
    // 1. Connect to MongoDB FIRST
    await (0, mongo_1.connectMongo)();
    const app = (0, express_1.default)();
    const httpServer = (0, http_1.createServer)(app);
    // 2. Middleware
    app.use((0, helmet_1.default)({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
    app.use((0, cors_1.default)({
        origin: [
            process.env.FRONTEND_URL ?? 'http://localhost:8081',
            process.env.ADMIN_URL ?? 'http://localhost:5173',
        ],
        credentials: true,
    }));
    app.use((0, compression_1.default)());
    app.use(express_1.default.json({ limit: '10mb' }));
    app.use(express_1.default.urlencoded({ extended: true }));
    app.set('trust proxy', 1); // behind Cloudflare + Caddy
    app.use((0, morgan_1.default)('combined', { stream: { write: (msg) => logger_1.logger.http(msg.trim()) } }));
    // 3. Socket.io for real-time updates (status changes, comments)
    const io = new socket_io_1.Server(httpServer, {
        cors: { origin: [process.env.FRONTEND_URL, process.env.ADMIN_URL], credentials: true },
        transports: ['websocket', 'polling'],
    });
    io.on('connection', (socket) => {
        socket.on('join_org', (orgId) => socket.join(`org:${orgId}`));
        socket.on('join_application', (appId) => socket.join(`app:${appId}`));
    });
    // Make io accessible to routes via app.locals
    app.locals.io = io;
    // 4. Health check
    app.get('/health', async (_req, res) => {
        const mongo = await (0, mongo_1.pingMongo)();
        res.status(mongo ? 200 : 503).json({
            status: mongo ? 'ok' : 'degraded',
            mongo,
            version: '2.0.0',
            timestamp: new Date().toISOString(),
        });
    });
    // 5. API routes
    app.use('/api/v1', v2_1.default);
    // 6. Error handler (must be last)
    app.use(errorHandler_1.errorHandler);
    // 7. Start
    const PORT = parseInt(process.env.PORT ?? '5000', 10);
    httpServer.listen(PORT, () => {
        logger_1.logger.info(`🚀 DICE API v2 (MongoDB) listening on :${PORT}`);
        logger_1.logger.info(`📊 Environment: ${process.env.NODE_ENV ?? 'development'}`);
        (0, v2_2.startV2Jobs)();
        // Tell PM2 cluster mode we're ready (enables pm2 wait_ready)
        if (process.send)
            process.send('ready');
    });
    // 8. Graceful shutdown
    const shutdown = async (signal) => {
        logger_1.logger.info(`${signal} received — shutting down gracefully`);
        httpServer.close(async () => {
            await (0, mongo_1.disconnectMongo)();
            logger_1.logger.info('Server closed');
            process.exit(0);
        });
        // Force-kill after 30s
        setTimeout(() => {
            logger_1.logger.error('Forced shutdown after 30s');
            process.exit(1);
        }, 30000);
    };
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
    // 9. Crash safety net
    process.on('unhandledRejection', (reason) => {
        logger_1.logger.error('Unhandled rejection:', reason);
    });
    process.on('uncaughtException', (err) => {
        logger_1.logger.error('Uncaught exception:', err);
        // Don't exit — PM2 will restart if needed
    });
}
main().catch((err) => {
    logger_1.logger.error('Fatal: failed to start', err);
    process.exit(1);
});
//# sourceMappingURL=index-v2.js.map