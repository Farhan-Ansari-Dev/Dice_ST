/**
 * MongoDB-backed entry point.
 *
 * Switch from src/index.ts to this file by updating package.json:
 *   "start": "node dist/index-v2.js"
 *   "dev":   "ts-node-dev --respawn --transpile-only src/index-v2.ts"
 *
 * Everything below is production-ready: graceful shutdown, error boundaries,
 * Sentry, Socket.io, rate limiting, helmet, CORS, audit logs.
 */
import 'dotenv/config';
//# sourceMappingURL=index-v2.d.ts.map