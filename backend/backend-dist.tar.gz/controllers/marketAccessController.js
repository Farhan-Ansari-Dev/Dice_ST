"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkMarketAccess = exports.getMarketRules = exports.getCountries = exports.getCertifications = exports.getProductCategories = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
const ProductCategory_1 = __importDefault(require("../models/ProductCategory"));
const MarketCertification_1 = __importDefault(require("../models/MarketCertification"));
const MarketRequirement_1 = __importDefault(require("../models/MarketRequirement"));
const marketAccessService_1 = require("../services/marketAccessService");
const getProductCategories = async (req, res) => {
    try {
        const categories = await ProductCategory_1.default.find().sort({ categoryName: 1 });
        res.json(categories);
    }
    catch (error) {
        res.status(500).json({ message: 'Error fetching categories' });
    }
};
exports.getProductCategories = getProductCategories;
const getCertifications = async (req, res) => {
    try {
        const certifications = await MarketCertification_1.default.find().sort({ certificationName: 1 });
        res.json(certifications);
    }
    catch (error) {
        res.status(500).json({ message: 'Error fetching certifications' });
    }
};
exports.getCertifications = getCertifications;
const getCountries = async (req, res) => {
    try {
        const countries = await MarketRequirement_1.default.distinct('country');
        res.json(countries.sort());
    }
    catch (error) {
        res.status(500).json({ message: 'Error fetching countries' });
    }
};
exports.getCountries = getCountries;
const getMarketRules = async (req, res) => {
    try {
        const rules = await MarketRequirement_1.default.find()
            .populate('productCategoryId')
            .populate('requiredCertifications');
        res.json(rules);
    }
    catch (error) {
        res.status(500).json({ message: 'Error fetching rules' });
    }
};
exports.getMarketRules = getMarketRules;
const checkMarketAccess = async (req, res) => {
    try {
        const { productCategory, certificationsOwned } = req.body;
        let category = await ProductCategory_1.default.findOne({ categoryName: productCategory });
        if (!category && mongoose_1.default.Types.ObjectId.isValid(productCategory)) {
            category = await ProductCategory_1.default.findById(productCategory);
        }
        if (!category) {
            return res.status(404).json({ message: 'Product category not found' });
        }
        const output = await marketAccessService_1.MarketAccessService.calculateMarketAccess(category._id.toString(), certificationsOwned || []);
        res.json(output);
    }
    catch (error) {
        res.status(500).json({ message: 'Error calculating market access' });
    }
};
exports.checkMarketAccess = checkMarketAccess;
//# sourceMappingURL=marketAccessController.js.map