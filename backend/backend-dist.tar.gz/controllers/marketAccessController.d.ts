import { Request, Response } from 'express';
export declare const getProductCategories: (req: Request, res: Response) => Promise<any>;
export declare const getCertifications: (req: Request, res: Response) => Promise<any>;
export declare const getCountries: (req: Request, res: Response) => Promise<any>;
export declare const getMarketRules: (req: Request, res: Response) => Promise<any>;
export declare const checkMarketAccess: (req: Request, res: Response) => Promise<any>;
//# sourceMappingURL=marketAccessController.d.ts.map