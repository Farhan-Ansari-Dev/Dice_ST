export declare function setupTestDB(): Promise<void>;
export declare function teardownTestDB(): Promise<void>;
export declare function clearTestDB(): Promise<void>;
//# sourceMappingURL=setup.d.ts.map