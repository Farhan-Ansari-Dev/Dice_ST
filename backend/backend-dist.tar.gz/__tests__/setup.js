"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupTestDB = setupTestDB;
exports.teardownTestDB = teardownTestDB;
exports.clearTestDB = clearTestDB;
/**
 * Test setup & teardown — shared across all test files.
 *
 * - Starts an in-memory MongoDB before all tests
 * - Cleans collections between tests
 * - Shuts down after all tests
 */
const mongoose_1 = __importDefault(require("mongoose"));
const mongodb_memory_server_1 = require("mongodb-memory-server");
let mongoServer;
async function setupTestDB() {
    mongoServer = await mongodb_memory_server_1.MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose_1.default.connect(uri);
}
async function teardownTestDB() {
    await mongoose_1.default.connection.dropDatabase();
    await mongoose_1.default.disconnect();
    await mongoServer.stop();
}
async function clearTestDB() {
    const collections = mongoose_1.default.connection.collections;
    for (const key in collections) {
        await collections[key].deleteMany({});
    }
}
//# sourceMappingURL=setup.js.map