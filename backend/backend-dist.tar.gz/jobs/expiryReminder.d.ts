/**
 * Checks for certificates expiring in 30, 7, and 1 day(s)
 * and sends push + in-app notifications to the certificate owner.
 */
export declare function runExpiryReminders(): Promise<void>;
/**
 * Also checks for applications that have been stale for >14 days
 */
export declare function runStaleApplicationCheck(): Promise<void>;
//# sourceMappingURL=expiryReminder.d.ts.map