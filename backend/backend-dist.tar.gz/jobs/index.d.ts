/**
 * Start all background jobs.
 * In production, use node-cron or Bull/BullMQ with Redis.
 * For now, simple setInterval is sufficient.
 */
export declare function startBackgroundJobs(): void;
//# sourceMappingURL=index.d.ts.map