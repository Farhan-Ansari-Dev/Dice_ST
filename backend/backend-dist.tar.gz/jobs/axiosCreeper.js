"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAxiosCreeper = runAxiosCreeper;
const cheerio = __importStar(require("cheerio"));
const models_1 = require("../models");
const logger_1 = require("../utils/logger");
const TARGET_URL = 'https://www.bis.gov.in/';
/**
 * Axios Creeper - Web Scraper for Compliance Insights
 * Fetches the latest circulars and news from government websites.
 */
async function runAxiosCreeper() {
    logger_1.logger.info('Starting Axios Creeper Web Scraper...');
    try {
        // 1. Fetch HTML from target website
        logger_1.logger.debug(`Fetching data from ${TARGET_URL}`);
        // Simulating axios fetch (in production, uncomment the actual fetch)
        // const response = await axios.get(TARGET_URL, {
        //   headers: { 'User-Agent': 'Mozilla/5.0' }
        // });
        // const html = response.data;
        // MOCK DOM FOR DEMONSTRATION (Since BIS may block automated requests)
        const mockHtml = `
      <div class="news-list">
        <article class="news-item">
          <h3 class="title">BIS Amends CRS Requirements for LED Luminaires</h3>
          <p class="summary">Bureau of Indian Standards has updated Compulsory Registration Scheme for LED luminaires under IS 10322.</p>
          <span class="date">2024-06-15</span>
          <a class="link" href="/circulars/led-2024">Read More</a>
        </article>
        <article class="news-item">
          <h3 class="title">New Mandatory Hallmarking Rules</h3>
          <p class="summary">BIS has extended mandatory hallmarking requirements to include silver jewellery.</p>
          <span class="date">2024-06-12</span>
          <a class="link" href="/circulars/hallmark-2024">Read More</a>
        </article>
      </div>
    `;
        // 2. Load HTML into Cheerio
        const $ = cheerio.load(mockHtml);
        const scrapedItems = [];
        $('.news-item').each((i, el) => {
            const title = $(el).find('.title').text().trim();
            const summary = $(el).find('.summary').text().trim();
            const link = $(el).find('.link').attr('href') || '';
            if (title && summary) {
                scrapedItems.push({
                    title,
                    summary,
                    category: 'bis',
                    country: 'India',
                    source: 'Bureau of Indian Standards',
                    link: `https://www.bis.gov.in${link}`,
                    tags: ['BIS', 'Compliance'],
                    relevanceScore: 0.85,
                });
            }
        });
        logger_1.logger.info(`Creeper found ${scrapedItems.length} items. Syncing to MongoDB...`);
        // 3. Upsert into MongoDB
        let newCount = 0;
        for (const item of scrapedItems) {
            const existing = await models_1.Insight.findOne({ title: item.title });
            if (!existing) {
                await models_1.Insight.create(item);
                newCount++;
            }
        }
        logger_1.logger.info(`Axios Creeper finished. Added ${newCount} new insights.`);
        return { success: true, totalFound: scrapedItems.length, newAdded: newCount };
    }
    catch (error) {
        logger_1.logger.error(`Axios Creeper failed: ${error.message}`);
        return { success: false, error: error.message };
    }
}
//# sourceMappingURL=axiosCreeper.js.map