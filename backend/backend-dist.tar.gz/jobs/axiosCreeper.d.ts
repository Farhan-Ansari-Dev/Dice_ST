/**
 * Axios Creeper - Web Scraper for Compliance Insights
 * Fetches the latest circulars and news from government websites.
 */
export declare function runAxiosCreeper(): Promise<{
    success: boolean;
    totalFound: number;
    newAdded: number;
    error?: undefined;
} | {
    success: boolean;
    error: any;
    totalFound?: undefined;
    newAdded?: undefined;
}>;
//# sourceMappingURL=axiosCreeper.d.ts.map