export declare function startV2Jobs(): void;
//# sourceMappingURL=index.d.ts.map