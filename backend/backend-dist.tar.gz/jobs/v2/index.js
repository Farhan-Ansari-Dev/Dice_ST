"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startV2Jobs = startV2Jobs;
/**
 * v2 background jobs scheduler.
 * Single in-process scheduler — fine at this scale (single EC2).
 * Migrate to BullMQ when you scale to multiple workers.
 */
const certExpiryReminder_1 = require("./certExpiryReminder");
const logger_1 = require("../../utils/logger");
const HOUR = 60 * 60 * 1000;
function startV2Jobs() {
    logger_1.logger.info('🔄 Starting v2 background jobs (MongoDB)...');
    // Run 5 seconds after server boot
    setTimeout(async () => {
        await (0, certExpiryReminder_1.runCertExpiryReminders)().catch(e => logger_1.logger.error('[expiry] startup run failed', e));
        logger_1.logger.info('✅ Initial v2 job run complete');
    }, 5000);
    // Daily check — every hour, run when IST is 09:00
    setInterval(async () => {
        const now = new Date();
        // IST = UTC+5:30 → check current UTC hour
        const istHour = (now.getUTCHours() + 5) % 24;
        const istMin = now.getUTCMinutes() + 30;
        if (istHour === 9 && istMin >= 30 && istMin < 60) {
            try {
                await (0, certExpiryReminder_1.runCertExpiryReminders)();
            }
            catch (e) {
                logger_1.logger.error('[expiry] scheduled run failed', e);
            }
        }
    }, HOUR);
    logger_1.logger.info('✅ v2 background jobs scheduled (cert expiry daily @ 09:30 IST)');
}
//# sourceMappingURL=index.js.map