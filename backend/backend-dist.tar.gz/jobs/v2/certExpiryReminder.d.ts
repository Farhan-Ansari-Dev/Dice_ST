export declare function runCertExpiryReminders(): Promise<void>;
//# sourceMappingURL=certExpiryReminder.d.ts.map