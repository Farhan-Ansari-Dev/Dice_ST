"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.startBackgroundJobs = startBackgroundJobs;
const expiryReminder_1 = require("./expiryReminder");
const insightsScraper_1 = require("./insightsScraper");
const logger_1 = require("../utils/logger");
const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
/**
 * Start all background jobs.
 * In production, use node-cron or Bull/BullMQ with Redis.
 * For now, simple setInterval is sufficient.
 */
function startBackgroundJobs() {
    logger_1.logger.info('🔄 Starting background jobs...');
    // Run immediately on startup, then daily
    setTimeout(async () => {
        await (0, insightsScraper_1.seedInsights)().catch((e) => logger_1.logger.error('Insights seed failed:', e));
        await (0, expiryReminder_1.runExpiryReminders)().catch((e) => logger_1.logger.error('Expiry reminders failed:', e));
        await (0, expiryReminder_1.runStaleApplicationCheck)().catch((e) => logger_1.logger.error('Stale app check failed:', e));
        logger_1.logger.info('✅ Initial job run complete');
    }, 5000); // 5s after server starts
    // Daily: expiry reminders at 9:00 AM IST
    setInterval(async () => {
        const now = new Date();
        const istHour = (now.getUTCHours() + 5) % 24; // IST = UTC+5:30, approximate
        if (istHour === 9) {
            await (0, expiryReminder_1.runExpiryReminders)().catch((e) => logger_1.logger.error('Expiry reminders failed:', e));
            await (0, expiryReminder_1.runStaleApplicationCheck)().catch((e) => logger_1.logger.error('Stale app check failed:', e));
        }
    }, HOUR);
    // Daily: seed insights
    setInterval(async () => {
        await (0, insightsScraper_1.seedInsights)().catch((e) => logger_1.logger.error('Insights seed failed:', e));
    }, DAY);
    logger_1.logger.info('✅ Background jobs scheduled');
}
//# sourceMappingURL=index.js.map