/**
 * Seeds the insights table with sample regulatory updates.
 * In production, this would be replaced by an actual web scraper
 * or RSS feed parser pulling from government gazette sites.
 */
export declare function seedInsights(): Promise<void>;
//# sourceMappingURL=insightsScraper.d.ts.map