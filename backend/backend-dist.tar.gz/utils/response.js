"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendPaginated = exports.sendError = exports.sendSuccess = void 0;
const sendSuccess = (res, data, message = 'Success', statusCode = 200) => {
    return res.status(statusCode).json({ success: true, message, data, timestamp: new Date().toISOString() });
};
exports.sendSuccess = sendSuccess;
const sendError = (res, message, statusCode = 400, errors) => {
    return res.status(statusCode).json({ success: false, message, errors, timestamp: new Date().toISOString() });
};
exports.sendError = sendError;
const sendPaginated = (res, data, total, page, limit, message = 'Success') => {
    return res.json({
        success: true, message, data,
        pagination: { total, page, limit, pages: Math.ceil(total / limit), hasNext: page * limit < total, hasPrev: page > 1 },
        timestamp: new Date().toISOString(),
    });
};
exports.sendPaginated = sendPaginated;
//# sourceMappingURL=response.js.map