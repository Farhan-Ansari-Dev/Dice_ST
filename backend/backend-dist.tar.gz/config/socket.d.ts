import { Server } from 'socket.io';
import { Server as HttpServer } from 'http';
export declare const setupSocket: (httpServer: HttpServer) => Server<import("socket.io").DefaultEventsMap, import("socket.io").DefaultEventsMap, import("socket.io").DefaultEventsMap, any>;
export declare const getIO: () => Server<import("socket.io").DefaultEventsMap, import("socket.io").DefaultEventsMap, import("socket.io").DefaultEventsMap, any>;
export declare const emitToUser: (userId: string, event: string, data: any) => boolean;
export declare const emitToAdmin: (event: string, data: any) => boolean;
export declare const emitToApp: (appId: string, event: string, data: any) => boolean;
export declare const emitBroadcast: (event: string, data: any) => boolean;
//# sourceMappingURL=socket.d.ts.map