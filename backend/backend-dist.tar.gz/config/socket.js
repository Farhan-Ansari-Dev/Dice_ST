"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emitBroadcast = exports.emitToApp = exports.emitToAdmin = exports.emitToUser = exports.getIO = exports.setupSocket = void 0;
const socket_io_1 = require("socket.io");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const logger_1 = require("../utils/logger");
let io;
const setupSocket = (httpServer) => {
    io = new socket_io_1.Server(httpServer, {
        cors: {
            origin: [process.env.FRONTEND_URL ?? 'http://localhost:8081', process.env.ADMIN_URL ?? 'http://localhost:5173'],
            methods: ['GET', 'POST'],
            credentials: true,
        },
        transports: ['websocket', 'polling'],
    });
    io.use((socket, next) => {
        const token = socket.handshake.auth.token;
        if (!token)
            return next(new Error('Authentication required'));
        try {
            const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
            socket.data.userId = decoded.userId;
            socket.data.role = decoded.role;
            next();
        }
        catch {
            next(new Error('Invalid token'));
        }
    });
    io.on('connection', (socket) => {
        const userId = socket.data.userId;
        logger_1.logger.info(`Socket connected: ${socket.id} (user: ${userId})`);
        socket.join(`user:${userId}`);
        if (socket.data.role === 'admin')
            socket.join('admin');
        socket.on('join:application', (appId) => socket.join(`app:${appId}`));
        socket.on('leave:application', (appId) => socket.leave(`app:${appId}`));
        socket.on('disconnect', () => logger_1.logger.info(`Socket disconnected: ${socket.id}`));
    });
    return io;
};
exports.setupSocket = setupSocket;
const getIO = () => {
    if (!io)
        throw new Error('Socket.io not initialized');
    return io;
};
exports.getIO = getIO;
// Emit helpers
const emitToUser = (userId, event, data) => (0, exports.getIO)().to(`user:${userId}`).emit(event, data);
exports.emitToUser = emitToUser;
const emitToAdmin = (event, data) => (0, exports.getIO)().to('admin').emit(event, data);
exports.emitToAdmin = emitToAdmin;
const emitToApp = (appId, event, data) => (0, exports.getIO)().to(`app:${appId}`).emit(event, data);
exports.emitToApp = emitToApp;
const emitBroadcast = (event, data) => (0, exports.getIO)().emit(event, data);
exports.emitBroadcast = emitBroadcast;
//# sourceMappingURL=socket.js.map