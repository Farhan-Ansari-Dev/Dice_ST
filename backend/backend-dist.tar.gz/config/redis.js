"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Redis client with in-memory fallback.
 *
 * When Redis is available (Docker / ElastiCache / Upstash), this module
 * uses ioredis as usual. When Redis is NOT reachable (local dev without
 * Docker), it silently degrades to a Map-based in-memory cache so the
 * backend still starts and runs.
 */
const ioredis_1 = __importDefault(require("ioredis"));
const logger_1 = require("../utils/logger");
// ── In-memory fallback (dev-only, single-process) ────────────────────────────
class MemoryCache {
    constructor() {
        this.store = new Map();
        this.timers = new Map();
    }
    async get(key) {
        const entry = this.store.get(key);
        if (!entry)
            return null;
        if (entry.expiresAt && Date.now() > entry.expiresAt) {
            this.store.delete(key);
            return null;
        }
        return entry.value;
    }
    async set(key, value) {
        this.store.set(key, { value });
        return 'OK';
    }
    async setex(key, seconds, value) {
        this.store.set(key, { value, expiresAt: Date.now() + seconds * 1000 });
        // Auto-cleanup
        const existing = this.timers.get(key);
        if (existing)
            clearTimeout(existing);
        this.timers.set(key, setTimeout(() => this.store.delete(key), seconds * 1000));
        return 'OK';
    }
    async del(key) {
        const had = this.store.has(key);
        this.store.delete(key);
        const timer = this.timers.get(key);
        if (timer) {
            clearTimeout(timer);
            this.timers.delete(key);
        }
        return had ? 1 : 0;
    }
    async incr(key) {
        const current = await this.get(key);
        const next = (parseInt(current ?? '0', 10) || 0) + 1;
        const entry = this.store.get(key);
        this.store.set(key, { value: String(next), expiresAt: entry?.expiresAt });
        return next;
    }
    async expire(key, seconds) {
        const entry = this.store.get(key);
        if (!entry)
            return 0;
        entry.expiresAt = Date.now() + seconds * 1000;
        const existing = this.timers.get(key);
        if (existing)
            clearTimeout(existing);
        this.timers.set(key, setTimeout(() => this.store.delete(key), seconds * 1000));
        return 1;
    }
    // No-op methods for compatibility
    on(_event, _handler) { return this; }
    async ping() { return 'PONG'; }
    async quit() { return 'OK'; }
    get status() { return 'ready'; }
}
// ── Try real Redis, fallback to memory ───────────────────────────────────────
let redisClient;
const redisUrl = process.env.REDIS_URL ?? 'redis://localhost:6379';
try {
    const client = new ioredis_1.default(redisUrl, {
        retryStrategy: (times) => {
            if (times > 3) {
                logger_1.logger.warn('⚠️  Redis unavailable — switching to in-memory cache');
                return null; // stop retrying
            }
            return Math.min(times * 200, 1000);
        },
        maxRetriesPerRequest: 1,
        enableReadyCheck: true,
        connectTimeout: 3000,
        lazyConnect: true,
    });
    // Try to connect — if it fails, swap to memory
    client.connect().then(() => {
        logger_1.logger.info('✅ Redis connected');
        redisClient = client;
    }).catch(() => {
        logger_1.logger.warn('⚠️  Redis not available — using in-memory cache (dev mode)');
        redisClient = new MemoryCache();
    });
    client.on('error', () => {
        if (!(redisClient instanceof MemoryCache)) {
            logger_1.logger.warn('⚠️  Redis error — falling back to in-memory cache');
            redisClient = new MemoryCache();
        }
    });
    // Start with memory cache until Redis connects
    redisClient = new MemoryCache();
}
catch {
    logger_1.logger.warn('⚠️  Redis init failed — using in-memory cache');
    redisClient = new MemoryCache();
}
exports.default = redisClient;
//# sourceMappingURL=redis.js.map