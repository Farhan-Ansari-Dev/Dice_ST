declare const _default: {
    get(key: string): Promise<string | null>;
    set(key: string, value: string): Promise<"OK">;
    setex(key: string, seconds: number, value: string): Promise<"OK">;
    del(key: string): Promise<number>;
    incr(key: string): Promise<number>;
    expire(key: string, seconds: number): Promise<number>;
    on(event: string, handler: (...args: any[]) => void): any;
    quit(): Promise<string>;
};
export default _default;
//# sourceMappingURL=redis.d.ts.map