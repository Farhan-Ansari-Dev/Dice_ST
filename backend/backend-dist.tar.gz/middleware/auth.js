"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requireRole = exports.requireAdmin = exports.authenticate = void 0;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const errorHandler_1 = require("./errorHandler");
const authenticate = (req, res, next) => {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer '))
        throw new errorHandler_1.AppError('No token provided', 401);
    const token = auth.split(' ')[1];
    try {
        const decoded = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        req.user = { id: decoded.userId, email: decoded.email, role: decoded.role };
        next();
    }
    catch {
        throw new errorHandler_1.AppError('Invalid or expired token', 401);
    }
};
exports.authenticate = authenticate;
const requireAdmin = (req, res, next) => {
    if (req.user?.role !== 'admin')
        throw new errorHandler_1.AppError('Admin access required', 403);
    next();
};
exports.requireAdmin = requireAdmin;
const requireRole = (...roles) => (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role))
        throw new errorHandler_1.AppError('Insufficient permissions', 403);
    next();
};
exports.requireRole = requireRole;
//# sourceMappingURL=auth.js.map