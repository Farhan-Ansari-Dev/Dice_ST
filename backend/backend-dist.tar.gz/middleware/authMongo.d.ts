/**
 * Auth middleware for MongoDB-backed routes.
 * Verifies JWT, hydrates req.user with the Mongoose User document.
 */
import { Request, Response, NextFunction } from 'express';
import { IUser } from '../models';
export interface AuthRequest extends Request {
    user?: IUser;
    token_payload?: JwtPayload;
}
interface JwtPayload {
    sub: string;
    org?: string;
    role: string;
    iat: number;
    exp: number;
    jti: string;
}
export declare function authenticate(req: AuthRequest, res: Response, next: NextFunction): Promise<void>;
/**
 * Authorisation guard — restrict route to specific roles.
 *
 *   router.delete('/users/:id', authenticate, requireRole('super_admin', 'admin'), handler);
 */
export declare function requireRole(...roles: string[]): (req: AuthRequest, res: Response, next: NextFunction) => void;
/**
 * Issue a JWT pair (access + refresh).
 */
export declare function issueTokens(user: IUser): {
    accessToken: string;
    refreshToken: string;
};
export {};
//# sourceMappingURL=authMongo.d.ts.map