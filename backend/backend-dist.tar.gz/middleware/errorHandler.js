"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = exports.AppError = void 0;
const logger_1 = require("../utils/logger");
class AppError extends Error {
    constructor(message, statusCode = 400) {
        super(message);
        this.statusCode = statusCode;
        this.isOperational = true;
        Error.captureStackTrace(this, this.constructor);
    }
}
exports.AppError = AppError;
const errorHandler = (err, req, res, next) => {
    logger_1.logger.error(`${err.message} — ${req.method} ${req.path}`, { stack: err.stack });
    if (err.name === 'ValidationError') {
        return res.status(400).json({ success: false, message: 'Validation failed', errors: err.errors });
    }
    if (err.name === 'JsonWebTokenError') {
        return res.status(401).json({ success: false, message: 'Invalid token' });
    }
    if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ success: false, message: 'Token expired' });
    }
    if (err.code === '23505') {
        return res.status(409).json({ success: false, message: 'Resource already exists' });
    }
    if (err.code === '23503') {
        return res.status(404).json({ success: false, message: 'Referenced resource not found' });
    }
    const statusCode = err.statusCode ?? err.status ?? 500;
    const message = err.isOperational ? err.message : 'Internal server error';
    return res.status(statusCode).json({ success: false, message, timestamp: new Date().toISOString() });
};
exports.errorHandler = errorHandler;
//# sourceMappingURL=errorHandler.js.map