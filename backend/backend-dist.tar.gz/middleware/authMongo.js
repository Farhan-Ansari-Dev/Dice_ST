"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticate = authenticate;
exports.requireRole = requireRole;
exports.issueTokens = issueTokens;
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const models_1 = require("../models");
const logger_1 = require("../utils/logger");
async function authenticate(req, res, next) {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
        res.status(401).json({ error: 'unauthenticated', message: 'Missing Bearer token' });
        return;
    }
    const token = header.slice(7);
    try {
        const payload = jsonwebtoken_1.default.verify(token, process.env.JWT_SECRET);
        const user = await models_1.User.findById(payload.sub);
        if (!user) {
            res.status(401).json({ error: 'invalid_token', message: 'User not found' });
            return;
        }
        req.user = user;
        req.token_payload = payload;
        // Track last activity (fire-and-forget)
        models_1.User.updateOne({ _id: user._id }, { $set: { last_active_at: new Date() } }).catch(() => { });
        next();
    }
    catch (err) {
        if (err.name === 'TokenExpiredError') {
            res.status(401).json({ error: 'token_expired' });
        }
        else {
            logger_1.logger.warn('[auth] invalid token', err.message);
            res.status(401).json({ error: 'invalid_token' });
        }
    }
}
/**
 * Authorisation guard — restrict route to specific roles.
 *
 *   router.delete('/users/:id', authenticate, requireRole('super_admin', 'admin'), handler);
 */
function requireRole(...roles) {
    return (req, res, next) => {
        if (!req.user) {
            res.status(401).json({ error: 'unauthenticated' });
            return;
        }
        if (!roles.includes(req.user.role)) {
            res.status(403).json({ error: 'forbidden', required: roles });
            return;
        }
        next();
    };
}
/**
 * Issue a JWT pair (access + refresh).
 */
function issueTokens(user) {
    const jti = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const payload = {
        sub: user._id.toString(),
        org: user.org_id?.toString(),
        role: user.role,
        jti,
    };
    const accessToken = jsonwebtoken_1.default.sign(payload, process.env.JWT_SECRET, { expiresIn: '15m' });
    const refreshToken = jsonwebtoken_1.default.sign({ sub: payload.sub, jti }, process.env.JWT_REFRESH_SECRET, { expiresIn: '30d' });
    return { accessToken, refreshToken };
}
//# sourceMappingURL=authMongo.js.map