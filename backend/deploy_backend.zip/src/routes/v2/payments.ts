import { Router, Request, Response, NextFunction } from 'express'
import { authenticate, AuthRequest } from '../../middleware/authMongo'
import { Payment } from '../../models/Payment'
import { razorpayService } from '../../services/razorpayService'
import { sendSuccess } from '../../utils/response'

const router = Router()
const wrap = (fn: any) => (req: Request, res: Response, next: NextFunction) => fn(req, res, next).catch(next)

router.get('/', authenticate, wrap(async (req: AuthRequest, res: Response) => {
  const query: any = {}
  if (req.user!.role !== 'admin' && req.user!.role !== 'super_admin') {
    query.org_id = req.user!.org_id
  }
  
  const payments = await Payment.find(query).populate('user_id', 'name email').populate('org_id', 'name').sort({ created_at: -1 }).lean()
  sendSuccess(res, payments)
}))

router.get('/:id', authenticate, wrap(async (req: AuthRequest, res: Response) => {
  const payment = await Payment.findOne({ _id: req.params.id, org_id: req.user!.org_id }).lean()
  sendSuccess(res, payment)
}))

import { Application } from '../../models/Application'
import { User } from '../../models/User'

// Create a Razorpay order / Quotation
router.post('/quotations', authenticate, wrap(async (req: AuthRequest, res: Response) => {
  const { application_id, gov_fee, lab_fee } = req.body
  
  const app = await Application.findById(application_id).populate('client_id')
  if (!app) return res.status(404).json({ success: false, message: 'Application not found' })
  
  const clientUser = await User.findById(app.client_id)
  const isIndian = clientUser?.country_code === 'IN'
  
  const currency = isIndian ? 'INR' : 'USD'
  const consultancyFee = isIndian ? 1999 : 50
  
  const govFeeNum = Number(gov_fee) || 0
  const labFeeNum = Number(lab_fee) || 0
  
  const subtotal = govFeeNum + labFeeNum + consultancyFee
  const taxRate = isIndian ? 18 : 0
  const taxAmount = subtotal * (taxRate / 100)
  
  const totalAmount = subtotal + taxAmount
  const totalPaise = Math.round(totalAmount * 100)
  
  const breakdown = {
    gov_fee_paise: Math.round(govFeeNum * 100),
    lab_fee_paise: Math.round(labFeeNum * 100),
    consultancy_fee_paise: Math.round(consultancyFee * 100),
    subtotal_paise: Math.round(subtotal * 100),
    tax_amount_paise: Math.round(taxAmount * 100),
    tax_rate: taxRate
  }
  
  const result = await razorpayService.createOrder(
    req.user!._id.toString(),
    application_id,
    totalPaise,
    'Certification Fees & Sanyog Consultancy',
    currency,
    breakdown
  )
  
  sendSuccess(res, result.payment, 'Quotation generated successfully', 201)
}))

router.post('/create-order', authenticate, wrap(async (req: AuthRequest, res: Response) => {
  const { amount, currency, receipt } = req.body
  
  if (!amount || amount < 100) {
    return res.status(400).json({ success: false, message: 'Minimum amount is 100 paise' })
  }

  try {
    const result = await razorpayService.createOrder(
      req.user!._id.toString(),
      null, // applicationId not strictly needed for generic checkout
      amount / 100, // razorpayService expects amount in INR, multiplies by 100
      receipt || 'Standard Checkout'
    )
    
    // The user's prompt expects { order_id, amount, currency }
    return res.json({
      success: true,
      order_id: result.order.id,
      amount: result.order.amount,
      currency: result.order.currency
    })
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Failed to create order' })
  }
}))

router.post('/verify-payment', authenticate, wrap(async (req: AuthRequest, res: Response) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body
  
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ success: false, message: 'Missing payment signature fields' })
  }

  const isValid = await razorpayService.verifyPayment(
    razorpay_order_id,
    razorpay_payment_id,
    razorpay_signature,
    req.user!._id.toString()
  )

  if (!isValid) {
    return res.status(400).json({ success: false, message: 'Payment verification failed' })
  }

  return res.json({ success: true, message: 'Payment verified successfully' })
}))

router.post('/webhook', wrap(async (req: Request, res: Response) => {
  const signature = req.headers['x-razorpay-signature'] as string
  const payload = JSON.stringify(req.body)

  const isValid = await razorpayService.handleWebhook(payload, signature)
  if (!isValid) {
    return res.status(400).json({ success: false, message: 'Invalid signature' })
  }

  const event = req.body.event
  if (event === 'payment.captured' || event === 'payment.authorized') {
    const paymentId = req.body.payload.payment.entity.id
    const orderId = req.body.payload.payment.entity.order_id
    // Normally you'd extract userId from the notes
    const userId = req.body.payload.payment.entity.notes?.userId
    
    if (userId) {
      // In webhook, we might not have the signature generated by the client checkout flow.
      // We pass empty string for signature if it's purely webhook based.
      await razorpayService.verifyPayment(orderId, paymentId, signature || '', userId)
    }
  }

  return res.json({ success: true })
}))

export default router
